/* Графика: всё рисуется кодом (Canvas 2D), кроме головы Дона Сомбреро (assets/hero.png). */
(function () {
  'use strict';
  const TAU = Math.PI * 2;
  const RARITY = {
    common:    { name: 'Обычный',      color: '#9aa7b4', glow: 0 },
    uncommon:  { name: 'Необычный',    color: '#4fcf6a', glow: 0.25 },
    rare:      { name: 'Редкий',       color: '#3d9bff', glow: 0.4 },
    epic:      { name: 'Эпический',    color: '#a65cff', glow: 0.6 },
    legendary: { name: 'Легендарный',  color: '#ffa31f', glow: 0.85 },
    mythic:    { name: 'Мифический',   color: '#ff3f74', glow: 1 }
  };
  const CROP_COLORS = {
    wheat: ['#e9c64c', '#8fb83a'], carrot: ['#ff8a1f', '#4aa83a'], corn: ['#ffd83a', '#59a83a'],
    pumpkin: ['#ff7a1a', '#4f9a35'], berry: ['#ee2e4f', '#3f9a4a']
  };

  function rng(seed) { let a = seed >>> 0; return () => { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
  function rr(c, x, y, w, h, r) { c.beginPath(); c.moveTo(x + r, y); c.arcTo(x + w, y, x + w, y + h, r); c.arcTo(x + w, y + h, x, y + h, r); c.arcTo(x, y + h, x, y, r); c.arcTo(x, y, x + w, y, r); c.closePath(); }
  function ell(c, x, y, rx, ry) { c.beginPath(); c.ellipse(x, y, rx, ry, 0, 0, TAU); }
  function shade(hex, k) { // k>0 светлее, k<0 темнее
    const n = parseInt(hex.slice(1), 16); let r = n >> 16, g = n >> 8 & 255, b = n & 255;
    const f = k < 0 ? 0 : 255, p = Math.abs(k);
    r = Math.round((f - r) * p + r); g = Math.round((f - g) * p + g); b = Math.round((f - b) * p + b);
    return 'rgb(' + r + ',' + g + ',' + b + ')';
  }
  function shadow(c, x, y, rx, ry, a) { c.fillStyle = 'rgba(20,40,20,' + (a == null ? 0.28 : a) + ')'; ell(c, x, y, rx, ry); c.fill(); }
  function grad(c, x0, y0, x1, y1, stops) { const g = c.createLinearGradient(x0, y0, x1, y1); stops.forEach((s, i) => g.addColorStop(i / (stops.length - 1), s)); return g; }
  function outline(c, w) { c.lineWidth = w || 3; c.strokeStyle = 'rgba(40,24,12,.55)'; c.lineJoin = 'round'; c.stroke(); }
  function text(c, s, x, y, size, color, align) {
    c.font = '800 ' + size + 'px "Trebuchet MS","Segoe UI",system-ui,sans-serif'; c.textAlign = align || 'center'; c.textBaseline = 'middle';
    c.lineWidth = Math.max(3, size / 4); c.strokeStyle = 'rgba(30,20,10,.75)'; c.lineJoin = 'round'; c.strokeText(s, x, y);
    c.fillStyle = color || '#fff'; c.fillText(s, x, y);
  }

  /* ---------- спрайты героя ---------- */
  const hero = { ready: false, base: null, neo: null, gold: null };
  function tint(src, fn) {
    const c = document.createElement('canvas'); c.width = src.width; c.height = src.height;
    const x = c.getContext('2d'); x.drawImage(src, 0, 0);
    const d = x.getImageData(0, 0, c.width, c.height), p = d.data;
    for (let i = 0; i < p.length; i += 4) { if (p[i + 3] === 0) continue; const o = fn(p[i], p[i + 1], p[i + 2]); p[i] = o[0]; p[i + 1] = o[1]; p[i + 2] = o[2]; }
    x.putImageData(d, 0, 0); return c;
  }
  function hueShift(r, g, b, deg, sat) {
    r /= 255; g /= 255; b /= 255;
    const mx = Math.max(r, g, b), mn = Math.min(r, g, b), l = (mx + mn) / 2; let h = 0, s = 0;
    if (mx !== mn) { const d = mx - mn; s = l > 0.5 ? d / (2 - mx - mn) : d / (mx + mn); h = mx === r ? (g - b) / d + (g < b ? 6 : 0) : mx === g ? (b - r) / d + 2 : (r - g) / d + 4; h /= 6; }
    h = (h + deg / 360) % 1; s = Math.min(1, s * sat);
    const q = l < 0.5 ? l * (1 + s) : l + s - l * s, p = 2 * l - q;
    const f = t => { t = (t + 1) % 1; return t < 1 / 6 ? p + (q - p) * 6 * t : t < 1 / 2 ? q : t < 2 / 3 ? p + (q - p) * (2 / 3 - t) * 6 : p; };
    return s === 0 ? [l * 255, l * 255, l * 255] : [f(h + 1 / 3) * 255, f(h) * 255, f(h - 1 / 3) * 255];
  }
  function loadHero(url) {
    return new Promise(res => {
      const img = new Image();
      img.onload = () => {
        const w = 256, h = Math.round(256 * img.height / img.width);
        const c = document.createElement('canvas'); c.width = w; c.height = h; c.getContext('2d').drawImage(img, 0, 0, w, h);
        hero.base = c; hero.neo = c; hero.gold = c;
        hero.ready = true; // базовый спрайт доступен сразу, даже если перекраска невозможна
        try { // getImageData запрещён при запуске с file:// — тогда остаются исходные цвета
          hero.neo = tint(c, (r, g, b) => hueShift(r, g, b, 175, 1.5));
          hero.gold = tint(c, (r, g, b) => { const l = (0.3 * r + 0.59 * g + 0.11 * b) / 255; return [Math.min(255, 255 * (0.35 + l * 0.9)), Math.min(255, 205 * (0.3 + l * 0.85)), 60 * l]; });
        } catch (e) { /* остаются исходные цвета */ }
        res(true);
      };
      img.onerror = () => res(false);
      img.src = url;
    });
  }
  /* Рисует голову героя; (x,y) — точка опоры (низ), h — высота. */
  function drawHero(c, kind, x, y, h, t, opts) {
    if (!hero.ready) return;
    opts = opts || {};
    const src = kind === 'hero_neo' ? hero.neo : kind === 'hero_gold' ? hero.gold : hero.base;
    const ar = src.width / src.height, bob = opts.bob == null ? Math.sin(t * 3) : opts.bob;
    const sq = 1 + bob * 0.035, w = h * ar * (1 / sq);
    c.save(); c.translate(x, y); c.rotate((opts.tilt || 0) + Math.sin(t * 2.1) * 0.025);
    c.drawImage(src, -w / 2, -h * sq, w, h * sq);
    c.restore();
  }

  /* ---------- питомцы ---------- */
  const PET_STYLE = {
    chick:   { body: '#ffd84a', belly: '#fff1a8', w: 22, h: 20, ears: 'tuft', beak: '#ff8f2a' },
    duck:    { body: '#fffdf2', belly: '#ffffff', w: 23, h: 20, beak: '#ffa51f', flat: true },
    goat:    { body: '#d9d4c8', belly: '#f5f1e6', w: 24, h: 24, horns: '#8b6b3f', ears: 'side' },
    piglet:  { body: '#ffa5b8', belly: '#ffd0da', w: 25, h: 21, snout: '#ff7e9c', ears: 'tri' },
    bunny:   { body: '#f2eef0', belly: '#ffffff', w: 21, h: 22, ears: 'long', inner: '#ffb0c2' },
    fox:     { body: '#ff8a2b', belly: '#fff1dd', w: 23, h: 22, ears: 'tri', tail: '#ff8a2b', tailTip: '#fff' },
    wolf:    { body: '#7d8796', belly: '#cfd6df', w: 26, h: 25, ears: 'tri', snout: '#5d6572' },
    unicorn: { body: '#fff6ff', belly: '#ffffff', w: 25, h: 25, ears: 'tri', horn: true, mane: true },
    cat:     { body: '#ffb04a', belly: '#fff0d2', w: 23, h: 22, ears: 'tri', stripes: '#e8892a', tail: '#ffb04a' },
    dragon:  { body: '#42c46b', belly: '#d8f7a8', w: 27, h: 26, ears: 'horn', wings: '#2fa357', tail: '#42c46b' },
    phoenix: { body: '#ff5a2b', belly: '#ffc24a', w: 26, h: 26, ears: 'flame', wings: '#ff9a2b', flame: true }
  };
  function isHero(t) { return t === 'hero' || t === 'hero_neo' || t === 'hero_gold'; }
  function fallbackPetStyle(type) {
    let hash = 0; for (let i = 0; i < type.length; i++) hash = (hash * 31 + type.charCodeAt(i)) >>> 0;
    const hue = hash % 360, sat = 58 + (hash % 20), light = 48 + (hash % 10);
    const f = n => { const k = (n + hue / 30) % 12; const a = sat / 100 * Math.min(light / 100, 1 - light / 100); return light / 100 - a * Math.max(-1, Math.min(k - 3, 9 - k, 1)); };
    const hex = [f(0), f(8), f(4)].map(v => Math.round(v * 255).toString(16).padStart(2, '0')).join('');
    return { body: '#' + hex, belly: '#fff4d8', w: 23 + (hash % 5), h: 21 + (hash % 4), ears: hash % 2 ? 'tri' : 'side', tail: '#' + hex, tailTip: '#fff' };
  }

  /* (x,y) — низ питомца, s — масштаб (1 ≈ 50 px), t — время для анимации. */
  function drawPet(c, type, x, y, s, t, opts) {
    opts = opts || {};
    const rar = opts.rarity ? RARITY[opts.rarity] : null;
    if (rar && rar.glow > 0 && opts.aura !== false) {
      const R = 46 * s * (0.8 + rar.glow * 0.5), gx = c.createRadialGradient(x, y - 24 * s, 2, x, y - 24 * s, R);
      gx.addColorStop(0, rar.color + 'aa'); gx.addColorStop(1, rar.color + '00');
      c.fillStyle = gx; c.beginPath(); c.arc(x, y - 24 * s, R, 0, TAU); c.fill();
    }
    const hop = opts.still ? 0 : Math.abs(Math.sin(t * 3 + (opts.phase || 0))) * 3 * s;
    if (isHero(type)) { drawHero(c, type, x, y - hop, 54 * s, t + (opts.phase || 0), { bob: opts.still ? 0 : undefined }); return; }
    const st = PET_STYLE[type] || fallbackPetStyle(type);
    const sq = opts.still ? 1 : 1 + Math.sin(t * 3 + (opts.phase || 0)) * 0.04;
    const w = st.w * s, h = st.h * s * sq, by = y - hop - h;
    c.save();
    // хвост и крылья позади
    if (st.wings) { c.fillStyle = st.wings; const f = Math.sin(t * 6) * 0.15; [-1, 1].forEach(sd => { c.save(); c.translate(x + sd * w * 0.8, by + h * 0.45); c.rotate(sd * (0.5 + f)); ell(c, 0, 0, w * 0.5, h * 0.3); c.fill(); c.restore(); }); }
    if (st.tail) { c.fillStyle = st.tail; c.save(); c.translate(x + w * 0.85, by + h * 0.75); c.rotate(-0.5 + Math.sin(t * 4) * 0.2); ell(c, 0, 0, w * 0.4, h * 0.22); c.fill(); if (st.tailTip) { c.fillStyle = st.tailTip; ell(c, w * 0.26, 0, w * 0.15, h * 0.17); c.fill(); } c.restore(); }
    // тело
    c.fillStyle = grad(c, x, by, x, by + h, [shade(st.body, 0.25), st.body, shade(st.body, -0.2)]);
    rr(c, x - w, by, w * 2, h, Math.min(w, h) * 0.72); c.fill(); outline(c, 2.2 * s);
    c.fillStyle = st.belly; ell(c, x, by + h * 0.72, w * 0.58, h * 0.24); c.fill();
    if (st.stripes) { c.strokeStyle = st.stripes; c.lineWidth = 2.2 * s; [-0.4, 0, 0.4].forEach(k => { c.beginPath(); c.moveTo(x + k * w, by + 1); c.lineTo(x + k * w * 0.9, by + h * 0.26); c.stroke(); }); }
    // уши/рога
    c.fillStyle = st.body;
    if (st.ears === 'tri') [-1, 1].forEach(sd => { c.beginPath(); c.moveTo(x + sd * w * 0.78, by + h * 0.22); c.lineTo(x + sd * w * 0.5, by - h * 0.28); c.lineTo(x + sd * w * 0.14, by + h * 0.08); c.closePath(); c.fill(); outline(c, 2 * s); });
    if (st.ears === 'long') [-1, 1].forEach(sd => { c.fillStyle = st.body; ell(c, x + sd * w * 0.42, by - h * 0.38, w * 0.2, h * 0.5); c.fill(); outline(c, 2 * s); c.fillStyle = st.inner; ell(c, x + sd * w * 0.42, by - h * 0.36, w * 0.09, h * 0.36); c.fill(); });
    if (st.ears === 'side') [-1, 1].forEach(sd => { c.fillStyle = st.body; c.save(); c.translate(x + sd * w * 0.95, by + h * 0.28); c.rotate(sd * 0.7); ell(c, 0, 0, w * 0.3, h * 0.13); c.fill(); outline(c, 2 * s); c.restore(); });
    if (st.ears === 'tuft') { c.fillStyle = '#ff9b2b'; for (let i = -1; i <= 1; i++) { c.beginPath(); c.arc(x + i * w * 0.2, by - 1 * s, w * 0.17, 0, TAU); c.fill(); } }
    if (st.ears === 'horn') [-1, 1].forEach(sd => { c.fillStyle = '#f6e7a8'; c.beginPath(); c.moveTo(x + sd * w * 0.62, by + h * 0.12); c.lineTo(x + sd * w * 0.5, by - h * 0.34); c.lineTo(x + sd * w * 0.3, by + h * 0.08); c.closePath(); c.fill(); outline(c, 2 * s); });
    if (st.ears === 'flame') for (let i = -1; i <= 1; i++) { c.fillStyle = i === 0 ? '#ffd24a' : '#ff7a2b'; c.beginPath(); c.moveTo(x + i * w * 0.4 - w * 0.14, by + 2); c.quadraticCurveTo(x + i * w * 0.4, by - h * (0.55 + 0.1 * Math.sin(t * 7 + i)), x + i * w * 0.4 + w * 0.14, by + 2); c.fill(); }
    if (st.horns) [-1, 1].forEach(sd => { c.fillStyle = st.horns; c.beginPath(); c.moveTo(x + sd * w * 0.3, by + 2); c.lineTo(x + sd * w * 0.42, by - h * 0.3); c.lineTo(x + sd * w * 0.12, by + 2); c.closePath(); c.fill(); outline(c, 1.8 * s); });
    if (st.horn) { c.fillStyle = grad(c, x, by - h * 0.6, x, by, ['#ffe86b', '#ff7ad9']); c.beginPath(); c.moveTo(x - w * 0.12, by + 3); c.lineTo(x, by - h * 0.6); c.lineTo(x + w * 0.12, by + 3); c.closePath(); c.fill(); outline(c, 1.8 * s); }
    if (st.mane) { ['#ff7ad9', '#7ad9ff', '#ffe86b'].forEach((col, i) => { c.fillStyle = col; ell(c, x - w * (0.78 - i * 0.04), by + h * (0.25 + i * 0.16), w * 0.2, h * 0.14); c.fill(); }); }
    // лицо
    const ey = by + h * 0.42, blink = (Math.sin(t * 0.9 + (opts.phase || 0) * 3) > 0.985) ? 0.15 : 1;
    [-1, 1].forEach(sd => {
      c.fillStyle = '#fff'; ell(c, x + sd * w * 0.38, ey, 4.3 * s, 5 * s * blink); c.fill();
      c.fillStyle = '#26190f'; ell(c, x + sd * w * 0.38 + (opts.look || 0), ey + 0.5 * s, 2.3 * s, 3 * s * blink); c.fill();
      c.fillStyle = '#fff'; ell(c, x + sd * w * 0.38 - 0.8 * s, ey - 1.2 * s, 0.9 * s, 0.9 * s); c.fill();
    });
    if (st.beak) { c.fillStyle = st.beak; c.beginPath(); c.moveTo(x - 4.5 * s, ey + 6 * s); c.lineTo(x + 4.5 * s, ey + 6 * s); c.lineTo(x, ey + 11 * s); c.closePath(); c.fill(); }
    else if (st.snout) { c.fillStyle = st.snout; ell(c, x, ey + 7 * s, 6 * s, 4.2 * s); c.fill(); c.fillStyle = 'rgba(60,20,30,.6)'; ell(c, x - 2 * s, ey + 7 * s, 0.9 * s, 1.3 * s); c.fill(); ell(c, x + 2 * s, ey + 7 * s, 0.9 * s, 1.3 * s); c.fill(); }
    else { c.strokeStyle = '#3a2417'; c.lineWidth = 1.6 * s; c.beginPath(); c.arc(x, ey + 6 * s, 3 * s, 0.15 * Math.PI, 0.85 * Math.PI); c.stroke(); }
    c.fillStyle = 'rgba(255,120,150,.35)'; [-1, 1].forEach(sd => { ell(c, x + sd * w * 0.62, ey + 6 * s, 3 * s, 2 * s); c.fill(); });
    c.restore();
  }

  /* ---------- деревья, камни, цветы, вода ---------- */
  const THEMES = [
    { grass: ['#7ed957', '#6fcf4f', '#8ee165'], tuft: '#4fae3a', leaf: ['#3fae4a', '#52c85a', '#2f8f3c'], trunk: '#8a5a32', path: '#e6c98e', pathEdge: '#c8a566', fogTint: '#0d2a14' },
    { grass: ['#5ec26b', '#52b862', '#6fd079'], tuft: '#2f9a4f', leaf: ['#e8892a', '#f7a73a', '#c96a1c'], trunk: '#7a4b2a', path: '#d8bd86', pathEdge: '#b99a5c', fogTint: '#0d2a14' },
    { grass: ['#cfd860', '#c4cf52', '#dde36f'], tuft: '#a3ad33', leaf: ['#f2c43a', '#ffd95a', '#d9a21f'], trunk: '#8c6a3a', path: '#efd9a0', pathEdge: '#cfb06a', fogTint: '#2a2208' }
  ];
  function drawTree(c, x, y, s, theme, seed) {
    const th = THEMES[theme], r = rng(seed || 1);
    shadow(c, x + 6 * s, y, 30 * s, 10 * s, 0.25);
    c.fillStyle = th.trunk; rr(c, x - 7 * s, y - 36 * s, 14 * s, 38 * s, 5 * s); c.fill(); outline(c, 2);
    const blobs = [[-18, -58, 26], [18, -58, 26], [0, -76, 30], [0, -50, 30]];
    blobs.forEach(([bx, by, br], i) => {
      c.fillStyle = th.leaf[(i + (seed || 0)) % 3]; c.beginPath(); c.arc(x + bx * s, y + by * s, br * s, 0, TAU); c.fill(); outline(c, 2.2);
    });
    c.fillStyle = 'rgba(255,255,255,.18)'; c.beginPath(); c.arc(x - 8 * s, y - 84 * s, 12 * s, 0, TAU); c.fill();
    if (theme === 1 && r() > 0.5) { c.fillStyle = '#ff5a3a'; [[-14, -60], [10, -70], [16, -48]].forEach(a => { c.beginPath(); c.arc(x + a[0] * s, y + a[1] * s, 3.2 * s, 0, TAU); c.fill(); }); }
  }
  function drawRock(c, x, y, s) {
    shadow(c, x, y + 2, 22 * s, 7 * s, 0.25);
    c.fillStyle = grad(c, x, y - 22 * s, x, y, ['#c8ccd2', '#8f959e']); c.beginPath(); c.moveTo(x - 20 * s, y); c.quadraticCurveTo(x - 24 * s, y - 20 * s, x - 6 * s, y - 24 * s); c.quadraticCurveTo(x + 18 * s, y - 28 * s, x + 22 * s, y); c.closePath(); c.fill(); outline(c, 2);
  }
  function drawFlower(c, x, y, col) {
    c.strokeStyle = '#3f9a3a'; c.lineWidth = 2; c.beginPath(); c.moveTo(x, y); c.lineTo(x, y - 9); c.stroke();
    c.fillStyle = col; for (let i = 0; i < 5; i++) { c.beginPath(); c.arc(x + Math.cos(i * 1.2566) * 3.2, y - 10 + Math.sin(i * 1.2566) * 3.2, 2.6, 0, TAU); c.fill(); }
    c.fillStyle = '#ffe14a'; c.beginPath(); c.arc(x, y - 10, 2, 0, TAU); c.fill();
  }
  function drawPond(c, x, y, rx, ry, t) {
    c.fillStyle = '#b9a06a'; ell(c, x, y + 4, rx + 8, ry + 8); c.fill();
    c.fillStyle = grad(c, x, y - ry, x, y + ry, ['#6fd3ff', '#3a9be0']); ell(c, x, y, rx, ry); c.fill(); outline(c, 3);
    c.strokeStyle = 'rgba(255,255,255,.5)'; c.lineWidth = 2;
    for (let i = 0; i < 3; i++) { c.beginPath(); c.ellipse(x - rx * 0.2 + i * 18, y - 4 + i * 6, 14 + (t ? Math.sin(t + i) * 2 : 0), 4, 0, 0, TAU); c.stroke(); }
    c.fillStyle = '#4fc15a'; [[-0.5, 0.2], [0.35, -0.3], [0.5, 0.35]].forEach(p => { ell(c, x + p[0] * rx, y + p[1] * ry, 11, 6); c.fill(); });
  }
  function drawFenceRow(c, x0, y, x1, th) {
    c.strokeStyle = '#a8723e'; c.lineWidth = 5; c.lineCap = 'round';
    c.beginPath(); c.moveTo(x0, y - 20); c.lineTo(x1, y - 20); c.moveTo(x0, y - 9); c.lineTo(x1, y - 9); c.stroke();
    for (let x = x0; x <= x1; x += 40) { c.fillStyle = '#c4894d'; rr(c, x - 5, y - 30, 10, 34, 3); c.fill(); outline(c, 1.8); }
  }

  /* ---------- грядка ---------- */
  function drawPlot(c, x, y, st) { // (x,y) — центр основания
    shadow(c, x, y + 38, 62, 12, 0.28);
    c.fillStyle = '#9a6535'; rr(c, x - 56, y - 38, 112, 82, 12); c.fill(); outline(c, 2.5);
    c.fillStyle = '#b57b43'; rr(c, x - 56, y - 38, 112, 70, 12); c.fill();
    c.fillStyle = grad(c, x, y - 32, x, y + 30, st && st.wet ? ['#6b4326', '#4d2f19'] : ['#7a4d2b', '#5d3820']); rr(c, x - 47, y - 30, 94, 56, 8); c.fill();
    c.strokeStyle = 'rgba(0,0,0,.18)'; c.lineWidth = 3;
    for (let i = -1; i <= 1; i++) { c.beginPath(); c.moveTo(x - 40, y + i * 17); c.lineTo(x + 40, y + i * 17); c.stroke(); }
    c.fillStyle = 'rgba(255,255,255,.1)'; rr(c, x - 47, y - 30, 94, 10, 6); c.fill();
  }
  function drawCrop(c, id, g, x, y, t, ready) {
    // На грядках растут только яйца: от маленького ростка до готового яйца.
    const k = 0.34 + 0.66 * Math.max(0, Math.min(1, g));
    const bob = Math.sin(t * 2.2) * (ready ? 1.5 : 3);
    [[-22,-5],[22,-5],[-22,15],[22,15]].forEach((p,i)=>{
      drawEgg(c,id,x+p[0],y+p[1]+bob,k*0.48,t+i*0.3,Math.sin(t*1.7+i)*0.04,ready?0:0);
    });
  }

  /* ---------- стойка для питомца ---------- */
  function drawStand(c, x, y, theme, locked) {
    const top = ['#8ed36a', '#f0a24a', '#ffd95a'][theme];
    shadow(c, x, y + 8, 50, 14, 0.3);
    c.fillStyle = grad(c, x - 40, y, x + 40, y, ['#a9a39a', '#d8d3c8', '#8f8a82']); rr(c, x - 40, y - 22, 80, 30, 9); c.fill(); outline(c, 2.5);
    c.fillStyle = shade(top, -0.1); ell(c, x, y - 22, 40, 15); c.fill(); outline(c, 2.5);
    c.fillStyle = top; ell(c, x, y - 25, 34, 11); c.fill();
    c.fillStyle = 'rgba(255,255,255,.35)'; ell(c, x - 8, y - 28, 14, 4); c.fill();
    c.fillStyle = '#f7d046'; c.beginPath(); c.arc(x, y - 4, 6, 0, TAU); c.fill(); outline(c, 1.6);
  }

  /* ---------- яйцо и инкубатор ---------- */
  const EGG = {
    meadow: ['#fff5d6', '#7ac6ff'], grove: ['#f3e0ff', '#b46bff'], peak: ['#fff0a8', '#ff9d1f'],
    blue_egg: ['#d9f3ff', '#3b9de0'], speckled_egg: ['#f4e3c4', '#9b6b42'], golden_egg: ['#fff0a6', '#e8a817'],
    rainbow_egg: ['#ffe0ee', '#9c62d8'], crystal_egg: ['#e2ffff', '#55c6cf'], moon_egg: ['#e4e5ff', '#6b75c9'],
    fire_egg: ['#ffd1a1', '#ef5a28'], ocean_egg: ['#c7f4ff', '#168bbd'], forest_egg: ['#d8f0c4', '#4d9a52'],
    candy_egg: ['#ffe0e8', '#ed6d9a'], star_egg: ['#fff5b8', '#e4b52a'], shadow_egg: ['#c9c2dc', '#55436e'],
    galaxy_egg: ['#d8c5ff', '#7847c5'], royal_egg: ['#ffe2bb', '#c17b24'], dragon_egg: ['#ffd0c7', '#bd3434'],
    sky: ['#e4f8ff', '#57b7ed'], ocean: ['#c7f4ff', '#168bbd'], lava: ['#ffd1a1', '#ef5a28'],
    crystal: ['#e2ffff', '#55c6cf'], shadow: ['#c9c2dc', '#55436e'], cosmic: ['#d8c5ff', '#7847c5']
  };
  const eggColorCache = {};
  function eggColors(kind) {
    if (EGG[kind]) return EGG[kind];
    if (!kind) return EGG.meadow;
    if (eggColorCache[kind]) return eggColorCache[kind];
    let hash = 0; for (let i = 0; i < kind.length; i++) hash = (hash * 31 + kind.charCodeAt(i)) >>> 0;
    const hsl = (h, s, l) => { const a = s * Math.min(l, 1 - l), f = n => { const k = (n + h / 30) % 12; return l - a * Math.max(-1, Math.min(k - 3, 9 - k, 1)); }; return '#' + [f(0), f(8), f(4)].map(v => Math.round(v * 255).toString(16).padStart(2, '0')).join(''); };
    return (eggColorCache[kind] = [hsl(hash % 360, 0.75, 0.9), hsl(hash % 360, 0.62, 0.48)]);
  }
  function drawEgg(c, kind, x, y, s, t, rot, crack) {
    const col = eggColors(kind);
    c.save(); c.translate(x, y); c.rotate(rot || 0); c.scale(s, s);
    c.fillStyle = grad(c, -20, -50, 20, 0, [shade(col[0], 0.3), col[0], shade(col[0], -0.15)]);
    c.beginPath(); c.moveTo(0, -52); c.bezierCurveTo(26, -52, 30, -8, 0, 0); c.bezierCurveTo(-30, -8, -26, -52, 0, -52); c.fill(); outline(c, 3);
    c.fillStyle = col[1];
    [[-10, -30, 5], [9, -22, 4], [-2, -42, 3.5], [4, -10, 3.4]].forEach(p => { c.beginPath(); c.arc(p[0], p[1], p[2], 0, TAU); c.fill(); });
    if (crack) { c.strokeStyle = '#3a2417'; c.lineWidth = 2.4; c.beginPath(); c.moveTo(-14, -30); c.lineTo(-6, -24); c.lineTo(-10, -16); c.lineTo(2, -20); c.lineTo(0, -8); c.stroke(); if (crack > 1) { c.beginPath(); c.moveTo(14, -34); c.lineTo(6, -28); c.lineTo(11, -20); c.stroke(); } }
    c.restore();
  }
  function drawEggMachine(c, x, y, kind, t, price, name) {
    shadow(c, x, y + 6, 66, 16, 0.3);
    c.fillStyle = '#8d5a31'; rr(c, x - 56, y - 70, 112, 74, 10); c.fill(); outline(c, 3);
    c.fillStyle = grad(c, x, y - 70, x, y, ['#b57b43', '#8d5a31']); rr(c, x - 52, y - 66, 104, 66, 8); c.fill();
    c.fillStyle = grad(c, x, y - 62, x, y - 14, ['#fff3c9', '#ffd77a']); rr(c, x - 36, y - 62, 72, 48, 24); c.fill(); outline(c, 2.5);
    drawEgg(c, kind, x, y - 16 + Math.sin(t * 2.4) * 1.5, 0.7, t, Math.sin(t * 3) * 0.05);
    const roofCol = { meadow: '#ff5a5a', grove: '#a65cff', peak: '#ffb31f' }[kind] || '#ff5a5a';
    c.fillStyle = roofCol; c.beginPath(); c.moveTo(x - 70, y - 66); c.lineTo(x, y - 112); c.lineTo(x + 70, y - 66); c.closePath(); c.fill(); outline(c, 3);
    c.fillStyle = 'rgba(255,255,255,.28)'; c.beginPath(); c.moveTo(x - 70, y - 66); c.lineTo(x, y - 112); c.lineTo(x, y - 66); c.closePath(); c.fill();
    c.fillStyle = '#5b3a1e'; rr(c, x - 40, y - 12, 80, 14, 5); c.fill();
    text(c, name || 'ЯЙЦО', x, y - 4, 10, '#ffe9b0');
  }

  /* ---------- рынок ---------- */
  function drawMarket(c, x, y, t) {
    shadow(c, x, y + 6, 72, 16, 0.3);
    c.fillStyle = '#9a6535'; rr(c, x - 60, y - 38, 120, 44, 8); c.fill(); outline(c, 3);
    c.fillStyle = '#c4894d'; rr(c, x - 60, y - 38, 120, 18, 8); c.fill();
    // ящики
    [[-38, '#ff7a1a'], [-8, '#ffd83a'], [22, '#ee2e4f']].forEach(a => { c.fillStyle = '#7d5230'; rr(c, x + a[0] - 12, y - 52, 26, 18, 4); c.fill(); outline(c, 1.8); c.fillStyle = a[1]; for (let i = 0; i < 3; i++) { c.beginPath(); c.arc(x + a[0] - 6 + i * 7, y - 54, 5, 0, TAU); c.fill(); } });
    // столбы + навес
    c.fillStyle = '#7d5230'; rr(c, x - 62, y - 92, 7, 58, 3); c.fill(); rr(c, x + 55, y - 92, 7, 58, 3); c.fill();
    for (let i = 0; i < 6; i++) { c.fillStyle = i % 2 ? '#fff6e8' : '#ff5a5a'; c.beginPath(); c.moveTo(x - 72 + i * 24, y - 92); c.lineTo(x - 48 + i * 24, y - 92); c.lineTo(x - 52 + i * 24, y - 70 + (i % 2 ? 0 : 0)); c.quadraticCurveTo(x - 60 + i * 24, y - 62, x - 68 + i * 24, y - 70); c.closePath(); c.fill(); }
    c.strokeStyle = 'rgba(40,24,12,.55)'; c.lineWidth = 2.5; c.beginPath(); c.moveTo(x - 72, y - 92); c.lineTo(x + 72, y - 92); c.stroke();
    text(c, 'РЫНОК', x, y - 104, 13, '#fff');
  }

  /* ---------- ворота зон ---------- */
  function drawGate(c, x, y, locked, price, t, nextName) {
    shadow(c, x, y + 6, 54, 12, 0.3);
    c.fillStyle = '#8d5a31'; rr(c, x - 54, y - 100, 14, 110, 4); c.fill(); outline(c, 2.5); rr(c, x + 40, y - 100, 14, 110, 4); c.fill(); outline(c, 2.5);
    c.fillStyle = '#a8723e'; rr(c, x - 54, y - 112, 108, 18, 6); c.fill(); outline(c, 2.5);
    if (locked) {
      c.fillStyle = '#b57b43'; for (let i = 0; i < 4; i++) { rr(c, x - 38 + i * 21, y - 84, 11, 88, 3); c.fill(); outline(c, 1.8); }
      c.fillStyle = '#6a6f78'; c.strokeStyle = '#444'; c.lineWidth = 3; rr(c, x - 12, y - 50, 24, 20, 4); c.fill(); outline(c, 2);
      c.beginPath(); c.arc(x, y - 52, 8, Math.PI, 0); c.stroke();
      text(c, price, x, y - 124, 13, '#ffe27a');
    } else { text(c, nextName || '', x, y - 124, 12, '#fff'); }
  }

  /* ---------- доска почёта ---------- */
  function drawBoard(c, x, y) {
    shadow(c, x, y + 4, 40, 10, 0.3);
    c.fillStyle = '#7d5230'; rr(c, x - 5, y - 40, 10, 44, 3); c.fill(); rr(c, x - 34, y - 90, 68, 56, 8); c.fill(); outline(c, 3);
    c.fillStyle = '#f1d9a5'; rr(c, x - 29, y - 85, 58, 46, 5); c.fill();
    c.fillStyle = '#c9a15f'; for (let i = 0; i < 3; i++) { rr(c, x - 22, y - 78 + i * 12, 44 - i * 8, 5, 2); c.fill(); }
    text(c, 'ТОП', x, y - 98, 12, '#ffe27a');
  }

  /* ---------- UI-спрайты ---------- */
  function drawCoin(c, x, y, r) {
    c.fillStyle = '#e8a817'; c.beginPath(); c.arc(x, y, r, 0, TAU); c.fill();
    c.fillStyle = grad(c, x, y - r, x, y + r, ['#ffe680', '#ffc233']); c.beginPath(); c.arc(x, y, r * 0.86, 0, TAU); c.fill();
    c.strokeStyle = '#d18f0d'; c.lineWidth = Math.max(1, r * 0.14); c.beginPath(); c.arc(x, y, r * 0.58, 0, TAU); c.stroke();
  }
  /* Мини-картинка для DOM (data URL) */
  function petIcon(type, rarity, size) {
    const c = document.createElement('canvas'); c.width = size; c.height = size; const x = c.getContext('2d');
    drawPet(x, type, size / 2, size * 0.92, size / 60, 0, { rarity, still: true, aura: true });
    return c.toDataURL();
  }
  function cropIcon(id, size) {
    const c = document.createElement('canvas'); c.width = size; c.height = size; const x = c.getContext('2d');
    x.translate(size / 2, size * 0.62); x.scale(size / 92, size / 92);
    drawCrop(x, id, 1, 0, 0, 0, true); // четыре куста = «грядка» в миниатюре
    return c.toDataURL();
  }

  window.Art = { RARITY, CROP_COLORS, eggColors, THEMES, rng, rr, ell, shade, shadow, grad, outline, text, loadHero, hero, drawHero, drawPet, isHero,
    drawTree, drawRock, drawFlower, drawPond, drawFenceRow, drawPlot, drawCrop, drawStand, drawEgg, drawEggMachine, drawMarket, drawGate, drawBoard, drawCoin, petIcon, cropIcon };
})();
