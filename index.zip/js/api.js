/* Лёгкий клиент Supabase без внешних зависимостей: Auth (GoTrue), RPC (PostgREST), Realtime (Phoenix).
   В клиенте используется ТОЛЬКО публичный (anon/publishable) ключ. service_role здесь не нужен и не должен появляться. */
(function () {
  'use strict';
  const cfg = window.FARM_CONFIG || {};
  const STORE = 'farm.session.v1';

  class ApiError extends Error { constructor(code, message) { super(message || code); this.code = code; } }
  class NetError extends Error { constructor() { super('network'); this.code = 'network'; } }

  const RU = {
    network: 'Нет связи с сервером. Проверь интернет.',
    not_authenticated: 'Нужно войти в аккаунт.',
    no_profile: 'Профиль не найден. Войди заново.',
    no_save: 'Сохранение не найдено.',
    bad_username: 'Ник: 3–18 символов, латиница, цифры и _, первая буква — латинская.',
    name_taken: 'Этот ник уже занят.',
    name_reserved: 'Этот ник зарезервирован. Выбери другой.',
    not_enough_coins: 'Не хватает монет.',
    zone_locked: 'Эта зона ещё закрыта.',
    plot_busy: 'Грядка уже занята.',
    plot_empty: 'Грядка пуста.',
    not_ready: 'Ещё не созрело.',
    nothing_to_sell: 'Нечего продавать.',
    inventory_full: 'Рюкзак переполнен (60 питомцев). Продай лишних.',
    egg_out_of_stock: 'Это яйцо закончилось в общем стоке. Подожди пополнения.',
    crop_out_of_stock: 'Это посадочное яйцо закончилось. Попробуй другое или дождись пополнения.',
    bad_amount: 'Количество должно быть от 1 до 10 000.',
    stand_busy: 'Стойка занята.',
    stand_empty: 'На стойке никого нет.',
    already_placed: 'Питомец уже на стойке.',
    not_placed: 'Питомец не на стойке.',
    all_unlocked: 'Все зоны уже открыты.',
    forbidden: 'Недостаточно прав.',
    bad_message: 'Объявление: от 1 до 240 символов.',
    bad_duration: 'Недопустимая длительность.',
    bad_mult: 'Множитель: от 1 до 100.',
    bad_value: 'Недопустимое значение.',
    egg_would_be_empty: 'В яйце должен остаться питомец с ненулевым шансом.',
    invalid_credentials: 'Неверный ник или пароль.',
    owner_key_required: 'Для первого входа владельца нужен одноразовый ключ.',
    owner_key_invalid: 'Ключ владельца неверный или уже использован.',
    auth_service_unavailable: 'Сервис входа временно недоступен. Попробуй ещё раз.',
    weak_password: 'Слишком простой пароль (минимум 6 символов).',
    validation_failed: 'Проверь введённые данные.',
    not_deployed: 'На сервере не применена миграция 0003 (продажа питомца / удаление объявления). Выполни её в SQL Editor.',
    config_missing: 'Не задан ключ Supabase (js/config.js).'
  };
  function human(code, fallback) { return RU[code] || fallback || ('Ошибка: ' + code); }

  let session = null;
  try { session = JSON.parse(localStorage.getItem(STORE) || 'null'); } catch (e) { session = null; }
  const authListeners = new Set();
  function emitAuth() { authListeners.forEach(f => { try { f(session); } catch (e) { console.error(e); } }); }
  function save() {
    try { session ? localStorage.setItem(STORE, JSON.stringify(session)) : localStorage.removeItem(STORE); } catch (e) { /* приватный режим */ }
  }

  function configured() { return !!(cfg.SUPABASE_URL && cfg.SUPABASE_ANON_KEY); }

  async function http(path, { method = 'POST', body, token, timeout = 20000 } = {}) {
    if (!configured()) throw new ApiError('config_missing');
    const headers = { apikey: cfg.SUPABASE_ANON_KEY, 'Content-Type': 'application/json', Authorization: 'Bearer ' + (token || cfg.SUPABASE_ANON_KEY) };
    const payload = body === undefined ? undefined : JSON.stringify(body);
    let responseText = '', status = 0;
    // Некоторые старые браузеры Android на планшетах не поддерживают AbortController.
    // В таком случае выполняем запрос без signal, а при сбое fetch пробуем XHR.
    try {
      if (typeof fetch === 'function') {
        const ctl = typeof AbortController !== 'undefined' ? new AbortController() : null;
        const to = ctl ? setTimeout(() => ctl.abort(), timeout) : null;
        try {
          const res = await fetch(cfg.SUPABASE_URL + path, {
            method, mode: 'cors', credentials: 'omit', cache: 'no-store',
            ...(ctl ? { signal: ctl.signal } : {}), headers, body: payload
          });
          status = res.status;
          responseText = await res.text();
        } finally { if (to) clearTimeout(to); }
      } else throw new Error('fetch_unavailable');
    } catch (fetchError) {
      if (typeof XMLHttpRequest !== 'function') throw new NetError();
      try {
        const xhr = await new Promise((resolve, reject) => {
          const x = new XMLHttpRequest();
          x.open(method, cfg.SUPABASE_URL + path, true);
          x.timeout = timeout;
          Object.keys(headers).forEach(k => x.setRequestHeader(k, headers[k]));
          x.onload = () => resolve(x);
          x.onerror = () => reject(new Error('xhr_network'));
          x.ontimeout = () => reject(new Error('xhr_timeout'));
          x.onabort = () => reject(new Error('xhr_abort'));
          x.send(payload === undefined ? null : payload);
        });
        status = xhr.status;
        responseText = xhr.responseText || '';
      } catch (xhrError) { throw new NetError(); }
    }
    const res = { ok: status >= 200 && status < 300, status };
    let data = null;
    const text = responseText;
    if (text) { try { data = JSON.parse(text); } catch (e) { data = { message: text }; } }
    if (!res.ok) {
      const code = (data && (data.error_code || data.code && typeof data.code === 'string' && !/^\d|^P\d|^PGRST|^42/.test(data.code) && data.code)) ||
        (data && data.message) || ('http_' + res.status);
      const finalCode = data && typeof data.code === 'string' && /^PGRST20[0-9]/.test(data.code) ? 'not_deployed' : String(code).trim();
      const err = new ApiError(finalCode, data && (data.msg || data.message || data.error_description));
      err.status = res.status;
      err.raw = data;
      throw err;
    }
    return data;
  }

  function setSession(d) {
    session = {
      access_token: d.access_token, refresh_token: d.refresh_token,
      expires_at: d.expires_at || Math.floor(Date.now() / 1000) + (d.expires_in || 3600),
      user: d.user ? { id: d.user.id } : (session && session.user)
    };
    save();
  }

  let refreshing = null;
  function refresh() {
    if (!session || !session.refresh_token) return Promise.reject(new ApiError('not_authenticated'));
    if (refreshing) return refreshing;
    refreshing = http('/auth/v1/token?grant_type=refresh_token', { body: { refresh_token: session.refresh_token } })
      .then(d => { setSession(d); return session; })
      .catch(e => { if (e.code !== 'network') { session = null; save(); emitAuth(); } throw e; })
      .finally(() => { refreshing = null; });
    return refreshing;
  }

  async function token() {
    if (!session) throw new ApiError('not_authenticated');
    if (session.expires_at - 45 < Date.now() / 1000) await refresh();
    return session.access_token;
  }

  const Api = {
    configured, human, ApiError, NetError,
    get user() { return session && session.user; },
    get hasSession() { return !!session; },
    onAuth(f) { authListeners.add(f); return () => authListeners.delete(f); },

    async signUpUsername(username, password, ownerKey) {
      const body = { action: 'signup', username, password };
      if (ownerKey) body.owner_key = ownerKey;
      const d = await http('/functions/v1/farm-auth', { body });
      if (!d || !d.access_token) throw new ApiError('auth_service_unavailable');
      setSession(d); emitAuth();
    },
    async signInUsername(username, password) {
      const d = await http('/functions/v1/farm-auth', { body: { action: 'login', username, password } });
      if (!d || !d.access_token) throw new ApiError('auth_service_unavailable');
      setSession(d); emitAuth();
    },
    async signOut() {
      const t = session && session.access_token;
      session = null; save(); emitAuth();
      if (t) { try { await http('/auth/v1/logout', { token: t, timeout: 5000 }); } catch (e) { /* локальный выход уже выполнен */ } }
    },

    async rpc(name, args) {
      for (let attempt = 0; ; attempt++) {
        const t = await token();
        try { return await http('/rest/v1/rpc/' + name, { body: args || {}, token: t }); }
        catch (e) {
          const expired = e.status === 401 && attempt === 0;
          if (expired) { await refresh(); continue; }
          throw e;
        }
      }
    },

    /* Realtime: «толчок» при изменении объявлений/событий. Данные всё равно берутся через farm_feed(). */
    realtime(onNudge, onStatus) {
      let ws = null, hb = null, closed = false, tries = 0, ref = 1, timer = null;
      const url = cfg.SUPABASE_URL.replace(/^http/, 'ws') + '/realtime/v1/websocket?apikey=' + encodeURIComponent(cfg.SUPABASE_ANON_KEY) + '&vsn=1.0.0';
      function send(topic, event, payload) { try { ws.send(JSON.stringify({ topic, event, payload, ref: String(ref++) })); } catch (e) { /* закрыт */ } }
      async function open() {
        if (closed) return;
        let tk; try { tk = await token(); } catch (e) { return schedule(); }
        try { ws = new WebSocket(url); } catch (e) { return schedule(); }
        ws.onopen = () => {
          tries = 0;
          send('realtime:farm-feed', 'phx_join', {
            config: {
              broadcast: { self: false }, presence: { key: '' }, private: false,
              postgres_changes: [
                { event: '*', schema: 'public', table: 'farm_announcements' },
                { event: '*', schema: 'public', table: 'farm_events' }
              ]
            },
            access_token: tk
          });
          hb = setInterval(() => send('phoenix', 'heartbeat', {}), 25000);
          onStatus && onStatus(true);
        };
        ws.onmessage = ev => {
          let m; try { m = JSON.parse(ev.data); } catch (e) { return; }
          if (m.event === 'postgres_changes') onNudge();
        };
        ws.onclose = () => { clearInterval(hb); onStatus && onStatus(false); schedule(); };
        ws.onerror = () => { try { ws.close(); } catch (e) { /* уже закрыт */ } };
      }
      function schedule() { if (closed) return; clearTimeout(timer); timer = setTimeout(open, Math.min(30000, 1500 * Math.pow(2, tries++))); }
      open();
      return () => { closed = true; clearInterval(hb); clearTimeout(timer); try { ws && ws.close(); } catch (e) { /* ок */ } };
    }
  };
  window.Api = Api;
})();
