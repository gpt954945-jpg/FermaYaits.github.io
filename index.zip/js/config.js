/* Публичные настройки Supabase (проект ferma-yaits-global). Здесь допустимы ТОЛЬКО URL проекта и публичный anon-ключ.
   Ключ service_role сюда вставлять нельзя. Доступ к данным защищён RLS и серверными функциями. */
window.FARM_CONFIG = {
  SUPABASE_URL: 'https://kuxlahvexadsaeojezgs.supabase.co',
  SUPABASE_ANON_KEY: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imt1eGxhaHZleGFkc2Flb2plemdzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTM0OTM4MTYsImV4cCI6MjEwOTA2OTgxNn0.RZSs0-BesYe8qALGSIhdB32u0FaYprPMMFNDaXsffeg'
};
