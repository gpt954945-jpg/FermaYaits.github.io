/* Интерфейс: HUD, окна, вылупление, объявления, админ-панель. Весь пользовательский текст вставляется через textContent. */
(function () {
  'use strict';
  const $ = id => document.getElementById(id), G = window.Game, A = window.Art, fmt = G.fmt;
  const UI = window.UI = {};

  function h(tag, props) {
    const e = document.createElement(tag);
    for (const k in (props || {})) {
      const v = props[k]; if (v == null || v === false) continue;
      if (k === 'class') e.className = v; else if (k === 'text') e.textContent = v; else if (k === 'style') e.style.cssText = v;
      else if (k.startsWith('on')) e.addEventListener(k.slice(2), v); else if (k === 'value') e.value = v; else e.setAttribute(k, v === true ? '' : v);
    }
    for (let i = 2; i < arguments.length; i++) [].concat(arguments[i]).forEach(c => { if (c != null && c !== false) e.append(c.nodeType ? c : document.createTextNode(String(c))); });
    return e;
  }
  UI.h = h;

  function eggPicture(id, size) {
    const c = document.createElement('canvas'); c.width = c.height = size || 88;
    const x = c.getContext('2d');
    A.drawEgg(x, id, c.width / 2, c.height * .78, (c.width / 100) * .78, 0, 0);
    c.className = 'eggPicture'; c.setAttribute('aria-label', 'Яйцо ' + id); return c;
  }

  /* ---------- звук ---------- */
  let ac = null, muted = false;
  try { muted = localStorage.getItem('farm.mute') === '1'; } catch (e) { /* нет storage */ }
  function tone(f, d, type, vol, to, delay) {
    if (muted) return; try {
      ac = ac || new (window.AudioContext || window.webkitAudioContext)(); if (ac.state === 'suspended') ac.resume();
      const t0 = ac.currentTime + (delay || 0), o = ac.createOscillator(), g = ac.createGain();
      o.type = type || 'sine'; o.frequency.setValueAtTime(f, t0); if (to) o.frequency.exponentialRampToValueAtTime(to, t0 + d);
      g.gain.setValueAtTime(vol || 0.06, t0); g.gain.exponentialRampToValueAtTime(0.0001, t0 + d); o.connect(g); g.connect(ac.destination); o.start(t0); o.stop(t0 + d + 0.02);
    } catch (e) { /* звук недоступен */ }
  }
  const SFX = {
    coin: () => { tone(988, .09, 'square', .035); tone(1319, .16, 'square', .035, null, .07); },
    plant: () => tone(260, .12, 'triangle', .09, 130), harvest: () => tone(520, .12, 'triangle', .09, 880),
    pop: () => tone(600, .08, 'sine', .08, 900), egg: () => { tone(200, .12, 'triangle', .08, 150); tone(220, .12, 'triangle', .08, 160, .15); },
    hatch: () => [523, 659, 784, 1047].forEach((f, i) => tone(f, .18, 'triangle', .07, null, i * .08)),
    rare: () => [523, 659, 784, 1047, 1319, 1568].forEach((f, i) => tone(f, .26, 'square', .045, null, i * .09)),
    unlock: () => [392, 523, 659, 784].forEach((f, i) => tone(f, .22, 'triangle', .08, null, i * .1)), err: () => tone(160, .18, 'sawtooth', .05, 100)
  };
  UI.sfx = n => { try { SFX[n] && SFX[n](); } catch (e) { /* ок */ } };
  function syncSoundBtn() { $('bSound').classList.toggle('off', muted); }
  $('bSound').onclick = () => { muted = !muted; try { localStorage.setItem('farm.mute', muted ? '1' : '0'); } catch (e) { /* ок */ } syncSoundBtn(); if (muted) stopSkeletonMusic(); else { UI.sfx('pop'); if (G.events.some(e => e.kind === 'skeleton')) startSkeletonMusic(); } };
  syncSoundBtn();

  // Настройки графики. Обычный режим не ограничивает качество; Potato Mode включается вручную.
  $('bSettings').onclick = () => {
    const body = h('div');
    const potato = h('input', { type: 'checkbox' }); potato.checked = !!G.potatoMode;
    const row = h('label', { class: 'settingToggle' }, potato, h('span', null,
      h('b', { text: '🥔 Potato Mode' }),
      h('small', { text: 'Уменьшает фоновые частицы и эффекты. Не скрывает постройки, яйца, грядки и кнопки.' })
    ));
    const status = h('p', { class: 'sm', text: G.potatoMode ? '🥔 Экономия включена: меньше частиц, мир и управление целы.' : 'Обычный режим: все эффекты и детали мира.' });
    potato.addEventListener('change', () => {
      G.setPotatoMode(potato.checked);
      status.textContent = G.potatoMode ? 'Potato Mode включён. Изменения применяются сразу, управление не меняется.' : 'Обычный режим включён. Полная графика восстановлена.';
      UI.toast(G.potatoMode ? '🥔 Potato Mode включён' : 'Обычная графика включена', 'ok');
    });
    body.append(h('div', { class: 'panel' }, h('h4', { text: 'Графика' }), row, status),
      h('div', { class: 'panel' }, h('h4', { text: 'Обучение' }), h('p', { class: 'sm', text: 'Можно заново пройти подсказки со стрелками и подсветкой кнопок.' }), h('button', { class: 'btn gold', text: 'Пройти обучение заново', onclick: () => { UI.closeModal(); UI.startTutorial(true); } })),
      h('div', { class: 'panel' }, h('h4', { text: 'Звук' }), h('p', { text: muted ? 'Звук выключен' : 'Звук включён' }), h('button', { class: 'btn', text: muted ? 'Включить звук' : 'Выключить звук', onclick: () => { $('bSound').click(); UI.closeModal(); UI.toast(muted ? 'Звук выключен' : 'Звук включён'); } })));
    UI.openModal('Настройки', body, { wide: false });
  };

  /* ---------- интерактивное обучение с подсветкой и указателем ---------- */
  const TUTORIAL_STEPS = [
    { title: 'Двигай персонажа', text: 'Потяни круглый джойстик влево или вправо. Персонаж пойдёт за пальцем.', selector: '#joy', pointer: 'ДВИГАЙ ЗДЕСЬ' },
    { title: 'Найди сток яиц', text: 'Подойди к стенду «Сток яиц», чтобы купить инкубационные яйца.', world: 'stock' },
    { title: 'Найди подсвеченную грядку', text: 'Подойди к этой грядке. Жёлтая пунктирная метка показывает нужное место.', world: 'plot' },
    { title: 'Посади и собери', text: 'Когда окажешься рядом с грядкой, появится большая кнопка действия. Нажми её, а после созревания нажми ещё раз, чтобы собрать.', selector: '#prompt', pointer: 'КНОПКА ДЕЙСТВИЯ', world: 'plot' },
    { title: 'Продай урожай', text: 'Иди к рынку с прилавком. Подойди близко и нажми кнопку действия — получишь монеты.', world: 'market' },
    { title: 'Открой питомца', text: 'У стенда яиц покупаются инкубационные яйца. Каждое яйцо может выдать разных питомцев и редкости.', world: 'stock' },
    { title: 'Поставь питомца на стойку', text: 'Открой рюкзак, выбери питомца и поставь его на свободную стойку. Питомец будет приносить монеты.', selector: '#bBag', pointer: 'ОТКРОЙ РЮКЗАК' },
    { title: 'Смотри прогресс', text: 'В таблице лидеров можно сравнить монеты и достижения игроков. Настройки и повтор обучения находятся в кнопке с шестерёнкой.', selector: '#bTop', pointer: 'ЛИДЕРЫ' }
  ];
  UI.startTutorial = function (force) {
    if (G.mode !== 'play') return;
    if (UI._tutStop) { UI._tutStop(); UI._tutStop = null; }
    try { if (!force && localStorage.getItem('farm.tutorial.v2') === 'done') return; } catch (e) {}
    let index = 0;
    const root = $('tutorial'); root.hidden = false; root.className = 'tutorialOverlay';
    const card = h('div', { class: 'tutorialCard' });
    const count = h('div', { class: 'tutorialCount' });
    const title = h('h3'); const desc = h('p');
    const visual = h('div', { class: 'tutorialVisual', text: '👆 Смотри на жёлтую подсветку' });
    const back = h('button', { class: 'btn', text: 'Назад' });
    const next = h('button', { class: 'btn gold', text: 'Дальше' });
    const skip = h('button', { class: 'tutorialSkip', text: 'Пропустить обучение' });
    const actions = h('div', { class: 'tutorialActions' }, back, next);
    const pointer = h('div', { class: 'tutorialPointer', text: '⬇ НАЖМИ ЗДЕСЬ' });
    card.append(count, title, desc, visual, actions, skip);
    root.replaceChildren(pointer, card);
    function placeCard() { // карточка обучения не должна заходить на левый блок HUD
      const r = $('tl').getBoundingClientRect();
      root.style.setProperty('--tut-top', Math.ceil(r.bottom + 10) + 'px'); root.style.setProperty('--tut-left', Math.ceil(r.right + 12) + 'px');
    }
    document.documentElement.classList.add('tutorial-on'); UI._tutPlace = placeCard;
    function clearTarget() { document.querySelectorAll('.tutTarget').forEach(el => el.classList.remove('tutTarget')); G.tutorialWorld = null; pointer.hidden = true; }
    function finish() {
      clearTarget(); root.hidden = true; root.replaceChildren(); document.documentElement.classList.remove('tutorial-on'); UI._tutPlace = null;
      try { localStorage.setItem('farm.tutorial.v2', 'done'); } catch (e) {}
      UI.toast('Обучение пройдено! Теперь ты знаешь основы 🥚', 'ok');
    }
    function paint() {
      clearTarget(); placeCard(); const step = TUTORIAL_STEPS[index];
      count.textContent = 'ШАГ ' + (index + 1) + ' / ' + TUTORIAL_STEPS.length;
      title.textContent = step.title; desc.textContent = (step.selector === '#joy' && $('joy').hidden) ? 'Двигай персонажа стрелками или WASD, либо кликай по карте — он дойдёт сам.' : step.text;
      visual.textContent = step.world ? '🟡 Ищи жёлтую метку на карте' : '👆 Подсветка показывает нужную кнопку';
      back.disabled = index === 0; next.textContent = index === TUTORIAL_STEPS.length - 1 ? 'Завершить' : 'Дальше';
      if (step.selector) {
        const el = document.querySelector(step.selector);
        if (el && !el.hidden) {
          el.classList.add('tutTarget');
          if (step.pointer) {
            const r = el.getBoundingClientRect();
            pointer.textContent = '⬇ ' + step.pointer;
            pointer.style.left = Math.max(90, Math.min(window.innerWidth - 90, r.left + r.width / 2)) + 'px';
            pointer.style.top = Math.max(52, Math.min(window.innerHeight - 58, r.top - 46)) + 'px';
            pointer.hidden = false;
          }
        }
      }
      if (step.world) {
        const kind = step.world;
        const obj = kind === 'plot' ? G.objs.find(o => o.kind === 'plot' && o.zone === 0) : kind === 'market' ? G.objs.find(o => o.kind === 'market' && o.zone === 0) : G.objs.find(o => o.kind === 'stock' && o.zone === 0);
        if (obj) G.tutorialWorld = { x: obj.x, y: obj.y };
      }
    }
    back.onclick = () => { index = Math.max(0, index - 1); paint(); };
    window.addEventListener('resize', paint, { passive: true });
    UI._tutStop = () => { UI._tutPlace = null; window.removeEventListener('resize', paint); document.documentElement.classList.remove('tutorial-on'); };
    const oldFinish = finish;
    function cleanupFinish() { window.removeEventListener('resize', paint); oldFinish(); }
    next.onclick = () => { if (index >= TUTORIAL_STEPS.length - 1) return cleanupFinish(); index++; paint(); };
    skip.onclick = cleanupFinish;
    paint();
  };

  /* ---------- уведомления и связь ---------- */
  const recentToasts = new Map();
  UI.toast = function (msg, type) {
    const text = String(msg || '').trim(); if (!text) return;
    const key = (type || '') + ':' + text.replace(/\s+/g, ' ').toLocaleLowerCase(); const now = Date.now();
    if (recentToasts.has(key) && now - recentToasts.get(key) < 60000) return;
    recentToasts.set(key, now);
    for (const [k, at] of recentToasts) if (now - at > 60000) recentToasts.delete(k);
    const box = $('toasts'); const t = h('div', { class: 'toast ' + (type || ''), text }); box.append(t);
    while (box.children.length > 1) box.firstChild.remove();
    setTimeout(() => { t.style.transition = 'opacity .3s'; t.style.opacity = 0; setTimeout(() => t.remove(), 320); }, 2600);
    if (type === 'err' || type === 'warn') UI.sfx('err');
  };
  UI.shake = function () { const c = $('coinChip'); c.classList.remove('shake'); void c.offsetWidth; c.classList.add('shake'); };
  let retry = null;
  UI.online = function (on) {
    $('netbar').hidden = on;
    if (!on && !retry) retry = setInterval(() => G.sync(), 4000);
    if (on && retry) { clearInterval(retry); retry = null; }
  };
  UI.sessionLost = function () { window.Main && Main.showAuth('Сессия истекла. Войди снова.'); };

  /* ---------- HUD ---------- */
  let shownCoins = 0, tween = null;
  G.upgradeLevels = {income:0,speed:0,sell:0}; let upgradesLoaded=false, upgradesLoading=false;
  let upgradesRetryAt=0;
  async function loadUpgradeLevels(){
    // При ошибке не повторяем сразу: раньше UI.refresh() снова вызывал загрузку в бесконечном цикле и вешал вкладку.
    if(upgradesLoaded||upgradesLoading||!G.state||Date.now()<upgradesRetryAt)return; upgradesLoading=true;
    try{const u=await Api.rpc('farm_upgrades_get'); G.upgradeLevels={income:+u.income||0,speed:+u.speed||0,sell:+u.sell||0}; if(G.state&&u.coins!=null)G.state.coins=+u.coins; upgradesLoaded=true;}
    catch(e){upgradesRetryAt=Date.now()+15000;}
    finally{upgradesLoading=false; if(upgradesLoaded&&G.state)UI.refresh();}
  }
  function setCoins(v) {
    if (tween) cancelAnimationFrame(tween);
    const from = shownCoins, t0 = performance.now(), el = $('coins');
    
    if (v > from) { const chip = $('coinChip'); chip.classList.remove('bump'); void chip.offsetWidth; chip.classList.add('bump'); }
    const step = now => { const k = Math.min(1, (now - t0) / 350); shownCoins = from + (v - from) * (1 - Math.pow(1 - k, 3)); el.textContent = fmt(shownCoins); if (k < 1) tween = requestAnimationFrame(step); else { shownCoins = v; el.textContent = fmt(v); } };
    tween = requestAnimationFrame(step);
  }
  let seedKey = '';
  UI.refresh = function () {
    const s = G.state; if (!s) return;
    loadUpgradeLevels();
    if (Math.floor(shownCoins) !== s.coins) setCoins(s.coins);
    const n = G.cropCount(); const cc = $('cropChip'); cc.hidden = !n; if (n) cc.textContent = 'Яйца: ' + n + ' · +' + fmt(G.cropValue());
    const free = s.pets.filter(p => p.stand == null).length; $('bagCount').textContent = free || '';
    const canAdmin = s.role === 'GLOBAL_ADMIN';
    $('bAdmin').hidden = !canAdmin;
    const sideAdmin=$('sideAdmin'); if(sideAdmin) sideAdmin.hidden=!canAdmin;
    const up=$('bUpgrades'); if(up) up.hidden=false;
  };
  let lastP = '';
  UI.setPrompt = function (d) {
    const p = $('prompt'); const key = d ? [d.kind, d.text, d.sub, d.ok, d.passive].join('|') : '';
    if (key === lastP) return; lastP = key;
    if (!d) { p.hidden = true; return; }
    p.hidden = false; p.querySelector('.pt').textContent = d.text; p.querySelector('.ps').textContent = d.sub || '';
    p.className = 'prompt' + (d.passive ? ' passive' : d.ok ? ' go' : ' off');
  };
  $('prompt').addEventListener('click', () => G.interact());
  $('prompt').addEventListener('pointerdown', e => e.stopPropagation());

  // таймер: зона, события, обновление подсказок (время роста тикает)
  setInterval(() => {
    if (G.mode !== 'play' || !G.state) return;
    const zi = Math.min(2, Math.floor(G.player.x / G.ZW)); $('zoneChip').textContent = G.ZONE_NAMES[zi];
    renderEvents(); if (UI._tutPlace) UI._tutPlace();
    lastP = ''; // принудительно обновить текст подсказки (таймеры)
  }, 1000);
  // Небольшая синхронизация таблички на физическом стенде: не обращаемся к серверу каждый кадр.
  setInterval(async () => {
    if (G.mode !== 'play' || !G.state) return;
    try { G.stockDisplay = (await Api.rpc('farm_global_stock') || []).filter(e => +e.quantity > 0).slice(0, 4); } catch (e) { /* табличка покажет прошлый ассортимент */ }
  }, 15000);
  function renderEvents() {
    const box = $('events'); const now = Date.now(); G.events = G.events.filter(e => e.expireAt > now);
    const seen = new Set();
    G.events.forEach(e => {
      const key = 'ev' + e.id; seen.add(key);
      let b = [...box.children].find(c => c.dataset.k === key);
      if (!b) { b = h('button', { class: 'ev eventIcon ' + e.kind, type: 'button', 'data-k': key, onclick: () => { const cur = G.events.find(x => 'ev' + x.id === key); if (cur) showEvent(cur); } }, h('b', { text: EVENT_ICONS[e.kind] || '✨' }), h('small')); box.append(b); }
      const left = tm((e.expireAt - now) / 1000); b.title = e.title + ' · ' + left; b.lastChild.textContent = left;
    });
    [...box.children].forEach(c => { if (!seen.has(c.dataset.k)) c.remove(); });
    if (G.events.some(e=>e.kind==='skeleton')) startSkeletonMusic(); else stopSkeletonMusic();
  }
  function tm(sec) { sec = Math.max(0, Math.ceil(sec)); const m = Math.floor(sec / 60), s = sec % 60; return m + ':' + String(s).padStart(2, '0'); }
  function showEvent(e) {
    const body=h('div',{class:'panel eventDetails'},h('div',{class:'eventBig',text:EVENT_ICONS[e.kind]||'✨'}),h('h3',{text:e.title}),h('p',{text:e.kind==='skeleton'?'Скелеты напали на ферму! Участвуй в событии, пока таймер не закончился.':'Глобальное событие активно для всех игроков.'}),h('b',{text:'Осталось: '+tm((e.expireAt-Date.now())/1000)}),h('p',{text:e.kind==='skeleton'?'Музыка события включается автоматически.':'Множитель: ×'+e.mult}));
    UI.openModal('Событие',body,{wide:false});
  }
  function startSkeletonMusic(){
    if (muted) return;
    try {
      if (!skeletonAudio) { skeletonAudio = new Audio('assets/skeleton-event.mp3'); skeletonAudio.loop = true; skeletonAudio.volume = 0.48; }
      if (skeletonAudio.paused) { const play = skeletonAudio.play(); if (play && play.catch) play.catch(() => { /* браузер ждёт жест пользователя; повторим при следующем тике */ }); }
    } catch(e) { skeletonAudio = null; }
  }
  function stopSkeletonMusic(){
    if (!skeletonAudio) return;
    try { skeletonAudio.pause(); skeletonAudio.currentTime = 0; } catch(e) { /* ok */ }
    skeletonAudio = null;
  }
  function renderPoll(poll){
    const dock=$('pollDock'); if(!dock)return;
    if(!poll){dock.hidden=true;dock.replaceChildren();activePollId=null;return;}
    if(activePollId===poll.id && dock.dataset.rendered==='1'){
      const close=dock.querySelector('.pollClose'); if(poll.my_vote!==null && poll.my_vote!==undefined && close) close.hidden=false; return;
    }
    activePollId=poll.id;dock.dataset.rendered='1';dock.hidden=false;
    const opts=(poll.options||[]);const counts=poll.counts||[];
    const head=h('div',{class:'pollHead'},h('b',{text:'📊 '+poll.question}),h('button',{class:'pollClose',text:'×',title:'Скрыть опрос',hidden:poll.my_vote===null||poll.my_vote===undefined,onclick:()=>{dock.hidden=true;}}));
    const choices=h('div',{class:'pollChoices'});
    opts.forEach((label,i)=>{const count=+(counts[i]||0);const b=h('button',{class:'pollChoice'+(poll.my_vote===i?' chosen':''),text:label,onclick:async()=>{const res=await arpc('farm_poll_vote',{p_poll:poll.id,p_option:i},'Голос учтён');if(res){UI.lastFeed.poll=res;dock.dataset.rendered='0';renderPoll(res);}}}); if(poll.my_vote!==null&&poll.my_vote!==undefined){b.disabled=true;b.append(h('small',{text:count+' голосов'}));}choices.append(b);});
    dock.replaceChildren(head,choices,h('small',{class:'pollFoot',text:'Опрос общий · осталось '+tm(poll.ends_in||0)}));
  }

  /* ---------- джойстик ---------- */
  (function () {
    const joy = $('joy'), knob = $('knob'); let id = null;
    function set(e) {
      const r = joy.getBoundingClientRect(), cx = r.left + r.width / 2, cy = r.top + r.height / 2; let dx = e.clientX - cx, dy = e.clientY - cy; const R = Math.max(28, r.width * 0.36), d = Math.hypot(dx, dy);
      if (d > R) { dx = dx / d * R; dy = dy / d * R; } knob.style.transform = 'translate(' + dx + 'px,' + dy + 'px)';
      const m = Math.hypot(dx, dy) / R; G.joy.x = m > 0.18 ? dx / R : 0; G.joy.y = m > 0.18 ? dy / R : 0;
    }
    joy.addEventListener('pointerdown', e => { id = e.pointerId; joy.setPointerCapture(id); set(e); e.preventDefault(); e.stopPropagation(); });
    joy.addEventListener('pointermove', e => { if (e.pointerId === id) set(e); });
    const end = e => { if (e.pointerId !== id) return; id = null; G.joy.x = G.joy.y = 0; knob.style.transform = ''; };
    joy.addEventListener('pointerup', end); joy.addEventListener('pointercancel', end);
    UI.showJoy = on => { joy.hidden = !(on && G.touch); };
  })();

  /* ---------- окна ---------- */
  let modalClose = null, pauseCount = 0;
  UI.pause = on => { pauseCount = Math.max(0, pauseCount + (on ? 1 : -1)); G.paused = pauseCount > 0; if (G.paused) { G.joy.x = G.joy.y = 0; G.target = null; } };
  UI.closeModal = function () { if ($('modal').hidden) return; $('modal').hidden = true; $('mbody').replaceChildren(); UI.pause(false); const f = modalClose; modalClose = null; f && f(); };
  UI.openModal = function (title, body, opts) {
    opts = opts || {}; const was = !$('modal').hidden;
    // Закрываем ресурсы предыдущего окна при переключении, иначе таймеры магазина
    // продолжают работать под новым окном и создают повторные обновления.
    if (was && modalClose) { const oldClose = modalClose; modalClose = null; try { oldClose(); } catch (e) {} }
    $('mtitle').textContent = title; $('mbody').replaceChildren(body); $('modal').querySelector('.mbox').classList.toggle('wide', !!opts.wide);
    modalClose = opts.onClose || null; $('modal').hidden = false; if (!was) UI.pause(true);
  };
  UI.resetSession = function () {
    // Новый вход (в т.ч. под другим ником) не должен наследовать улучшения, паузу и очередь вылупления прошлого аккаунта.
    upgradesLoaded = false; upgradesLoading = false; upgradesRetryAt = 0; G.upgradeLevels = { income: 0, speed: 0, sell: 0 };
    pauseCount = 0; G.paused = false; G.stockDisplay = null; shownCoins = 0; modalClose = null;
    UI.closeHatch(); $('hatch').hidden = true;
  };
  $('mclose').onclick = UI.closeModal;
  $('modal').addEventListener('pointerdown', e => { if (e.target === $('modal')) UI.closeModal(); });
  window.addEventListener('keydown', e => { if (e.key === 'Escape') { if (!$('hatch').hidden) return; UI.closeModal(); } });

  const iconCache = {};
  function petIcon(type, rarity) { const k = type + rarity; return iconCache[k] || (iconCache[k] = A.petIcon(type, rarity, 144)); }
  function rarPill(r) { return h('span', { class: 'rar', style: 'background:' + A.RARITY[r].color, text: A.RARITY[r].name }); }
  function sellPrice(t) { return Math.ceil(t.income * 60); }
  function freeStand() {
    const s = G.state; for (let i = 0; i < 12; i++) { const z = i < 3 ? 0 : i < 7 ? 1 : 2; if (z < s.zones && !s.pets.some(p => p.stand === i)) return i; } return -1;
  }
  async function run(name, args) { try { return await G.exec(name, args); } catch (e) { return null; } }

  /* ---------- рюкзак ---------- */
  UI.openBag = function () {
    const s = G.state; if (!s) return; const body = h('div');
    const draw = () => {
      body.replaceChildren(); const st = G.state; const pets = st.pets.slice().sort((a, b) => (G.petType(b.type).income - G.petType(a.type).income));
      const rate = pets.filter(p => p.stand != null).reduce((a, p) => a + G.petType(p.type).income, 0) * st.config.income_mult * st.event_mult.income;
      body.append(h('div', { class: 'sumline' }, h('span', { text: 'Питомцев: ' + pets.length + '/60' }), h('span', { text: 'Доход: ' + fmt(rate) + '/с' }), h('span', { text: 'Яиц открыто: ' + st.eggs_opened })));
      if (!pets.length) { body.append(h('div', { class: 'empty', text: 'Пока пусто. Купи яйцо у инкубатора — из него вылупится питомец, который приносит монеты.' })); return; }
      const grid = h('div', { class: 'grid' });
      pets.forEach(p => {
        const t = G.petType(p.type);
        const acts = h('div', { class: 'acts' });
        if (p.stand == null) acts.append(h('button', { class: 'btn sm green', text: 'Поставить', onclick: async () => { const i = freeStand(); if (i < 0) { UI.toast('Нет свободных стоек. Открой новую зону или сними питомца.', 'warn'); return; } if (await run('farm_place_pet', { p_pet: p.id, p_stand: i })) { UI.sfx('pop'); draw(); } } }));
        else acts.append(h('button', { class: 'btn sm', text: 'Снять', onclick: async () => { const r = await run('farm_unplace_pet', { p_pet: p.id }); if (r) { if (r.paid) UI.toast('+' + fmt(r.paid), 'ok'); draw(); } } }));
        acts.append(h('button', { class: 'btn sm red', text: 'Продать ' + fmt(sellPrice(t)), onclick: async () => { if (['legendary', 'mythic'].includes(t.rarity) && !confirm('Продать «' + t.name + '» (' + A.RARITY[t.rarity].name + ')?')) return; const r = await run('farm_sell_pet', { p_pet: p.id }); if (r) { UI.sfx('coin'); draw(); } } }));
        grid.append(h('div', { class: 'pcard' + (p.stand != null ? ' placed' : '') }, h('img', { src: petIcon(p.type, t.rarity), alt: '' }), h('b', { text: t.name }), rarPill(t.rarity),
          h('div', { class: 'sm', text: '+' + fmt(t.income * st.config.income_mult * st.event_mult.income) + '/с' }), h('div', { class: 'sm', text: p.stand != null ? 'Стойка ' + (p.stand + 1) : 'В рюкзаке' }), acts));
      });
      body.append(grid);
    };
    draw(); UI.openModal('Питомцы', body, { wide: true });
  };
  UI.openEggStock = async function () {
    const body=h('div',null,h('div',{class:'empty',text:'Загружаю яйца со стенда…'}));
    let timer=null, closed=false;
    const draw=async()=>{
      if(closed)return;
      try{
        const rows=await Api.rpc('farm_global_stock');
        const active=(rows||[]).filter(e=>+e.quantity>0).slice(0,4);
        G.stockDisplay=active;
        const grid=h('div',{class:'grid stockShopGrid'});
        active.forEach(e=>{
          grid.append(h('div',{class:'pcard stockShopCard'},eggPicture(e.id,100),h('b',{text:e.name}),h('div',{class:'sm',text:'Цена: '+fmt(e.price)+' монет'}),h('div',{class:'stockCount',text:'В наличии: '+e.quantity}),h('button',{class:'btn sm gold',text:'Купить яйцо',disabled:+e.quantity<=0,onclick:async(ev)=>{const btn=ev.currentTarget;if(btn.disabled)return;btn.disabled=true;try{const st=await G.exec('farm_buy_egg',{p_egg:e.id});UI.closeModal();UI.showHatch(st.hatched,e.id);}catch(x){btn.disabled=false;if(x.code==='egg_out_of_stock')UI.toast('Это яйцо закончилось. Сток обновлён.','warn');}}})));
        });
        const nextAt=Math.max(...(rows||[]).map(e=>Date.parse(e.updated_at||0)||0));
        const remain=Math.max(0,60-Math.floor((Date.now()-nextAt)/1000));
        body.replaceChildren(h('p',{class:'sm',text:'На стенде всегда ровно 4 предложения для всех игроков. Ассортимент обновляется раз в минуту.'}),grid,h('p',{class:'sm stockTimer',text:'Следующее обновление примерно через '+Math.floor(remain/60)+':'+String(remain%60).padStart(2,'0')}));
      }catch(e){body.replaceChildren(h('div',{class:'empty',text:Api.human(e.code,e.message)}));}
    };
    UI.openModal('🥚 Яйца на стенде',body,{wide:true,onClose:()=>{closed=true;clearInterval(timer);}});
    await draw();
    if(!closed)timer=setInterval(draw,12000);
  };

  UI.openMarket = async function(){
    const body=h('div',null,h('p',{class:'sm',text:'Здесь продаются только собранные яйца с грядок.'}));
    const draw=()=>{body.replaceChildren(h('div',{class:'marketSummary'},h('b',{text:'Собрано: '+G.cropCount()+' яиц'}),h('b',{text:'Получишь: '+fmt(G.cropValue())+' монет'}),h('button',{class:'btn gold big',text:'Продать все яйца',disabled:G.cropCount()===0,onclick:async()=>{try{const st=await Api.rpc('farm_sell_crops');const paid=st.paid||0;G.applyState(st);UI.toast('Продано за '+fmt(paid)+' монет','ok');draw();}catch(e){UI.toast(Api.human(e.code,e.message),'warn');}}})));};
    draw();UI.openModal('🛒 Рынок',body,{wide:false});
  };
  UI.openPlantEggShop = async function(){
    const body=h('div',{class:'stockShopBody'},h('div',{class:'empty',text:'Загружаю посадочные яйца…'}));
    let timer=null, closed=false;
    const draw=async()=>{
      if(closed)return;
      try{
        const rows=(await Api.rpc('farm_crop_stock')||[]).slice(0,4);
        const grid=h('div',{class:'grid stockShopGrid'});
        rows.forEach(e=>{
          const locked=+e.min_zone>G.state.zones, empty=+e.quantity<=0;
          const buttonText=locked?'Открой зону '+e.min_zone:empty?'Нет в наличии':'Выбрать для посадки';
          const card=h('div',{class:'pcard stockShopCard'},eggPicture(e.id,94),h('b',{text:e.name}),h('div',{class:'sm',text:'Цена посадки: '+fmt(e.seed_cost)+' монет'}),h('div',{class:'stockCount',text:'В наличии: '+e.quantity+' / 4'}),h('div',{class:'sm',text:'Продажа: '+fmt(e.sell_price)+' · Рост: '+Math.ceil(e.grow_seconds/60)+' мин'}),h('button',{class:'btn sm gold',text:buttonText,disabled:locked||empty,onclick:()=>{G.selectedCrop=e.id;UI.closeModal();UI.toast('Выбрано: '+e.name+'. Подойди к свободной грядке.','ok');UI.refresh();}}));
          grid.append(card);
        });
        body.replaceChildren(h('p',{class:'sm',text:'Глобальный сток: одновременно доступны только 4 вида посадочных яиц. Ассортимент меняется раз в минуту.'}),grid);
      }catch(e){body.replaceChildren(h('div',{class:'empty',text:Api.human(e.code,e.message)}));}
    };
    UI.openModal('🥚 Посадочные яйца',body,{wide:true,onClose:()=>{closed=true;clearInterval(timer);}});
    await draw(); if(!closed)timer=setInterval(draw,12000);
  };

  // Ежедневные награды и серия входов.
  UI.openDailyRewards=async function(){
    const body=h('div',null,h('div',{class:'empty',text:'Загружаю награду…'}));
    UI.openModal('🎁 Ежедневная награда',body,{wide:false});
    const draw=async()=>{
      try{
        const d=await Api.rpc('farm_daily_status');
        const claimed=!!d.claimed_today;
        const rewards=[100,150,250,400,600,850,1200];
        const strip=h('div',{class:'dailyStrip'});
        rewards.forEach((v,i)=>strip.append(h('div',{class:'dailyDay'+(i+1===d.next_streak?' today':'')+(i+1<=d.streak?' done':'')},h('b',{text:'Д'+(i+1)}),h('strong',{text:'+'+fmt(v)}))));
        body.replaceChildren(h('div',{class:'panel'},h('div',{class:'dailyHero',text:'🔥 Серия: '+d.streak+' дн.'}),h('p',{class:'sm',text:claimed?'Сегодняшняя награда уже получена. Возвращайся завтра!':'Забирай бонус каждый день. Если пропустить день, серия начнётся заново.'}),strip,h('h3',{text:claimed?'Следующая награда':'Сегодня: +'+fmt(d.next_reward)+' монет'}),h('button',{class:'btn gold big',text:claimed?'Уже получено':'Забрать награду',disabled:claimed,onclick:async()=>{try{const r=await Api.rpc('farm_daily_claim');if(r.claimed){G.sync();UI.sfx('unlock');UI.toast('Ежедневный бонус: +'+fmt(r.reward)+' монет','ok');}else UI.toast('Награда уже получена сегодня','warn');await draw();}catch(e){UI.toast(Api.human(e.code,e.message),'warn');}}})));
      }catch(e){body.replaceChildren(h('div',{class:'empty',text:Api.human(e.code,e.message)}));}
    };
    await draw();
  };
  const bindBtn=(id,fn)=>{const el=$(id);if(el)el.onclick=fn;};
  bindBtn('bDaily',()=>UI.openDailyRewards());

  // Достижения с серверной проверкой и разовой выдачей монет.
  UI.openAchievements=async function(){
    const body=h('div',null,h('div',{class:'empty',text:'Загружаю достижения…'}));
    UI.openModal('🏆 Достижения',body,{wide:true});
    const draw=async()=>{
      try{
        const rows=await Api.rpc('farm_achievements');
        const list=h('div',{class:'achievementList'});
        (rows||[]).forEach(a=>{
          const progress=Math.min(+a.goal,+a.progress||0),pct=Math.max(0,Math.min(100,progress/+a.goal*100));
          const status=a.claimed?'Награда получена':a.unlocked?'Можно забрать':'В процессе';
          list.append(h('div',{class:'panel achievementCard'},h('div',{class:'row',style:'justify-content:space-between;align-items:center'},h('b',{text:a.title}),h('span',{class:'badge',text:status})),h('p',{class:'sm',text:a.description}),h('div',{class:'achievementTrack'},h('i',{style:'width:'+pct+'%'})),h('div',{class:'row',style:'justify-content:space-between'},h('small',{text:fmt(progress)+' / '+fmt(a.goal)}),h('b',{text:'+'+fmt(a.reward)+' 🪙'})),h('button',{class:'btn sm gold',text:a.claimed?'Получено':a.unlocked?'Забрать':'Закрыто',disabled:!a.unlocked||a.claimed,onclick:async()=>{try{const r=await Api.rpc('farm_claim_achievement',{p_id:a.id});G.sync();UI.sfx('unlock');UI.toast('Достижение: +'+fmt(r.reward)+' монет','ok');await draw();}catch(e){UI.toast(Api.human(e.code,e.message),'warn');}}})));
        });
        body.replaceChildren(list);
      }catch(e){body.replaceChildren(h('div',{class:'empty',text:Api.human(e.code,e.message)}));}
    };
    await draw();
  };
  bindBtn('bAchievements',()=>UI.openAchievements());

  // Каталог визуальных предметов и урожая из игровых яиц.
  UI.openCatalog=function(){
    const body=h('div',{class:'gameCatalog'},
      h('p',{class:'sm',text:'Виды яиц, кнопки и урожай для фермы. Из высиженных яиц питомцы, из посадочных — растения.'}),
      h('img',{class:'gameCatalogAtlas',src:'assets/game-ui-atlas.png',alt:'Каталог яиц, растений, кнопок и игровых значков'}),
      h('div',{class:'panel'},h('h3',{text:'🌱 Что можно получить из посадочных яиц'}),
        h('div',{class:'catalogDrops'},
          ...[['🍀','Клевер'],['🥕','Морковь'],['🌾','Пшеница'],['🌽','Кукуруза'],['🍅','Томат'],['🍇','Ягода'],['🍉','Арбуз'],['🎃','Тыква']].map(x=>h('div',{class:'catalogDrop'},h('span',{text:x[0]}),h('b',{text:x[1]})))
        )
      ),
      h('div',{class:'panel'},h('h3',{text:'🎮 Управление'}),
        h('p',{class:'sm',text:'Магазин яиц — покупка · Инкубатор — вылупление · Посадочные яйца — выращивание урожая · Рынок — продажа · Бонус дня и достижения — награды · Улучшения — развитие фермы.'})
      )
    );
    UI.openModal('🥚 Каталог фермы',body,{wide:true});
  };
  const catalogBtn=$('bCatalog'); if(catalogBtn) catalogBtn.onclick=()=>UI.openCatalog();


  UI.showOfflineReturn=function(st){
    if(!st)return;
    const paid=Math.max(0,Math.floor(+st.offline_reward||0));
    const ready=Math.max(0,Math.floor(+st.offline_ready||0));
    if(paid>0||ready>0){
      const parts=[];
      if(paid>0)parts.push('со стоек начислено '+fmt(paid)+' монет');
      if(ready>0)parts.push('созрело яиц на грядках: '+ready);
      setTimeout(()=>UI.toast('Пока тебя не было: '+parts.join(' · '),'ok'),900);
    }
  };

  // Улучшения фермы сохраняются на сервере отдельно для каждого игрока.
  UI.openUpgrades=async function(){
    const body=h('div',null,h('div',{class:'empty',text:'Загружаю улучшения…'})); UI.openModal('✨ Улучшения фермы',body,{wide:true});
    const defs=[
      {id:'income',name:'Золотые кормушки',desc:'+15% дохода питомцев за уровень',base:500,icon:'💰',max:10},
      {id:'speed',name:'Быстрый инкубатор',desc:'Яйца созревают на 12% быстрее за уровень',base:650,icon:'⚡',max:10},
      {id:'sell',name:'Упаковка премиум',desc:'+12% монет за продажу урожая за уровень',base:450,icon:'📦',max:10}
    ];
    const draw=()=>{body.replaceChildren(h('p',{class:'sm',text:'Улучшения сохраняются в аккаунте и работают на всех устройствах.'}));
      defs.forEach(d=>{const lv=+(G.upgradeLevels[d.id]||0),cost=Math.floor(d.base*Math.pow(1.7,lv));body.append(h('div',{class:'panel upgradeCard'},h('div',{class:'upgradeIcon',text:d.icon}),h('div',{class:'upgradeInfo'},h('b',{text:d.name}),h('p',{class:'sm',text:d.desc}),h('div',{class:'sm',text:'Уровень '+lv+'/'+d.max+' · Следующая цена: '+fmt(cost)}),h('button',{class:'btn gold',text:lv>=d.max?'Максимум':'Улучшить за '+fmt(cost),disabled:lv>=d.max||G.state.coins<cost,onclick:async()=>{try{const u=await Api.rpc('farm_upgrade_buy',{p_kind:d.id});G.upgradeLevels={income:+u.income||0,speed:+u.speed||0,sell:+u.sell||0};G.state.coins=+u.coins;UI.refresh();UI.sfx('unlock');draw();}catch(e){UI.toast(Api.human(e.code,e.message),'warn');}}}))));});
    };
    try{const u=await Api.rpc('farm_upgrades_get');G.upgradeLevels={income:+u.income||0,speed:+u.speed||0,sell:+u.sell||0};if(u.coins!=null)G.state.coins=+u.coins;UI.refresh();draw();}catch(e){body.replaceChildren(h('div',{class:'empty',text:Api.human(e.code,e.message)}));}
  };
  bindBtn('bUpgrades',()=>UI.openUpgrades());

  $('bBag').onclick = () => UI.openBag();
  UI.openPetPicker = function (stand) {
    const body = h('div'), pets = G.state.pets.filter(p => p.stand == null).sort((a, b) => G.petType(b.type).income - G.petType(a.type).income);
    if (!pets.length) body.append(h('div', { class: 'empty', text: 'Нет свободных питомцев. Купи яйцо!' }));
    const grid = h('div', { class: 'grid' });
    pets.forEach(p => { const t = G.petType(p.type); grid.append(h('div', { class: 'pcard' }, h('img', { src: petIcon(p.type, t.rarity), alt: '' }), h('b', { text: t.name }), rarPill(t.rarity), h('div', { class: 'sm', text: '+' + fmt(t.income * G.state.config.income_mult * G.state.event_mult.income) + '/с' }),
      h('div', { class: 'acts' }, h('button', { class: 'btn sm green', text: 'Поставить сюда', onclick: async () => { UI.closeModal(); if (await run('farm_place_pet', { p_pet: p.id, p_stand: stand })) UI.sfx('pop'); } })))); });
    body.append(grid); UI.openModal('Стойка ' + (stand + 1) + ': кого поставить?', body, { wide: true });
  };

  /* ---------- лидеры ---------- */
  UI.openBoard = async function () {
    const body = h('div', null, h('div', { class: 'empty', text: 'Загрузка…' })); UI.openModal('Лучшие фермеры', body);
    try {
      const rows = await Api.rpc('farm_leaderboard'); body.replaceChildren();
      const t = h('table', { class: 't' }, h('tr', null, h('th', { text: '#' }), h('th', { text: 'Игрок' }), h('th', { text: 'Заработано' }), h('th', { text: 'Питомцев' })));
      rows.forEach((r, i) => t.append(h('tr', { class: r.username === G.state.username ? 'me' : '' }, h('td', { text: String(i + 1) }), h('td', { text: r.username }), h('td', { text: fmt(r.total_earned) }), h('td', { text: String(r.pets) }))));
      body.append(rows.length ? t : h('div', { class: 'empty', text: 'Пока никого нет.' }));
    } catch (e) { body.replaceChildren(h('div', { class: 'empty', text: Api.human(e.code, e.message) })); }
  };
  $('bTop').onclick = () => UI.openBoard();

  // Правая панель разделов: вызывает те же окна, что и игровые стойки.
  const bindSide=(id,fn)=>{const el=$(id);if(el)el.addEventListener('click',fn);};
  bindSide('sideEggShop',()=>UI.openEggStock());
  bindSide('sideIncubator',()=>UI.openEggStock());
  bindSide('sidePlantEggs',()=>UI.openPlantEggShop());
  bindSide('sideMarket',()=>UI.openMarket());
  bindSide('sideRating',()=>UI.openBoard());
  bindSide('sideDaily',()=>UI.openDailyRewards());
  bindSide('sideAch',()=>UI.openAchievements());
  bindSide('sideUpgrades',()=>UI.openUpgrades());
  bindSide('sideCatalog',()=>UI.openCatalog());
  bindSide('sideAdmin',()=>UI.openAdmin());


  /* ---------- вылупление ---------- */
  const hatchQueue = []; let hatchClose = null;
  UI.closeHatch = function () { hatchQueue.length = 0; if (hatchClose) hatchClose(true); };
  UI.showHatch = function (res, eggId) {
    if (hatchClose) { hatchQueue.push([res, eggId]); return; }
    const t = G.petType(res.type), rar = t.rarity, big = rar === 'legendary' || rar === 'mythic';
    const root = $('hatch'), cv = $('hc'), c = cv.getContext('2d'), card = $('hcard'); card.hidden = true; root.hidden = false; UI.pause(true);
    let t0 = performance.now(), done = false, burstDone = false, raf = 0; const sp = [];
    const R = A.RARITY[rar];
    function close(silent) { cancelAnimationFrame(raf); root.hidden = true; UI.pause(false); hatchClose = null; UI.refresh(); const nx = silent === true ? null : hatchQueue.shift(); if (nx) UI.showHatch(nx[0], nx[1]); }
    hatchClose = close;
    $('hok').onclick = () => close();
    $('hplace').onclick = async () => { const i = freeStand(); if (i < 0) { UI.toast('Нет свободных стоек. Питомец в рюкзаке.', 'warn'); close(); return; } close(); if (await run('farm_place_pet', { p_pet: res.id, p_stand: i })) UI.sfx('pop'); };
    $('hplace').disabled = false;
    function frame(now) {
      const t = (now - t0) / 1000; c.clearRect(0, 0, 420, 420);
      const g = c.createRadialGradient(210, 230, 10, 210, 230, 220); g.addColorStop(0, big ? R.color + '55' : 'rgba(255,255,255,.12)'); g.addColorStop(1, 'rgba(0,0,0,0)'); c.fillStyle = g; c.fillRect(0, 0, 420, 420);
      if (t < 1.9) {
        const k = t / 1.9, rot = Math.sin(t * (14 + k * 26)) * (0.05 + k * 0.2), crack = t > 1.0 ? (t > 1.45 ? 2 : 1) : 0;
        c.fillStyle = 'rgba(0,0,0,.3)'; c.beginPath(); c.ellipse(210, 340, 70 - k * 8, 14, 0, 0, Math.PI * 2); c.fill();
        A.drawEgg(c, eggId, 210, 335, 4.1, t, rot, crack);
      } else {
        if (!burstDone) { burstDone = true; UI.sfx(big ? 'rare' : 'hatch'); const n = big ? 90 : 40; for (let i = 0; i < n; i++) { const a = Math.random() * Math.PI * 2, v = 120 + Math.random() * 260; sp.push({ x: 210, y: 220, vx: Math.cos(a) * v, vy: Math.sin(a) * v - 80, a: 0, life: 1 + Math.random(), col: i % 3 ? R.color : '#fff', r: 2 + Math.random() * 4 }); } if (big) { G.confetti(G.player.x, G.player.y - 60, 80); G.shake = 0.8; G.flash = 0.5; } }
        const u = t - 1.9, sc = u < .4 ? 3.9 * (1 - Math.pow(1 - u / .4, 3)) * (1 + .12 * Math.sin(u / .4 * Math.PI)) : 3.9;
        if (R.glow > 0) { c.save(); c.translate(210, 225); c.rotate(t * 0.4); for (let i = 0; i < 14; i++) { c.rotate(Math.PI * 2 / 14); c.fillStyle = R.color + '40'; c.beginPath(); c.moveTo(0, 0); c.lineTo(-18, -200); c.lineTo(18, -200); c.fill(); } c.restore(); }
        A.drawPet(c, res.type, 210, 330, sc, t, { rarity: rar });
        if (u > 0.5 && card.hidden) { card.hidden = false; $('hrar').textContent = R.name + (big ? '!' : ''); $('hrar').style.background = R.color; $('hname').textContent = t.name; $('hinc').textContent = '+' + fmt(t.income * G.state.config.income_mult * G.state.event_mult.income) + ' монет в секунду'; $('hplace').hidden = freeStand() < 0; }
        if (u < 0.12) { c.fillStyle = 'rgba(255,255,255,' + (0.9 - u * 7) + ')'; c.fillRect(0, 0, 420, 420); }
      }
      for (let i = sp.length - 1; i >= 0; i--) { const q = sp[i]; q.a += 0.016; if (q.a > q.life) { sp.splice(i, 1); continue; } q.vy += 380 * 0.016; q.x += q.vx * 0.016; q.y += q.vy * 0.016; c.globalAlpha = 1 - q.a / q.life; c.fillStyle = q.col; c.beginPath(); c.arc(q.x, q.y, q.r, 0, Math.PI * 2); c.fill(); c.globalAlpha = 1; }
      raf = requestAnimationFrame(frame);
    }
    raf = requestAnimationFrame(frame);
  };

  /* ---------- объявления и события (Realtime + опрос) ---------- */
  const anns = new Map(); let feedTimer = null, rtStop = null, nudgeT = null;
  function addAnn(a) {
    const clean = String(a.message || '').trim().replace(/\s+/g, ' ');
    const textKey = clean.toLocaleLowerCase();
    if (!clean || anns.has(a.id) || [...anns.values()].some(r => r.textKey === textKey)) return;
    const el = h('div', { class: 'ann', text: clean }); $('announce').append(el);
    const rec = { el, textKey, to: setTimeout(() => removeAnn(a.id), Math.max(1000, a.ends_in * 1000)) }; anns.set(a.id, rec);
    const box = $('announce');
    while (box.children.length > 3) {
      const first = box.firstChild;
      const entry = [...anns.entries()].find(([, r]) => r.el === first);
      if (entry) { clearTimeout(entry[1].to); anns.delete(entry[0]); }
      first.remove();
    }
  }
  function removeAnn(id) { const r = anns.get(id); if (!r) return; clearTimeout(r.to); anns.delete(id); r.el.classList.add('out'); setTimeout(() => r.el.remove(), 650); }
  UI.applyFeed = function (f) {
    const ids = new Set(f.announcements.map(a => a.id));
    f.announcements.forEach(addAnn); [...anns.keys()].forEach(id => { if (!ids.has(id)) removeAnn(id); });
    G.setEvents(f.events.map(e => ({ id: e.id, kind: e.kind, title: e.title, mult: +e.mult, expireAt: Date.now() + e.ends_in * 1000 }))); renderEvents();
    UI.lastFeed = f; renderPoll(f.poll || null);
  };
  UI.pollFeed = async function () { try { UI.applyFeed(await Api.rpc('farm_feed')); } catch (e) { if (e.code === 'not_authenticated') UI.sessionLost(); } };
  UI.startFeed = function () {
    UI.stopFeed(); UI.pollFeed();
    Api.rpc('farm_global_stock').then(rows => { G.stockDisplay = (rows || []).filter(e => +e.quantity > 0).slice(0, 4); }).catch(() => {});
    feedTimer = setInterval(UI.pollFeed, 6000);
    rtStop = Api.realtime(() => { clearTimeout(nudgeT); nudgeT = setTimeout(UI.pollFeed, 150); });
  };
  UI.stopFeed = function () { clearInterval(feedTimer); feedTimer = null; rtStop && rtStop(); rtStop = null; [...anns.keys()].forEach(removeAnn); G.setEvents([]); renderEvents(); renderPoll(null); stopSkeletonMusic(); };

  /* ---------- админ-панель (права проверяет сервер при каждом действии) ---------- */
  async function arpc(name, args, ok) { try { const r = await Api.rpc(name, args); if (ok) UI.toast(ok, 'ok'); return r === null ? true : r; } catch (e) { UI.toast(Api.human(e.code, e.message), 'err'); return null; } }
  const KINDS = { income: 'Доход', growth: 'Рост', sell: 'Продажи', skeleton: 'Нашествие скелетов' };
  const EVENT_ICONS = { income: '💰', growth: '🌱', sell: '🛒', skeleton: '💀' };
  let skeletonAudio = null, skeletonTimer = null, activePollId = null;
  UI.openAdmin = function () {
    const s = G.state, global = s && s.role === 'GLOBAL_ADMIN';
    if (!global) { UI.toast('Админ-панель доступна только владельцу фермы.', 'warn'); return; }
    const body = h('div'), content = h('div');
    const tabs = [['ann', 'Объявления', tabAnn], ['ev', 'События', tabEvents], ['poll', 'Опросы', tabPoll], ['stock', 'Склад яиц', tabStock], ['global', 'Глобальный абьюз', tabGlobal], ['cfg', 'Экономика', tabCfg], ['pl', 'Игроки', tabPlayers], ['log', 'История', tabLog]];
    const bar = h('div', { class: 'tabs' }); let cur = tabs[0][0];
    const show = id => { cur = id; [...bar.children].forEach((b, i) => b.classList.toggle('on', tabs[i][0] === id)); content.replaceChildren(h('div', { class: 'empty', text: 'Загрузка…' })); tabs.find(t => t[0] === id)[2](content); };
    tabs.forEach(t => bar.append(h('button', { class: 'tab', type: 'button', text: t[1], onclick: () => show(t[0]) })));
    body.append(h('div', { class: 'sumline' }, h('span', { text: 'Владелец: ' + s.username }), h('span', { class: 'badge', text: 'GLOBAL OWNER' })), h('p', { class: 'adminIntro', text: 'Закрытая панель владельца. Все изменения применяются глобально и проверяются сервером.' }), bar, content);
    UI.openModal('Админ-панель', body, { wide: true }); show(cur);
  };
  $('bAdmin').onclick = () => UI.openAdmin();

  function tabAnn(root) {
    const msg = h('textarea', { maxlength: 240, placeholder: 'Текст объявления (до 240 символов)' }), dur = h('select', null, ...[[10, '10 секунд'], [20, '20 секунд'], [60, '1 минута'], [300, '5 минут'], [1800, '30 минут']].map(d => h('option', { value: d[0], text: d[1] })));
    const list = h('div', { class: 'list' });
    const renderList = () => { list.replaceChildren(); const a = (UI.lastFeed && UI.lastFeed.announcements) || []; if (!a.length) list.append(h('div', { class: 'empty', text: 'Активных объявлений нет' })); a.forEach(x => list.append(h('div', { class: 'it' }, h('span', { class: 'msg', text: x.message }), h('button', { class: 'btn sm red', text: 'Удалить', onclick: async () => { if (await arpc('farm_delete_announcement', { p_id: x.id }, 'Удалено')) { await UI.pollFeed(); renderList(); } } })))); };
    root.replaceChildren(h('div', { class: 'panel' }, h('h4', { text: 'Новое объявление' }), msg, h('label', { text: 'Показывать' }), dur, h('div', { style: 'margin-top:10px' }, h('button', { class: 'btn gold', text: 'Опубликовать всем', onclick: async () => { if (!msg.value.trim()) { UI.toast('Введи текст', 'warn'); return; } if (await arpc('farm_announce', { p_message: msg.value, p_seconds: +dur.value }, 'Опубликовано')) { msg.value = ''; await UI.pollFeed(); renderList(); } } }))),
      h('div', { class: 'panel' }, h('h4', { text: 'Активные' }), list)); UI.pollFeed().then(renderList);
  }
  function tabEvents(root) {
    const kind = h('select', null, ...Object.entries(KINDS).map(k => h('option', { value: k[0], text: k[1] + ' ×' }))), title = h('input', { maxlength: 80, value: 'Золотой час' }), mult = h('input', { type: 'number', min: 1, max: 100, step: '0.5', value: 2 }), mins = h('input', { type: 'number', min: 1, max: 1440, value: 10 });
    const list = h('div', { class: 'list' });
    const renderList = () => { list.replaceChildren(); const a = (UI.lastFeed && UI.lastFeed.events) || []; if (!a.length) list.append(h('div', { class: 'empty', text: 'Активных событий нет' })); a.forEach(x => list.append(h('div', { class: 'it' }, h('span', { class: 'msg', text: (EVENT_ICONS[x.kind]||'✨')+' '+KINDS[x.kind] + ' ×' + x.mult + ' — ' + x.title }), h('button', { class: 'btn sm red', text: 'Завершить', onclick: async () => { if (await arpc('farm_end_event', { p_id: x.id }, 'Завершено')) { await UI.pollFeed(); renderList(); } } })))); };
    root.replaceChildren(h('div', { class: 'panel' }, h('h4', { text: 'Создать событие' }), h('label', { text: 'Тип' }), kind, h('label', { text: 'Название' }), title, h('div', { class: 'row' }, h('div', null, h('label', { text: 'Множитель (1–100)' }), mult), h('div', null, h('label', { text: 'Минут (1–1440)' }), mins)),
      h('div', { style: 'margin-top:10px' }, h('button', { class: 'btn gold', text: 'Запустить', onclick: async () => { if (await arpc('farm_create_event', { p_kind: kind.value, p_title: title.value, p_mult: +mult.value, p_minutes: +mins.value }, 'Событие запущено')) { await UI.pollFeed(); renderList(); } } }))),
      h('div', { class: 'panel' }, h('h4', { text: 'Идут сейчас' }), list)); UI.pollFeed().then(renderList);
  }
  function tabPoll(root) {
    const question=h('input',{maxlength:180,placeholder:'Вопрос для всех игроков'}), opts=[h('input',{maxlength:60,placeholder:'Вариант 1'}),h('input',{maxlength:60,placeholder:'Вариант 2'})];
    const extra=h('button',{class:'btn sm',text:'+ Добавить вариант',onclick:()=>{if(opts.length>=5)return UI.toast('Максимум 5 вариантов','warn');const x=h('input',{maxlength:60,placeholder:'Ещё вариант'});opts.push(x);extra.before(x);}});
    const mins=h('select',null,...[[60,'1 час'],[360,'6 часов'],[1440,'24 часа'],[10080,'7 дней']].map(x=>h('option',{value:x[0],text:x[1]})));
    const active=h('div',{class:'panel'});
    const refreshActive=async()=>{try{const f=await Api.rpc('farm_feed');const p=f&&f.poll;active.replaceChildren(h('h4',{text:'Активный опрос'}));if(!p){active.append(h('p',{class:'empty',text:'Сейчас нет активного опроса'}));return;}active.append(h('p',{text:p.question}),h('button',{class:'btn red',text:'Отключить опрос у всех игроков',onclick:async()=>{if(!confirm('Отключить этот опрос у всех игроков?'))return;if(await arpc('farm_end_poll',{p_poll:p.id},'Опрос отключён у всех')){await UI.pollFeed();refreshActive();}}}));}catch(e){active.replaceChildren(h('p',{class:'empty',text:Api.human(e.code,e.message)}));}};
    root.replaceChildren(h('div',{class:'panel'},h('h4',{text:'Глобальный опрос'}),question,...opts,extra,h('label',{text:'Длительность'}),mins,h('button',{class:'btn gold',text:'Опубликовать всем',onclick:async()=>{const a=opts.map(x=>x.value.trim()).filter(Boolean);if(!question.value.trim()||a.length<2)return UI.toast('Нужен вопрос и минимум 2 варианта','warn');if(await arpc('farm_create_poll',{p_question:question.value.trim(),p_options:a,p_minutes:+mins.value},'Опрос опубликован')){UI.pollFeed();refreshActive();}}})),active,h('div',{class:'panel'},h('h4',{text:'Подсказка'}),h('p',{text:'Опрос появится снизу у всех игроков. Крестик после голосования скрывает его только у тебя, а кнопка выше отключает опрос у всех.'}))); 
    refreshActive();
  }
  async function tabStock(root) {
    const list=h('div',{class:'stockAdminList'});
    const summary=h('div',{class:'stockSummary'});
    const id=h('input',{maxlength:32,placeholder:'например: ruby_egg'});
    const name=h('input',{maxlength:40,placeholder:'Название яйца'});
    const price=h('input',{type:'number',min:'0',max:'1000000000',value:'100'});
    const quantity=h('input',{type:'number',min:'0',max:'1000000',value:'100'});
    const maximum=h('input',{type:'number',min:'1',max:'1000000',value:'1000'});
    const draw=async()=>{
      list.replaceChildren(h('div',{class:'empty',text:'Загружаю общий склад…'}));
      try {
        const rows=await Api.rpc('farm_admin_egg_catalog');
        const all=rows||[]; const total=all.reduce((n,e)=>n+(+e.quantity||0),0); const active=all.filter(e=>+e.quantity>0).length;
        summary.replaceChildren(
          h('div',{class:'stockSummaryTile'},h('b',{text:String(all.length)}),h('small',{text:'Видов яиц'})),
          h('div',{class:'stockSummaryTile'},h('b',{text:fmt(total)}),h('small',{text:'Яиц на общем складе'})),
          h('div',{class:'stockSummaryTile'},h('b',{text:String(active)}),h('small',{text:'Есть в наличии'}))
        );
        list.replaceChildren();
        all.forEach(e=>{
          const p=h('input',{type:'number',min:'0',max:'1000000000',value:String(e.price),class:'stockAdminAmount',title:'Цена'});
          const q=h('input',{type:'number',min:'0',max:'1000000',value:String(e.quantity),class:'stockAdminAmount',title:'Количество'});
          const m=h('input',{type:'number',min:'1',max:'1000000',value:String(e.max_quantity),class:'stockAdminAmount',title:'Вместимость'});
          const save=h('button',{class:'btn sm gold',text:'Сохранить',onclick:async()=>{
            const vals=[Number(p.value),Number(q.value),Number(m.value)];
            if(vals.some(v=>!Number.isInteger(v))||vals[0]<0||vals[1]<0||vals[2]<1||vals[1]>vals[2])return UI.toast('Количество должно быть от 0 до максимального запаса','warn');
            if(await arpc('farm_admin_save_egg',{p_id:e.id,p_name:e.name,p_price:vals[0],p_min_zone:0,p_quantity:vals[1],p_max_quantity:vals[2]},'Общий запас сохранён')) await draw();
          }});
          const card=h('div',{class:'stockAdminCard stockAdminEdit'},eggPicture(e.id,76),h('div',{class:'stockAdminInfo'},h('b',{text:e.name}),h('small',{text:'ID: '+e.id}),h('div',{class:'stockAdminFields'},h('div',null,h('label',{text:'Цена, монет'}),p),h('div',null,h('label',{text:'Остаток у всех'}),q),h('div',null,h('label',{text:'Лимит склада'}),m)),save));
          list.append(card);
        });
        if(!all.length)list.append(h('div',{class:'empty',text:'Каталог пуст'}));
      } catch(e) { list.replaceChildren(h('div',{class:'empty',text:Api.human(e.code,e.message)})); }
    };
    const add=async()=>{
      const vals=[Number(price.value),Number(quantity.value),Number(maximum.value)];
      if(!/^[a-z0-9_]{2,32}$/.test(id.value.trim().toLowerCase()))return UI.toast('ID: латинские буквы, цифры и _ (2–32 символа)','warn');
      if(!name.value.trim()||vals.some(v=>!Number.isInteger(v))||vals[0]<0||vals[1]<0||vals[2]<1||vals[1]>vals[2])return UI.toast('Проверь название, цену и запас','warn');
      if(await arpc('farm_admin_save_egg',{p_id:id.value.trim().toLowerCase(),p_name:name.value.trim(),p_price:vals[0],p_min_zone:0,p_quantity:vals[1],p_max_quantity:vals[2]},'Яйцо добавлено в общий склад')){id.value='';name.value='';quantity.value='100';await draw();}
    };
    root.replaceChildren(
      h('div',{class:'panel'},h('h4',{text:'📦 Глобальный склад яиц'}),h('p',{class:'sm',text:'Глобальный инкубатор: игрокам одновременно показываются только 4 предложения. Покупка уменьшает общий остаток для всех.'}),summary,list),
      h('div',{class:'panel'},h('h4',{text:'➕ Добавить яйцо'}),h('p',{class:'sm',text:'Новое яйцо сразу появится в каталоге. Для него автоматически создаётся базовый питомец.'}),h('div',{class:'eggAdminForm'},h('label',{text:'ID яйца'}),id,h('label',{text:'Название'}),name,h('label',{text:'Цена в монетах'}),price,h('label',{text:'Начальный остаток'}),quantity,h('label',{text:'Максимальный запас'}),maximum),h('button',{class:'btn gold',text:'Добавить в общий склад',onclick:add})),
      h('div',{class:'panel'},h('h4',{text:'🥚 Посадочные яйца — ровно 4 предложения'}),h('p',{class:'sm',text:'На посадочном рынке одновременно активны только 4 вида. Для каждого предложения можно выставить остаток от 0 до 4 яиц.'}),(()=>{const sel=h('select'),qty=h('input',{type:'number',min:'0',max:'4',value:'4'});const load=()=>Api.rpc('farm_admin_crop_stock').then(rows=>{sel.replaceChildren(...(rows||[]).map(e=>h('option',{value:e.id,text:e.name+' · '+e.quantity+'/4'})));}).catch(e=>UI.toast(Api.human(e.code,e.message),'err'));load();return h('div',{class:'eggAdminForm'},h('label',{text:'Выбери одно из 4 яиц'}),sel,h('label',{text:'Остаток (0–4)'}),qty,h('button',{class:'btn gold',text:'Сохранить остаток',onclick:async()=>{const n=Number(qty.value);if(!Number.isInteger(n)||n<0||n>4)return UI.toast('Количество должно быть от 0 до 4','warn');if(await arpc('farm_admin_set_crop_stock',{p_crop:sel.value,p_quantity:n},'Остаток сохранён'))await load();}}),h('button',{class:'btn',text:'🎲 Сменить 4 посадочных яйца',onclick:async()=>{if(await arpc('farm_admin_roll_crop_stock',{},'Выбраны новые 4 яйца'))await load();}}));})()),
      h('div',{class:'panel'},h('h4',{text:'🎲 Случайное пополнение инкубатора'}),h('p',{class:'sm',text:'Базовое яйцо и ещё 3 случайных предложения. Остальные виды скрыты со стенда до следующей ротации.'}),h('button',{class:'btn gold',text:'🎲 Обновить 4 яйца инкубатора',onclick:async()=>{if(await arpc('farm_admin_roll_stock',{},'Инкубатор обновлён'))await draw();}}))
    );
    draw();
  }

  async function tabGlobal(root) {
    const amount=h('input',{type:'number',min:'1',max:'1000000000',value:'500'});
    const pet=h('select',null,...G.cat.pets.slice().sort((a,b)=>a.name.localeCompare(b.name,'ru')).map(p=>h('option',{value:p.id,text:p.name+' · '+p.rarity})));
    const kind=h('select',null,...[['income','Доход питомцев'],['growth','Скорость роста'],['sell','Продажа урожая']].map(x=>h('option',{value:x[0],text:x[1]})));
    const mult=h('select',null,...[[2,'×2'],[5,'×5'],[10,'×10'],[25,'×25'],[50,'×50'],[100,'×100']].map(x=>h('option',{value:x[0],text:x[1]})));
    const minutes=h('select',null,...[[5,'5 минут'],[15,'15 минут'],[30,'30 минут'],[60,'1 час'],[180,'3 часа'],[1440,'24 часа']].map(x=>h('option',{value:x[0],text:x[1]})));
    root.replaceChildren(
      h('div',{class:'panel'},h('h4',{text:'💸 Массовая выдача монет'}),h('p',{class:'sm',text:'Начисляет одинаковую сумму каждому аккаунту. Выдача записывается в историю.'}),h('label',{text:'Монет каждому игроку'}),amount,h('button',{class:'btn gold',text:'Выдать всем игрокам',onclick:async()=>{const n=Math.floor(+amount.value);if(n<1||n>1000000000)return UI.toast('Укажи сумму от 1 до 1 000 000 000','warn');if(confirm('Выдать '+fmt(n)+' монет каждому игроку?'))await arpc('farm_admin_grant_all_coins',{p_amount:n},'Монеты выданы всем игрокам');}})),
      h('div',{class:'panel'},h('h4',{text:'🐾 Подарок всем игрокам'}),h('p',{class:'sm',text:'Выдаёт выбранного питомца каждому игроку, у которого его ещё нет. Дубликаты от этой команды не создаются.'}),h('label',{text:'Питомец'}),pet,h('button',{class:'btn gold',text:'Подарить всем',onclick:async()=>{if(confirm('Выдать питомца всем игрокам?'))await arpc('farm_admin_give_pet_all',{p_pet_type:pet.value},'Питомец выдан всем, у кого его не было');}})),
      h('div',{class:'panel'},h('h4',{text:'⚡ Глобальный буст'}),h('p',{class:'sm',text:'Запускает множитель выбранной системы для всех игроков.'}),h('label',{text:'Что усилить'}),kind,h('label',{text:'Множитель'}),mult,h('label',{text:'Длительность'}),minutes,h('button',{class:'btn gold',text:'Запустить глобальный буст',onclick:async()=>{const title='Глобальный буст '+kind.options[kind.selectedIndex].text+' ×'+mult.value;if(await arpc('farm_create_event',{p_kind:kind.value,p_title:title,p_mult:+mult.value,p_minutes:+minutes.value},'Глобальный буст запущен'))UI.pollFeed();}})),
      h('div',{class:'panel'},h('h4',{text:'🌍 Быстрые глобальные действия'}),h('div',{class:'globalActionGrid'},
        h('button',{class:'btn red',text:'⛔ Остановить все события',onclick:async()=>{if(confirm('Завершить все глобальные события?')){await arpc('farm_admin_clear_events',{},'Все события остановлены');UI.pollFeed();}}}),
        h('button',{class:'btn red',text:'🧹 Удалить все объявления',onclick:async()=>{if(confirm('Удалить все активные объявления у игроков?')){await arpc('farm_admin_clear_announcements',{},'Все объявления удалены');UI.pollFeed();}}}),
        h('button',{class:'btn gold',text:'🎲 Обновить оба магазина',onclick:async()=>{if(!confirm('Сменить 4 яйца в инкубаторе и 4 посадочных яйца для всех игроков?'))return;const a=await arpc('farm_admin_roll_stock',{},'Инкубатор обновлён');if(a)await arpc('farm_admin_roll_crop_stock',{},'Посадочный магазин обновлён');UI.pollFeed();}}),
        h('button',{class:'btn gold',text:'🌟 Мега-буст ×2 на 30 минут',onclick:async()=>{if(!confirm('Запустить ×2 доход, рост и продажу для всех на 30 минут?'))return;let ok=true;for(const k of ['income','growth','sell']){const r=await arpc('farm_create_event',{p_kind:k,p_title:'Глобальный мега-буст ×2',p_mult:2,p_minutes:30},'Буст '+k+' запущен');if(!r){ok=false;break;}}if(ok)UI.pollFeed();}}),
        h('button',{class:'btn red',text:'🚨 Глобальная тревога',onclick:async()=>{const msg='⚠️ Внимание! Глобальное событие началось!';if(await arpc('farm_announce',{p_message:msg,p_seconds:30},'Объявление отправлено всем'))UI.pollFeed();}})
      )),
      h('div',{class:'panel'},h('h4',{text:'🛠 Остальные глобальные инструменты'}),h('p',{class:'sm',text:'Настройка дохода, скорости роста и продажи находится во вкладке «Экономика». Создание обычных ивентов, объявлений и опросов — в соседних вкладках. Все действия сервера заносятся в историю.'}))
    );
  }

  async function tabCfg(root) {
    const st = G.state, names = { income_mult: 'Множитель дохода питомцев', sell_mult: 'Множитель цен продажи', growth_speed: 'Скорость роста', offline_cap_hours: 'Лимит накопления, часов' };
    const p1 = h('div', { class: 'panel' }, h('h4', { text: 'Общие настройки экономики' }), h('p', { class: 'sm', text: 'Эти значения применяются сразу ко всем игрокам. Меняй число и нажимай «Сохранить» рядом с ним.' }));
    Object.keys(names).forEach(k => { const inp = h('input', { type: 'number', step: '0.1', value: st.config[k] }); p1.append(h('label', { text: names[k] }), h('div', { class: 'row' }, inp, h('button', { class: 'btn sm gold', text: 'Сохранить', onclick: async () => { if (await arpc('farm_set_config', { p_key: k, p_value: +inp.value }, 'Сохранено')) G.sync(); } }))); });
    const p2 = h('div', { class: 'panel' }, h('h4', { text: 'Настройка питомцев' }), h('p', { class: 'sm', text: 'Доход/с — сколько монет питомец приносит в секунду. Вес — шанс выпадения: чем выше число, тем чаще питомец.' }));
    const t = h('table', { class: 't' }, h('tr', null, h('th', { text: 'Питомец' }), h('th', { text: 'Доход/с' }), h('th', { text: 'Вес' }), h('th')));
    G.cat.pets.slice().sort((a, b) => a.egg_id.localeCompare(b.egg_id) || a.income - b.income).forEach(p => {
      const inc = h('input', { type: 'number', step: 'any', value: p.income }), w = h('input', { type: 'number', step: 'any', value: p.weight });
      t.append(h('tr', null, h('td', null, h('b', { text: p.name }), h('br'), h('span', { class: 'badge', style: 'background:' + A.RARITY[p.rarity].color + ';color:#fff', text: A.RARITY[p.rarity].name + ' · ' + p.egg_id })), h('td', null, inc), h('td', null, w),
        h('td', null, h('button', { class: 'btn sm gold', text: 'Ок', onclick: async () => { if (await arpc('farm_admin_pet_type', { p_id: p.id, p_income: +inc.value, p_weight: +w.value }, 'Питомец обновлён')) { p.income = +inc.value; p.weight = +w.value; G.sync(); } } }))));
    }); p2.append(t);
    root.replaceChildren(p1, p2);
  }
  async function tabPlayers(root) {
    const q = h('input', { placeholder: 'Введи ник игрока' }), list = h('div', { class: 'list' }), det = h('div');
    const onlineLine = h('div', { class: 'panel', text: 'Активны за последние 2 минуты: загружаю…' });
    const load = async () => { list.replaceChildren(h('div', { class: 'empty', text: 'Загрузка…' })); const rows = await arpc('farm_admin_players', { p_query: q.value }); list.replaceChildren(); if (!rows) return; const cutoff = Date.now() - 120000; const active = rows.filter(r => r.updated_at && new Date(r.updated_at).getTime() >= cutoff).length; onlineLine.textContent = 'Активны за последние 2 минуты: ' + active + (rows.length >= 50 ? ' (среди последних 50 игроков)' : ''); if (!rows.length) list.append(h('div', { class: 'empty', text: 'Никого не найдено' })); rows.forEach(r => list.append(h('div', { class: 'it' }, h('span', { class: 'msg' }, r.username + ' ', h('span', { class: 'badge', text: r.role })), h('span', { text: fmt(r.coins) }), h('button', { class: 'btn sm', text: 'Открыть', onclick: () => open(r.user_id) })))); };
    const open = async id => {
      const d = await arpc('farm_admin_player', { p_user: id }); if (!d) return; const amt = h('input', { type: 'number', min: 1, value: 1000 });
      det.replaceChildren(h('div', { class: 'panel' }, h('h4', { text: d.username }), h('div', { class: 'kv' }, h('b', { text: 'Роль' }), h('span', { text: d.role }), h('b', { text: 'Монеты' }), h('span', { text: fmt(d.coins) }), h('b', { text: 'Всего заработано' }), h('span', { text: fmt(d.total_earned) }), h('b', { text: 'Зон открыто' }), h('span', { text: String(d.zones) }), h('b', { text: 'Питомцев' }), h('span', { text: d.pets.length + (' (на стойках: ' + d.pets.filter(p => p.stand != null).length + ')') }), h('b', { text: 'Яиц открыто' }), h('span', { text: String(d.eggs_opened) })),
        h('div', { class: 'row', style: 'margin-top:10px' }, amt, h('button', { class: 'btn sm gold', text: 'Выдать монеты', onclick: async () => { if (await arpc('farm_admin_grant_coins', { p_user: id, p_amount: Math.floor(+amt.value) }, 'Выдано')) { open(id); load(); } } }), h('button',{class:'btn sm',text:'Установить баланс',onclick:async()=>{const n=Math.floor(+amt.value);if(n<0||n>1000000000000)return UI.toast('Неверный баланс','warn');if(confirm('Установить игроку баланс '+fmt(n)+'?')&&await arpc('farm_admin_set_player_coins',{p_user:id,p_coins:n},'Баланс установлен')){open(id);load();}}})),
        d.role === 'GLOBAL_ADMIN' ? null : h('div', { class: 'row', style: 'margin-top:8px' }, d.role === 'admin' ? h('button', { class: 'btn sm red', text: 'Снять роль админа', onclick: async () => { if (await arpc('farm_admin_set_role', { p_user: id, p_role: 'player' }, 'Роль снята')) { open(id); load(); } } }) : h('button', { class: 'btn sm green', text: 'Назначить админом', onclick: async () => { if (await arpc('farm_admin_set_role', { p_user: id, p_role: 'admin' }, 'Роль выдана')) { open(id); load(); } } }))));
    };
    root.replaceChildren(h('div', { class: 'panel' }, h('h4', { text: 'Управление игроками' }), h('p', { class: 'sm', text: 'Найди игрока по нику, открой его карточку и выдай монеты или измени роль.' }), onlineLine), h('div', { class: 'panel' }, h('div', { class: 'row' }, q, h('button', { class: 'btn sm gold', text: 'Найти игрока', onclick: load })), list), det); q.addEventListener('keydown', e => { if (e.key === 'Enter') load(); }); load();
  }
  async function tabLog(root) {
    const rows = await arpc('farm_admin_log', { p_limit: 60 }); if (!rows) { root.replaceChildren(h('div', { class: 'empty', text: 'Не удалось загрузить' })); return; }
    const t = h('table', { class: 't' }, h('tr', null, h('th', { text: 'Время' }), h('th', { text: 'Игрок' }), h('th', { text: 'Действие' })));
    rows.forEach(r => t.append(h('tr', null, h('td', { text: new Date(r.created_at).toLocaleString('ru-RU') }), h('td', { text: r.username || '—' }), h('td', { text: r.action + ' ' + JSON.stringify(r.details) }))));
    root.replaceChildren(h('div', { class: 'panel' }, h('h4', { text: 'Последние действия администраторов' }), h('p', { class: 'sm', text: 'Здесь отображаются недавние изменения в игре.' }), t));
  }
})();
