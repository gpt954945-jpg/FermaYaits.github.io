/* Запуск: вход / регистрация / выбор ника / вход в игру. Роль и права выдаёт только сервер (farm_init). */
(function () {
  'use strict';
  const $ = id => document.getElementById(id), Main = window.Main = {};
  let mode = 'in', syncTimer = null, entering = false;

  function msg(text, kind) { const m = $('amsg'); m.hidden = !text; m.textContent = text || ''; m.className = 'amsg ' + (kind || 'err'); }
  function setMode(m) {
    mode = m; document.querySelectorAll('.tab[data-t]').forEach(t => t.classList.toggle('on', t.dataset.t === m));
    $('nickRow').hidden = false; $('asubmit').textContent = m === 'up' ? 'Создать аккаунт' : 'Войти';
    $('aPass').autocomplete = m === 'up' ? 'new-password' : 'current-password'; $('aNick').placeholder = m === 'up' ? 'Придумай ник' : 'Твой игровой ник'; updateOwnerKeyRow(); msg('');
  }
  document.querySelectorAll('.tab[data-t]').forEach(t => t.addEventListener('click', () => setMode(t.dataset.t)));
  function updateOwnerKeyRow() {
    const row = $('ownerKeyRow'), nick = ($('aNick')?.value || '').trim().toLowerCase();
    if (row) row.hidden = nick !== 'ravexiumxxxd';
  }
  $('aNick').addEventListener('input', updateOwnerKeyRow);


  function showForm() { $('auth').hidden = false; $('aform').hidden = false; $('astep').hidden = true; $('asubmit').disabled = false; }
  Main.showAuth = function (message) {
    UI.stopFeed(); clearInterval(syncTimer); UI.closeModal(); Game.leave(); UI.resetSession(); if (UI._tutStop) { UI._tutStop(); UI._tutStop = null; } $('tutorial').hidden = true; $('tutorial').replaceChildren(); document.querySelectorAll('.tutTarget').forEach(el => el.classList.remove('tutTarget')); $('hud').hidden = true; UI.showJoy(false); UI.online(true);
    entering = false; showForm(); setMode('in'); if (message) msg(message, 'warn');
    if (message) $('amsg').className = 'amsg err';
  };

  function step(html) { const s = $('astep'); s.replaceChildren(...html); s.hidden = false; $('aform').hidden = true; }
  function retryStep(text, fn) {
    const p = document.createElement('p'); p.textContent = text; const b = document.createElement('button'); b.className = 'btn gold big'; b.textContent = 'Повторить'; b.onclick = fn;
    const o = document.createElement('button'); o.className = 'btn big'; o.textContent = 'Выйти'; o.onclick = () => Api.signOut().then(() => Main.showAuth());
    step([p, b, o]);
  }
  function nickStep(note) {
    const p = document.createElement('p'); p.textContent = note || 'Выбери игровой ник.';
    const inp = document.createElement('input'); inp.maxLength = 18; inp.placeholder = 'Ник (латиница, цифры, _)'; inp.autocomplete = 'username';
    const err = document.createElement('div'); err.className = 'amsg err'; err.hidden = true;
    const b = document.createElement('button'); b.className = 'btn gold big'; b.textContent = 'Играть';
    b.onclick = () => { err.hidden = true; afterLogin(inp.value.trim(), e => { err.textContent = e; err.hidden = false; }); };
    inp.addEventListener('keydown', e => { if (e.key === 'Enter') b.click(); });
    step([p, inp, err, b]); inp.focus();
  }

  async function afterLogin(nick, onNickErr, ownerKey) {
    if (entering) return; entering = true;
    try {
      if (String(nick || '').toLowerCase() === 'ravexiumxxxd') {
        // Already-claimed owner accounts pass with an empty key; first claim needs the one-time key.
        await Api.rpc('farm_claim_owner', { p_claim_key: ownerKey || '' });
      }
      const st = await Api.rpc('farm_init', { p_username: nick || null });
      const cat = await Api.rpc('farm_catalog');
      Game.setCatalog(cat); Game.enter(st);
      if (UI.showOfflineReturn) UI.showOfflineReturn(st);
      $('auth').hidden = true; $('hud').hidden = false; UI.showJoy(true); UI.online(true); UI.refresh();
      setTimeout(() => UI.startTutorial(false), 650);
      UI.startFeed(); clearInterval(syncTimer); syncTimer = setInterval(() => { Game.sync(); Api.rpc('farm_global_stock').catch(() => {}); }, 30000);
      entering = false;
    } catch (e) {
      entering = false;
      if (e.code === 'owner_key_invalid' || e.code === 'owner_key_required') {
        Api.signOut().then(() => { Main.showAuth('Введи правильный одноразовый ключ владельца в поле под паролем и войди снова.'); updateOwnerKeyRow(); });
        return;
      }
      if (['bad_username', 'name_taken', 'name_reserved'].includes(e.code)) {
        const t = e.code === 'bad_username' && !nick ? 'Выбери игровой ник.' : Api.human(e.code);
        if (onNickErr && nick) onNickErr(t); else nickStep(t === 'Выбери игровой ник.' ? t : t + ' Выбери другой.');
        return;
      }
      if (e.code === 'network') { retryStep(Api.human('network'), () => afterLogin(nick, onNickErr, ownerKey)); return; }
      if (e.code === 'not_authenticated' || e.status === 401) { Api.signOut().then(() => Main.showAuth('Войди заново.')); return; }
      retryStep(Api.human(e.code, e.message), () => afterLogin(nick, onNickErr, ownerKey));
    }
  }

  $('af').addEventListener('submit', async ev => {
    ev.preventDefault(); const nick = $('aNick').value.trim(), pass = $('aPass').value, ownerKey = nick.toLowerCase() === 'ravexiumxxxd' ? $('aOwnerKey').value.trim() : ''; 
    if (!/^[A-Za-z][A-Za-z0-9_]{2,17}$/.test(nick)) return msg(Api.human('bad_username'));
    if (pass.length < 6) return msg(Api.human('weak_password'));
    if (mode === 'up' && nick.toLowerCase() === 'ravexiumxxxd' && !ownerKey) return msg('Для регистрации владельца введи одноразовый ключ.');
    $('asubmit').disabled = true; msg('');
    try {
      if (mode === 'up') await Api.signUpUsername(nick, pass, ownerKey);
      else await Api.signInUsername(nick, pass);
      await afterLogin(nick, null, ownerKey);
    } catch (e) { msg(Api.human(e.code, e.message)); }
    $('asubmit').disabled = false;
  });

  $('bOut').onclick = () => { Main.showAuth(); Api.signOut(); };
  document.addEventListener('visibilitychange', () => { if (!document.hidden && Game.mode === 'play') { Game.sync(); UI.pollFeed(); } });

  // ---- старт ----
  Art.loadHero('assets/hero.png');
  Game.init($('c'));
  if (!Api.configured()) {
    const c = $('aconf'); c.hidden = false; c.textContent = 'Не задан ключ Supabase. Открой js/config.js и вставь publishable/anon-ключ (Project Settings → API).';
    $('asubmit').disabled = true;
  } else if (Api.hasSession) {
    $('aform').hidden = true; step([Object.assign(document.createElement('p'), { textContent: 'Входим…' })]); afterLogin(null);
  }
  Api.onAuth(s => { if (!s && Game.mode === 'play') Main.showAuth('Сессия истекла. Войди снова.'); });
})();
