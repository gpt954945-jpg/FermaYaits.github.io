/* Игровой мир: карта, объекты, управление, рендер, действия. Деньги и покупки считает сервер (Supabase RPC). */
(function () {
  'use strict';
  const A = window.Art, TAU = Math.PI * 2;
  const ZW = 800, WW = 2400, WH = 1000, ROAD_Y = 500;
  const ZONE_NAMES = ['Луг', 'Дубовая роща', 'Золотые холмы'];
  const TIPS = [
    'Выращивай яйца на грядках и собирай готовый урожай.',
    'Покупай яйца, выращивай их и открывай новых питомцев.',
    'Редкие питомцы приносят в разы больше. Дон Сомбреро — легенда луга!',
    'Новая зона — новые грядки, стойки и яйца. Ворота ждут на дороге.',
    'Забирай монеты со стоек вовремя: копятся не дольше нескольких часов.',
    'События удваивают и утраивают доход. Следи за значком вверху.'
  ];

  let savedPotato = false;
  try { savedPotato = localStorage.getItem('farm.potato') === '1'; } catch (e) {}
  const G = {
    canvas: null, ctx: null, W: 0, H: 0, dpr: 1, scale: 1,
    state: null, cat: null, offset: 0,
    selectedCrop: 'blue_egg', mode: 'backdrop', // backdrop | play
    player: { x: 130, y: 520, vx: 0, vy: 0, face: 1, walkT: 0, pop: 0, tilt: 0 },
    cam: { x: 400, y: 500 }, keys: {}, joy: { x: 0, y: 0 }, target: null,
    objs: [], solids: [], trees: [], parts: [], floats: [], npc: null,
    busy: new Set(), pending: 0, needSync: false, queue: Promise.resolve(),
    nearest: null, time: 0, shake: 0, flash: 0, events: [], paused: false, lastAct: 0, touch: false, potatoMode: savedPotato
  };
  window.Game = G;

  /* ---------- вспомогательное ---------- */
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const lerp = (a, b, t) => a + (b - a) * t;
  function fmt(n) {
    n = Math.floor(n);
    if (n < 10000) return String(n).replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
    const u = [['Мрд', 1e9], ['М', 1e6], ['К', 1e3]];
    for (const [s, v] of u) if (n >= v) { const x = n / v; return (x >= 100 ? x.toFixed(0) : x >= 10 ? x.toFixed(1) : x.toFixed(2)).replace(/\.?0+$/, '') + s; }
    return String(n);
  }
  G.fmt = fmt;
  const zoneOf = x => clamp(Math.floor(x / ZW), 0, 2);
  const nowSrv = () => Date.now() / 1000 + G.offset;
  G.nowSrv = nowSrv;
  const crop = id => G.cat && G.cat.crops.find(c => c.id === id);
  const petType = id => G.cat && G.cat.pets.find(p => p.id === id);
  G.crop = crop; G.petType = petType;

  function growNeed(c) { const s = G.state; return c.grow_seconds / Math.max(0.01, s.config.growth_speed * s.event_mult.growth * (1 + ((G.upgradeLevels||{}).speed||0)*0.12)); }
  function plotInfo(i) {
    const s = G.state; const p = s.plots[String(i)]; if (!p) return null;
    const c = crop(p.crop); if (!c) return null;
    const need = growNeed(c), el = nowSrv() - p.at;
    return { crop: c, g: clamp(el / need, 0, 1), left: Math.max(0, need - el), ready: el >= need };
  }
  function petOnStand(i) { const s = G.state; return s && s.pets.find(p => p.stand === i) || null; }
  function accrued(pet) {
    const s = G.state, t = petType(pet.type); if (!t) return 0;
    const cap = Math.max(0.1, s.config.offline_cap_hours) * 3600;
    return t.income * s.config.income_mult * s.event_mult.income * (1 + ((G.upgradeLevels||{}).income||0)*0.15) * Math.min(cap, Math.max(0, nowSrv() - pet.collected_at));
  }
  G.accrued = accrued;
  function cropCount() { return G.state ? Object.values(G.state.crops).reduce((a, b) => a + b, 0) : 0; }
  function cropValue() {
    const s = G.state; if (!s) return 0; let v = 0;
    for (const [id, n] of Object.entries(s.crops)) { const c = crop(id); if (c) v += c.sell_price * n; }
    return Math.floor(v * s.config.sell_mult * s.event_mult.sell * (1 + ((G.upgradeLevels||{}).sell||0)*0.12));
  }
  G.cropCount = cropCount; G.cropValue = cropValue;

  /* ---------- построение мира ---------- */
  function build() {
    const objs = [], solids = [], rand = A.rng(20261104);
    const standX = [[230, 370, 510], [200, 310, 420, 530], [180, 270, 360, 450, 540]];
    let standIdx = 0;
    for (let z = 0; z < 3; z++) {
      const x0 = z * ZW;
      for (let k = 0; k < 6; k++) objs.push({ kind: 'plot', id: z * 6 + k, zone: z, x: x0 + 260 + (k % 3) * 140, y: 230 + Math.floor(k / 3) * 125, r: 70 });
      standX[z].forEach(sx => { const o = { kind: 'stand', id: standIdx++, zone: z, x: x0 + sx, y: 735, r: 64 }; objs.push(o); solids.push({ x: o.x, y: o.y - 4, r: 34 }); });
      if (z < 2) { const go = { kind: 'gate', id: z + 1, zone: z, x: x0 + ZW, y: ROAD_Y + 30, r: 95 }; objs.push(go); solids.push({ x: go.x - 47, y: go.y, r: 14 }, { x: go.x + 47, y: go.y, r: 14 }); }
    }
    const bo = { kind: 'board', id: 0, zone: 0, x: 215, y: 640, r: 80 }; objs.push(bo); solids.push({ x: bo.x, y: bo.y, r: 24 });
    // Единые глобальные точки магазина, посадочных яиц и продажи: не дублируем их в каждой зоне.
    const mo = { kind: 'market', id: 0, zone: 0, x: 110, y: 345, r: 100 }; objs.push(mo); solids.push({ x: mo.x - 20, y: mo.y - 10, r: 38 }, { x: mo.x + 20, y: mo.y - 10, r: 38 });
    const tx = 460, ty = 640; objs.push({ kind: 'stock', id: 0, zone: 0, x: tx, y: ty, r: 82 }); solids.push({ x: tx, y: ty - 8, r: 32 });
    const px = 620, py = 640; objs.push({ kind: 'plantshop', id: 0, zone: 0, x: px, y: py, r: 82 }); solids.push({ x: px, y: py - 8, r: 32 });
    G.npc = { kind: 'npc', id: 0, zone: 0, x: 105, y: 635, r: 80, hx: 105, hy: 635, tx: 105, ty: 635, wait: 1, say: '', sayT: 0, face: 1, walkT: 0 };
    objs.push(G.npc);
    // деревья: вокруг, не в рабочих зонах
    const avoid = [[150, 120, 660, 420], [0, 440, 800, 570], [140, 610, 660, 790], [610, 590, 800, 790], [10, 200, 210, 400], [40, 570, 290, 700]];
    const trees = [];
    for (let z = 0; z < 3; z++) {
      let tries = 0;
      while (trees.filter(t => t.zone === z).length < 26 && tries++ < 420) {
        const lx = 20 + rand() * (ZW - 40), ly = 40 + rand() * 930;
        if (avoid.some(a => lx > a[0] - 20 && lx < a[2] + 20 && ly > a[1] - 10 && ly < a[3] + 40)) continue;
        if (z === 0 && Math.hypot(lx - 660, ly - 880) < 120) continue;
        if (z === 1 && Math.hypot(lx - 170, ly - 880) < 120) continue;
        if (trees.some(t => Math.hypot(t.x - (z * ZW + lx), t.y - ly) < 54)) continue;
        if (Math.abs(lx - (ZW - 4)) < 30 || lx < 30) continue;
        trees.push({ kind: 'tree', zone: z, x: z * ZW + lx, y: ly, s: 0.8 + rand() * 0.5, seed: Math.floor(rand() * 99) });
      }
    }
    trees.forEach(t => solids.push({ x: t.x, y: t.y - 4, r: 13 * t.s }));
    solids.push({ x: 660, y: 880, r: 62 }, { x: ZW + 170, y: 880, r: 62 });
    G.objs = objs; G.trees = trees; G.solids = solids;
    G.ponds = [{ x: 660, y: 880 }, { x: ZW + 170, y: 880 }];
    buildStatic();
  }

  function buildStatic() {
    const mobile = G.touch;
    const RS = mobile ? 0.72 : 1.0, c = document.createElement('canvas');
    c.width = Math.round(WW * RS); c.height = Math.round(WH * RS);
    const x = c.getContext('2d'); x.scale(RS, RS);
    const rand = A.rng(77);
    for (let z = 0; z < 3; z++) {
      const th = A.THEMES[z], x0 = z * ZW;
      x.fillStyle = th.grass[0]; x.fillRect(x0, 0, ZW, WH);
      for (let gy = 0; gy < WH; gy += 50) for (let gx = 0; gx < ZW; gx += 50) { x.fillStyle = th.grass[((gx / 50 + gy / 50) & 1) ? 1 : 2]; x.globalAlpha = 0.45; x.fillRect(x0 + gx, gy, 50, 50); }
      x.globalAlpha = 1;
      for (let i = 0; i < 700; i++) { const px = x0 + rand() * ZW, py = rand() * WH; x.strokeStyle = th.tuft; x.lineWidth = 1.8; x.globalAlpha = 0.5; x.beginPath(); x.moveTo(px, py); x.lineTo(px - 2, py - 7); x.moveTo(px, py); x.lineTo(px + 3, py - 6); x.stroke(); }
      x.globalAlpha = 1;
      // поле: тёмная подложка вокруг грядок
      x.fillStyle = 'rgba(70,45,20,.18)'; A.rr(x, x0 + 160, 120, 500, 300, 26); x.fill();
      // дорога
      x.fillStyle = th.pathEdge; A.rr(x, x0 - 4, ROAD_Y - 52, ZW + 8, 104, 18); x.fill();
      x.fillStyle = th.path; A.rr(x, x0 - 4, ROAD_Y - 44, ZW + 8, 88, 14); x.fill();
      for (let i = 0; i < 60; i++) { x.fillStyle = 'rgba(160,120,60,.25)'; const sx = x0 + rand() * ZW, sy = ROAD_Y - 38 + rand() * 76; A.ell(x, sx, sy, 7 + rand() * 6, 3 + rand() * 2); x.fill(); }
      // подъезды к полю, стойкам, рынку
      x.fillStyle = th.path; A.rr(x, x0 + 380, 410, 40, 60, 8); x.fill(); A.rr(x, x0 + 380, 550, 40, 120, 8); x.fill();
      A.rr(x, x0 + 640, 550, 60, 140, 8); x.fill(); A.rr(x, x0 + 70, 400, 60, 70, 8); x.fill();
      // цветы
      const fc = ['#ff6b8b', '#ffd23f', '#fff', '#b58cff', '#6bc8ff'];
      for (let i = 0; i < 70; i++) { const px = x0 + rand() * ZW, py = rand() * WH; if (Math.abs(py - ROAD_Y) < 56) continue; A.drawFlower(x, px, py, fc[Math.floor(rand() * 5)]); }
      for (let i = 0; i < 9; i++) { const px = x0 + 30 + rand() * (ZW - 60), py = 40 + rand() * 920; if (Math.abs(py - ROAD_Y) < 70) continue; A.drawRock(x, px, py, 0.6 + rand() * 0.6); }
    }
    for (let k = 1; k <= 2; k++) { // вертикальные заборы на границах зон
      const bx = k * ZW; x.strokeStyle = '#a8723e'; x.lineWidth = 5; x.lineCap = 'round';
      [[20, ROAD_Y - 70], [ROAD_Y + 60, WH - 20]].forEach(([a, b]) => { x.beginPath(); x.moveTo(bx, a); x.lineTo(bx, b); x.stroke(); for (let py = a; py <= b; py += 34) { x.fillStyle = '#c4894d'; A.rr(x, bx - 6, py - 8, 12, 30, 3); x.fill(); x.strokeStyle = 'rgba(40,24,12,.5)'; x.lineWidth = 1.6; x.stroke(); x.strokeStyle = '#a8723e'; x.lineWidth = 5; } });
    }
    G.ponds.forEach(p => A.drawPond(x, p.x, p.y, 78, 38, 0));
    // площадь у спавна
    x.fillStyle = 'rgba(255,255,255,.12)'; A.ell(x, 130, 560, 130, 60); x.fill();
    G.static = c; G.staticRS = RS;
  }

  /* ---------- состояние ---------- */
  G.setCatalog = function (cat) { G.cat = cat; };
  G.applyState = function (st) {
    G.state = st; G.offset = st.now - Date.now() / 1000;
    if (!crop(G.selectedCrop)) G.selectedCrop = G.cat && G.cat.crops[0] ? G.cat.crops[0].id : 'blue_egg';
    window.UI && UI.refresh();
  };
  G.enter = function (st) {
    G.mode = 'play'; G.applyState(st);
    G.player.x = 130; G.player.y = 520; G.player.pop = 0; G.target = null; G.cam.x = 130; G.cam.y = 520;
    burst(130, 500, 'spark', 26, '#ffe27a');
  };
  G.leave = function () { G.mode = 'backdrop'; G.state = null; G.target = null; G.keys = {}; G.joy.x = G.joy.y = 0; G.nearest = null; G.busy.clear(); };
  G.setEvents = function (ev) { G.events = ev || []; };

  /* ---------- частицы ---------- */
  function burst(x, y, type, n, color, spread) {
    for (let i = 0; i < n && G.parts.length < (G.potatoMode ? 36 : 260); i++) {
      const a = Math.random() * TAU, sp = (spread || 120) * (0.4 + Math.random());
      G.parts.push({ t: type, x, y, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp - 90, life: 0.7 + Math.random() * 0.6, age: 0, c: color, s: 3 + Math.random() * 4, rot: Math.random() * TAU, vr: (Math.random() - 0.5) * 12 });
    }
  }
  function floatText(x, y, s, color, size) { G.floats.push({ x, y, s, color: color || '#fff', size: size || 16, age: 0, life: 1.3 }); }
  G.burst = burst; G.floatText = floatText;
  G.confetti = function (x, y, n) { const cols = ['#ff5a7a', '#ffd23f', '#5ad2ff', '#7dff7a', '#c27bff']; for (let i = 0; i < n && G.parts.length < (G.potatoMode ? 36 : 260); i++) burst(x, y, 'conf', 1, cols[i % 5], 260); };

  /* ---------- подсказки действий ---------- */
  function describe(o) {
    const s = G.state; if (!s || o.zone >= s.zones && o.kind !== 'gate') return null;
    switch (o.kind) {
      case 'plot': {
        const info = plotInfo(o.id);
        if (!info) { const c = crop(G.selectedCrop); if (!c) return null; return { text: 'Посадить яйцо: ' + c.name, sub: '−' + fmt(c.seed_cost), ok: s.coins >= c.seed_cost, why: 'Не хватает монет' }; }
        if (info.ready) return { text: 'Собрать яйцо: ' + info.crop.name, ok: true };
        return { text: 'Яйцо «' + info.crop.name + '» созревает', sub: fmtTime(info.left), ok: false, passive: true };
      }
      case 'stand': {
        const pet = petOnStand(o.id);
        if (!pet) { const free = s.pets.filter(p => p.stand == null).length; return { text: 'Поставить питомца', sub: free ? '' : 'нет свободных', ok: free > 0, why: 'В рюкзаке нет свободных питомцев. Купи яйцо!' }; }
        const a = Math.floor(accrued(pet)); const t = petType(pet.type);
        return a >= 1 ? { text: 'Забрать монеты', sub: '+' + fmt(a), ok: true } : { text: (t ? t.name : '') + ' копит доход', ok: false, passive: true };
      }
      case 'market': return { text: 'Открыть рынок', sub: 'Продажа собранных яиц', ok: true };
      case 'stock': return { text: 'Инкубационные яйца', sub: 'Питомцы и общий сток', ok: true };
      case 'plantshop': return { text: 'Яйца для посадки', sub: 'Выбери яйцо для грядок', ok: true };
      case 'gate': {
        if (s.zones !== o.id) return null; const z = G.cat.zones.find(q => q.zone === o.id + 1); if (!z) return null;
        return { text: 'Открыть: ' + z.name, sub: '−' + fmt(z.price), ok: s.coins >= z.price, why: 'Не хватает монет' };
      }
      case 'board': return { text: 'Таблица лидеров', ok: true };
      case 'npc': return { text: 'Поговорить с Доном', ok: true };
    }
    return null;
  }
  function fmtTime(sec) { sec = Math.ceil(sec); const m = Math.floor(sec / 60), s = sec % 60; return m + ':' + String(s).padStart(2, '0'); }
  G.describe = describe;

  /* ---------- выполнение действий ---------- */
  function enqueue(fn) { G.pending++; G.queue = G.queue.then(fn).catch(() => { }).finally(() => { G.pending--; if (G.pending === 0 && G.needSync) { G.needSync = false; G.sync(); } }); return G.queue; }
  G.sync = async function () {
    if (!window.Api.hasSession || G.pending) return;
    try { const st = await Api.rpc('farm_state'); G.applyState(st); UI.online(true); }
    catch (e) { if (e.code === 'network') UI.online(false); else if (e.code === 'not_authenticated' || e.code === 'no_profile') UI.sessionLost(); }
  };
  async function call(name, args) {
    try { const r = await Api.rpc(name, args); UI.online(true); return r; }
    catch (e) {
      if (e.code === 'network') UI.online(false);
      G.needSync = true;
      if (e.code === 'not_authenticated') UI.sessionLost();
      else UI.toast(Api.human(e.code, e.message), 'err');
      throw e;
    }
  }

  G.act = function (o) {
    if (!G.state || G.paused) return;
    const d = describe(o); if (!d) return;
    const now = performance.now(); if (now - G.lastAct < 140) return; G.lastAct = now;
    if (d.passive) { return; }
    if (!d.ok) { UI.toast(d.why || 'Сейчас нельзя', 'warn'); UI.shake(); return; }
    const key = o.kind + ':' + o.id; if (G.busy.has(key)) return;
    const s = G.state;
    switch (o.kind) {
      case 'plot': {
        const info = plotInfo(o.id);
        if (!info) { // посадка (оптимистично)
          const c = crop(G.selectedCrop); s.coins -= c.seed_cost; s.plots[String(o.id)] = { crop: c.id, at: nowSrv() };
          burst(o.x, o.y, 'dirt', 10, '#7a4d2b', 90); UI.sfx('plant'); UI.refresh();
          G.busy.add(key);
          enqueue(async () => { try { const st = await call('farm_plant', { p_plot: o.id, p_crop: c.id }); if (G.pending === 1) G.applyState(st); } catch (e) { } finally { G.busy.delete(key); } });
        } else if (info.ready) {
          delete s.plots[String(o.id)]; s.crops[info.crop.id] = (s.crops[info.crop.id] || 0) + 1;
          burst(o.x, o.y - 10, 'spark', 12, A.eggColors(info.crop.id)[1], 130); floatText(o.x, o.y - 40, '+1 яйцо «' + info.crop.name + '»', '#fff', 15); UI.sfx('harvest'); UI.refresh();
          G.busy.add(key);
          enqueue(async () => { try { const st = await call('farm_harvest', { p_plot: o.id }); if (G.pending === 1) G.applyState(st); } catch (e) { } finally { G.busy.delete(key); } });
        }
        break;
      }
      case 'market': UI.openMarket(); break;
      case 'stand': {
        const pet = petOnStand(o.id);
        if (!pet) { UI.openPetPicker(o.id); break; }
        G.busy.add(key);
        enqueue(async () => {
          try {
            const st = await call('farm_collect', { p_stand: o.id }); const paid = st.paid || 0; G.applyState(st);
            if (paid > 0) { coinShower(o.x, o.y - 50, Math.min(16, 4 + Math.floor(paid / 200))); floatText(o.x, o.y - 100, '+' + fmt(paid), '#ffe27a', 20); UI.sfx('coin'); }
          } catch (e) { } finally { G.busy.delete(key); }
        });
        break;
      }
      case 'gate': {
        G.busy.add(key);
        enqueue(async () => {
          try { const st = await call('farm_unlock_zone'); G.applyState(st); G.confetti(o.x, o.y - 60, 60); G.flash = 0.6; UI.sfx('unlock'); UI.toast('Открыта зона: ' + ZONE_NAMES[st.zones - 1] + '!', 'ok'); }
          catch (e) { } finally { G.busy.delete(key); }
        });
        break;
      }
      case 'board': UI.openBoard(); break;
      case 'stock': UI.openEggStock(); break;
      case 'plantshop': UI.openPlantEggShop(); break;
      case 'npc': { const n = G.npc; n.say = TIPS[Math.floor(Math.random() * TIPS.length)]; n.sayT = 5; burst(n.x, n.y - 50, 'spark', 8, '#ffe27a', 80); UI.sfx('pop'); break; }
    }
  };
  function coinShower(x, y, n) { for (let i = 0; i < n && G.parts.length < (G.potatoMode ? 36 : 260); i++) { const a = -Math.PI / 2 + (Math.random() - 0.5) * 1.6, sp = 150 + Math.random() * 180; G.parts.push({ t: 'coin', x, y, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp, life: 1 + Math.random() * 0.5, age: 0, s: 6 + Math.random() * 3, rot: 0, vr: 0 }); } }
  G.coinShower = coinShower;

  /* ---------- ввод ---------- */
  const typing = () => { const a = document.activeElement; return a && /^(INPUT|TEXTAREA|SELECT)$/.test(a.tagName); };
  window.addEventListener('keydown', e => {
    if (typing() || G.paused) return;
    const k = e.key.toLowerCase();
    if (['arrowup', 'arrowdown', 'arrowleft', 'arrowright', ' ', 'w', 'a', 's', 'd'].includes(k)) e.preventDefault();
    G.keys[k] = true; if (k !== 'e' && k !== ' ' && k !== 'enter') G.target = null;
    if ((k === 'e' || k === ' ' || k === 'enter') && !e.repeat) G.interact();
    if (k === 'e' && e.repeat) G.interact(true);
    if (k === 'b') UI.openBag();
  });
  window.addEventListener('keyup', e => { G.keys[e.key.toLowerCase()] = false; });
  window.addEventListener('blur', () => { G.keys = {}; });

  G.interact = function (repeat) { if (G.mode !== 'play' || G.paused) return; if (G.nearest) G.act(G.nearest); };

  function screenToWorld(sx, sy) { return { x: (sx - G.W / 2) / G.scale + G.cam.x, y: (sy - G.H / 2) / G.scale + G.cam.y }; }
  function hitObject(wx, wy) {
    let best = null, bd = 1e9;
    G.objs.forEach(o => { if (o.kind === 'tree') return; const d = describeVisible(o) ? Math.hypot(o.x - wx, (o.y - 28) - wy) : 1e9; const lim = o.kind === 'plot' ? 62 : ['market','stock','plantshop'].includes(o.kind) ? 70 : 52; if (d < lim && d < bd) { best = o; bd = d; } });
    return best;
  }
  function describeVisible(o) { return G.state && (o.kind === 'gate' ? G.state.zones === o.id : o.zone < G.state.zones); }
  G.pointerDown = function (sx, sy) {
    if (G.mode !== 'play' || G.paused) return;
    const w = screenToWorld(sx, sy), o = hitObject(w.x, w.y);
    const maxX = G.state.zones * ZW - 22;
    G.target = { x: clamp(w.x, 24, maxX), y: clamp(w.y, 70, 950), obj: o };
    if (o) { G.target.x = clamp(o.x, 24, maxX); G.target.y = o.kind === 'plot' ? o.y + 10 : o.y + (o.kind === 'gate' ? 0 : 48); }
    burst(w.x, w.y, 'ring', 1, '#fff', 0);
  };

  /* ---------- обновление ---------- */
  function update(dt) {
    G.time += dt;
    const p = G.player;
    if (G.mode === 'play' && G.state && !G.paused) {
      let ix = 0, iy = 0; const k = G.keys;
      if (k['a'] || k['arrowleft']) ix -= 1; if (k['d'] || k['arrowright']) ix += 1;
      if (k['w'] || k['arrowup']) iy -= 1; if (k['s'] || k['arrowdown']) iy += 1;
      if (G.joy.x || G.joy.y) { ix = G.joy.x; iy = G.joy.y; G.target = null; }
      if (!ix && !iy && G.target) {
        const dx = G.target.x - p.x, dy = G.target.y - p.y, d = Math.hypot(dx, dy);
        const stopAt = G.target.obj ? 10 : 6;
        if (d < stopAt) { const o = G.target.obj; G.target = null; if (o) G.act(o); }
        else { ix = dx / d; iy = dy / d; }
      }
      const len = Math.hypot(ix, iy); if (len > 1) { ix /= len; iy /= len; }
      const sp = 235;
      p.vx = lerp(p.vx, ix * sp, Math.min(1, dt * 14)); p.vy = lerp(p.vy, iy * sp, Math.min(1, dt * 14));
      p.x += p.vx * dt; p.y += p.vy * dt;
      for (let it = 0; it < 2; it++) G.solids.forEach(s => { const dx = p.x - s.x, dy = (p.y - s.y) * 1.25, d = Math.hypot(dx, dy), m = s.r + 12; if (d < m && d > 0.001) { const push = (m - d) / d; p.x += dx * push; p.y += (dy / 1.25) * push; } });
      p.x = clamp(p.x, 26, G.state.zones * ZW - 22); p.y = clamp(p.y, 70, 955);
      if (Math.abs(p.vx) > 8) p.face = p.vx > 0 ? 1 : -1;
      const mv = Math.hypot(p.vx, p.vy); p.walkT += dt * (mv > 12 ? 1 : 0) * 1; p.tilt = lerp(p.tilt, clamp(p.vx / 700, -0.18, 0.18), Math.min(1, dt * 10));
      p.pop = Math.min(1, p.pop + dt * 2.2);
      if (mv > 60 && Math.random() < dt * 9) G.parts.push({ t: 'dust', x: p.x, y: p.y, vx: -p.vx * 0.1, vy: -14, life: 0.5, age: 0, s: 3 + Math.random() * 3, rot: 0, vr: 0 });
      // ближайший объект
      let best = null, bd = 1e9;
      G.objs.forEach(o => { if (o.kind === 'tree' || !describeVisible(o)) return; const d = Math.hypot(o.x - p.x, (o.y - p.y) * 1.2); if (d < o.r && d < bd) { best = o; bd = d; } });
      G.nearest = best; const bd2 = best ? describe(best) : null; UI.setPrompt(bd2 ? Object.assign({ kind: best.kind }, bd2) : null);
      G.cam.x = lerp(G.cam.x, p.x, Math.min(1, dt * 5)); G.cam.y = lerp(G.cam.y, clamp(p.y, 300, 720) * 0.6 + p.y * 0.4, Math.min(1, dt * 5));
      const hw = G.W / G.scale / 2, hh = G.H / G.scale / 2;
      G.cam.x = hw * 2 < WW ? clamp(G.cam.x, hw - 30, WW - hw + 30) : WW / 2;
      G.cam.y = hh * 2 < WH + 60 ? clamp(G.cam.y, hh - 30, WH - hh + 30) : WH / 2;
    } else if (G.mode === 'backdrop') {
      G.cam.x = 500 + Math.sin(G.time * 0.05) * 420 + G.time * 0; G.cam.y = 480 + Math.sin(G.time * 0.07) * 60;
    }
    // NPC
    const n = G.npc;
    if (n) {
      n.wait -= dt; if (n.sayT > 0) n.sayT -= dt;
      const dx = n.tx - n.x, dy = n.ty - n.y, d = Math.hypot(dx, dy);
      if (d > 4) { n.x += dx / d * 42 * dt; n.y += dy / d * 42 * dt; n.walkT += dt; n.face = dx > 0 ? 1 : -1; }
      else if (n.wait <= 0) { n.tx = n.hx + (Math.random() - 0.5) * 90; n.ty = n.hy + (Math.random() - 0.5) * 50; n.wait = 2 + Math.random() * 3; if (Math.random() < 0.35) { n.say = ['¡Hola, амиго!', 'Добро пожаловать на ферму!', '¡Arriba!'][Math.floor(Math.random() * 3)]; n.sayT = 2.6; } }
    }
    // погода от событий
    if (G.events.length && G.mode === 'play') {
      const v = viewRect(); G.events.forEach(ev => {
        const rate = 14 * dt; let cnt = Math.floor(rate) + (Math.random() < rate % 1 ? 1 : 0);
        while (cnt-- > 0 && G.parts.length < (G.potatoMode ? 28 : 240)) {
          const x = v.x0 + Math.random() * (v.x1 - v.x0), y = v.y0 - 20;
          if (ev.kind === 'income') G.parts.push({ t: 'coin', x, y, vx: 0, vy: 120 + Math.random() * 80, life: 4, age: 0, s: 5 + Math.random() * 3, rot: 0, vr: 0, fall: true });
          else if (ev.kind === 'growth') G.parts.push({ t: 'drop', x, y, vx: -30, vy: 520 + Math.random() * 120, life: 1.6, age: 0, s: 1, rot: 0, vr: 0, fall: true });
          else G.parts.push({ t: 'petal', x, y, vx: 30 + Math.random() * 40, vy: 60 + Math.random() * 50, life: 6, age: 0, s: 3 + Math.random() * 3, rot: Math.random() * TAU, vr: 2, fall: true });
        }
      });
    }
    for (let i = G.parts.length - 1; i >= 0; i--) {
      const q = G.parts[i]; q.age += dt; if (q.age > q.life) { G.parts.splice(i, 1); continue; }
      if (q.t === 'coin' || q.t === 'spark' || q.t === 'conf' || q.t === 'dirt') { if (!q.fall) q.vy += 520 * dt; }
      q.x += q.vx * dt; q.y += q.vy * dt; q.rot += q.vr * dt;
    }
    for (let i = G.floats.length - 1; i >= 0; i--) { const f = G.floats[i]; f.age += dt; f.y -= 34 * dt; if (f.age > f.life) G.floats.splice(i, 1); }
    G.shake = Math.max(0, G.shake - dt * 2.5); G.flash = Math.max(0, G.flash - dt * 1.8);
  }

  function viewRect() { const hw = G.W / G.scale / 2, hh = G.H / G.scale / 2; return { x0: G.cam.x - hw, x1: G.cam.x + hw, y0: G.cam.y - hh, y1: G.cam.y + hh }; }

  /* ---------- рендер ---------- */
  function render() {
    const c = G.ctx, s = G.scale, st = G.state, t = G.time;
    c.setTransform(1, 0, 0, 1, 0, 0);
    c.fillStyle = '#2d7a4a'; c.fillRect(0, 0, G.W, G.H);
    c.save();
    const sh = G.shake * 10; const ox = (Math.random() - 0.5) * sh, oy = (Math.random() - 0.5) * sh;
    c.translate(G.W / 2 + ox, G.H / 2 + oy); c.scale(s, s); c.translate(-G.cam.x, -G.cam.y);
    // фон за пределами мира
    c.fillStyle = '#245f3c'; const v = viewRect(); c.fillRect(v.x0 - 10, v.y0 - 10, v.x1 - v.x0 + 20, v.y1 - v.y0 + 20);
    c.drawImage(G.static, 0, 0, WW, WH);
    // вода (мерцание)
    G.ponds.forEach(p => { c.strokeStyle = 'rgba(255,255,255,.5)'; c.lineWidth = 2; c.beginPath(); c.ellipse(p.x + Math.sin(t * 1.3) * 10, p.y + 2, 16 + Math.sin(t * 2) * 3, 5, 0, 0, TAU); c.stroke(); });
    // y-сортировка
    const list = [];
    const unlocked = st ? st.zones : 3;
    G.trees.forEach(tr => { if (tr.x > v.x0 - 80 && tr.x < v.x1 + 80 && tr.y > v.y0 - 40 && tr.y < v.y1 + 120) list.push({ y: tr.y, f: () => A.drawTree(c, tr.x, tr.y, tr.s, tr.zone, tr.seed) }); });
    G.objs.forEach(o => {
      if (o.kind === 'tree') return;
      if (o.x < v.x0 - 120 || o.x > v.x1 + 120) return;
      if (o.kind === 'plot') list.push({ y: o.y - 40, f: () => drawPlotObj(c, o, t) });
      else if (o.kind === 'stand') list.push({ y: o.y, f: () => drawStandObj(c, o, t) });
      else if (o.kind === 'market') list.push({ y: o.y, f: () => A.drawMarket(c, o.x, o.y, t) });
      else if (o.kind === 'plantshop') list.push({ y: o.y, f: () => { A.drawEggMachine(c,o.x,o.y,'meadow',t,0,'ПОСАДКА'); A.text(c,'ЯЙЦА ДЛЯ ГРЯДОК',o.x,o.y-125,10,'#ffe27a'); } });
      else if (o.kind === 'stock') list.push({ y: o.y, f: () => {
        A.drawStand(c, o.x, o.y, o.zone);
        A.drawEgg(c, ['meadow','grove','peak'][o.zone], o.x, o.y - 48, .58, t, 0);
        A.text(c, 'СТЕНД ЯИЦ', o.x, o.y - 93, 11, '#ffe27a');
        const items=(G.stockDisplay||[]).slice(0,4), bx=o.x-82, by=o.y-184;
        A.rr(c,bx,by,164,76,8); c.fillStyle='#fff4d5'; c.fill(); A.outline(c,2.5);
        c.fillStyle='#8d5a31'; A.rr(c,bx+3,by+3,158,14,5); c.fill();
        A.text(c,'СЕЙЧАС В ПРОДАЖЕ',o.x,by+10,8,'#fff4d5');
        if(items.length){items.forEach((e,i)=>{const col=i%2,row=Math.floor(i/2), xx=bx+7+col*80, yy=by+23+row*25; A.drawEgg(c,e.id,xx+8,yy+15,.19,t,0); A.text(c,String(e.name||'Яйцо').slice(0,10),xx+44,yy+7,7,'#56371e'); A.text(c,'×'+e.quantity,xx+44,yy+18,8,'#23733a');});}
        else A.text(c,'Загрузка ассортимента…',o.x,by+47,8,'#56371e');
      } });
      else if (o.kind === 'board') list.push({ y: o.y, f: () => A.drawBoard(c, o.x, o.y) });
      else if (o.kind === 'npc') list.push({ y: o.y, f: () => drawNpc(c, o) });
    });
    if (G.mode === 'play') list.push({ y: G.player.y, f: () => drawPlayer(c) });
    list.sort((a, b) => a.y - b.y).forEach(i => i.f());
    // подсветка выбранного объекта
    if (G.nearest && G.mode === 'play') { const o = G.nearest, pulse = 0.5 + 0.5 * Math.sin(t * 6); const d = describe(o); c.strokeStyle = d && d.ok ? 'rgba(255,255,255,' + (0.55 + 0.4 * pulse) + ')' : 'rgba(255,255,255,.3)'; c.lineWidth = 3; c.setLineDash([8, 7]); c.lineDashOffset = -t * 20; c.beginPath(); c.ellipse(o.x, o.y + (o.kind === 'plot' ? 36 : 8), o.kind === 'plot' ? 66 : 54, o.kind === 'plot' ? 16 : 14, 0, 0, TAU); c.stroke(); c.setLineDash([]); }
    // Подсказка обучения: пульсирующая рамка прямо на нужном объекте мира.
    if (G.tutorialWorld && G.mode === 'play') {
      const q = G.tutorialWorld, pulse = 1 + Math.sin(t * 5) * 0.12;
      c.save(); c.globalAlpha = 0.95; c.strokeStyle = '#ffe27a'; c.lineWidth = 6; c.setLineDash([10, 7]);
      c.beginPath(); c.ellipse(q.x, q.y + 5, 62 * pulse, 24 * pulse, 0, 0, TAU); c.stroke(); c.setLineDash([]);
      A.text(c, 'СЮДА', q.x, q.y - 65, 17, '#ffe27a'); c.restore();
    }
    // цель тапа
    if (G.target && G.mode === 'play') { c.strokeStyle = 'rgba(255,255,255,.7)'; c.lineWidth = 2.5; c.beginPath(); c.arc(G.target.x, G.target.y, 8 + Math.sin(t * 8) * 2, 0, TAU); c.stroke(); }
    // туман закрытых зон
    if (unlocked < 3) {
      const fx = unlocked * ZW; const g = c.createLinearGradient(fx - 20, 0, fx + 120, 0); g.addColorStop(0, 'rgba(8,28,20,0)'); g.addColorStop(1, 'rgba(8,28,20,.62)');
      c.fillStyle = g; c.fillRect(fx - 20, 0, 140, WH); c.fillStyle = 'rgba(8,28,20,.62)'; c.fillRect(fx + 120, 0, WW - fx - 120, WH);
      c.fillStyle = 'rgba(220,235,255,.06)'; for (let i = 0; i < 8; i++) { A.ell(c, fx + 140 + ((t * 18 + i * 330) % (WW - fx)), 150 + i * 110, 160, 40); c.fill(); }
    }
    // ворота поверх тумана
    G.objs.forEach(o => { if (o.kind !== 'gate') return; if (o.x < v.x0 - 120 || o.x > v.x1 + 120) return; const locked = st ? st.zones <= o.id : false; const z = G.cat && G.cat.zones.find(q => q.zone === o.id + 1); A.drawGate(c, o.x, o.y, locked, z ? fmt(z.price) : '', t, z ? z.name : ''); });
    // частицы и числа
    G.parts.forEach(q => drawPart(c, q));
    G.floats.forEach(f => { c.globalAlpha = clamp(1.6 - f.age / f.life * 1.6, 0, 1); A.text(c, f.s, f.x, f.y, f.size, f.color); c.globalAlpha = 1; });
    c.restore();
    // экранные эффекты
    if (G.flash > 0) { c.fillStyle = 'rgba(255,245,200,' + G.flash * 0.55 + ')'; c.fillRect(0, 0, G.W, G.H); }
    const vg = c.createRadialGradient(G.W / 2, G.H / 2, Math.min(G.W, G.H) * 0.45, G.W / 2, G.H / 2, Math.max(G.W, G.H) * 0.78); vg.addColorStop(0, 'rgba(0,20,10,0)'); vg.addColorStop(1, 'rgba(0,20,10,.32)');
    c.fillStyle = vg; c.fillRect(0, 0, G.W, G.H);
  }

  function drawPart(c, q) {
    const k = 1 - q.age / q.life;
    if (q.t === 'coin') { c.globalAlpha = Math.min(1, k * 3); A.drawCoin(c, q.x, q.y, q.s * (0.65 + 0.35 * Math.abs(Math.cos(q.age * 8)))); c.globalAlpha = 1; }
    else if (q.t === 'spark') { c.globalAlpha = k; c.fillStyle = q.c; c.save(); c.translate(q.x, q.y); c.rotate(q.rot); c.beginPath(); for (let i = 0; i < 4; i++) { c.lineTo(Math.cos(i * Math.PI / 2) * q.s, Math.sin(i * Math.PI / 2) * q.s); c.lineTo(Math.cos(i * Math.PI / 2 + Math.PI / 4) * q.s * 0.35, Math.sin(i * Math.PI / 2 + Math.PI / 4) * q.s * 0.35); } c.fill(); c.restore(); c.globalAlpha = 1; }
    else if (q.t === 'conf') { c.globalAlpha = Math.min(1, k * 2); c.fillStyle = q.c; c.save(); c.translate(q.x, q.y); c.rotate(q.rot); c.fillRect(-q.s / 2, -q.s / 4, q.s, q.s / 2); c.restore(); c.globalAlpha = 1; }
    else if (q.t === 'dirt') { c.globalAlpha = k; c.fillStyle = q.c; c.beginPath(); c.arc(q.x, q.y, q.s * 0.7, 0, TAU); c.fill(); c.globalAlpha = 1; }
    else if (q.t === 'dust') { c.globalAlpha = k * 0.4; c.fillStyle = '#fff'; c.beginPath(); c.arc(q.x, q.y, q.s * (2 - k), 0, TAU); c.fill(); c.globalAlpha = 1; }
    else if (q.t === 'ring') { c.globalAlpha = k * 0.8; c.strokeStyle = '#fff'; c.lineWidth = 3; c.beginPath(); c.arc(q.x, q.y, 6 + (1 - k) * 22, 0, TAU); c.stroke(); c.globalAlpha = 1; }
    else if (q.t === 'drop') { c.globalAlpha = 0.55; c.strokeStyle = '#bfe6ff'; c.lineWidth = 1.8; c.beginPath(); c.moveTo(q.x, q.y); c.lineTo(q.x + 3, q.y + 14); c.stroke(); c.globalAlpha = 1; }
    else if (q.t === 'petal') { c.globalAlpha = 0.85; c.fillStyle = '#ffd0e4'; c.save(); c.translate(q.x, q.y); c.rotate(q.rot); A.ell(c, 0, 0, q.s, q.s * 0.55); c.fill(); c.restore(); c.globalAlpha = 1; }
  }

  function drawPlotObj(c, o, t) {
    A.drawPlot(c, o.x, o.y, { wet: G.events.some(e => e.kind === 'growth') });
    const info = G.state ? plotInfo(o.id) : null;
    if (info) {
      const eggKind = info.crop.id || ['meadow','grove','peak'][o.zone] || 'meadow';
      const growth = Math.max(0, Math.min(1, info.g));
      if (growth < 0.42) {
        A.drawEgg(c, eggKind, o.x, o.y - 24, 0.48 + growth * 0.16, t, Math.sin(t * 2.2) * 0.035, growth > 0.18 ? 1 : 0);
      } else {
        const count = growth > 0.82 ? 3 : 2;
        for (let ei = 0; ei < count; ei++) {
          const ex = o.x + (ei - (count - 1) / 2) * 27;
          A.drawEgg(c, eggKind, ex, o.y - 25 - (ei % 2) * 3, 0.43 + growth * 0.08, t + ei * 0.4, Math.sin(t * 2 + ei) * 0.025, info.ready ? 2 : 0);
        }
      }
      if (info.ready) {
        const b = Math.sin(t * 5) * 3; c.globalAlpha = 0.9;
        c.fillStyle = '#fff'; c.strokeStyle = 'rgba(40,24,12,.6)'; c.lineWidth = 2.5; c.beginPath(); c.arc(o.x, o.y - 58 + b, 12, 0, TAU); c.fill(); c.stroke();
        c.fillStyle = ['#7ac6ff','#b46bff','#ff9d1f'][o.zone] || '#7ac6ff'; c.beginPath(); c.arc(o.x, o.y - 58 + b, 7, 0, TAU); c.fill(); c.globalAlpha = 1;
        if (Math.random() < 0.05) G.parts.push({ t: 'spark', x: o.x + (Math.random() - 0.5) * 80, y: o.y - 10 + (Math.random() - 0.5) * 40, vx: 0, vy: -30, life: 0.8, age: 0, c: '#fff6b0', s: 4, rot: 0, vr: 3, fall: true });
      } else {
        const w = 70, x = o.x - w / 2, y = o.y + 44; c.fillStyle = 'rgba(30,20,10,.6)'; A.rr(c, x, y, w, 8, 4); c.fill();
        c.fillStyle = '#7dff7a'; A.rr(c, x + 1, y + 1, Math.max(6, (w - 2) * info.g), 6, 3); c.fill();
        A.text(c, fmtTime(info.left), o.x, y + 18, 11, '#fff');
      }
    }
  }
  function drawStandObj(c, o, t) {
    const theme = o.zone; A.drawStand(c, o.x, o.y, theme);
    const pet = G.state && petOnStand(o.id);
    if (pet) {
      const tp = petType(pet.type), rar = tp ? tp.rarity : 'common';
      A.drawPet(c, pet.type, o.x, o.y - 24, 1.05, t, { rarity: rar, phase: o.id * 1.7 });
      const a = accrued(pet); if (a >= 1) { const b = Math.sin(t * 4 + o.id) * 2; A.drawCoin(c, o.x + 30, o.y - 76 + b, 9); A.text(c, fmt(a), o.x + 30, o.y - 93 + b, 12, '#ffe27a'); }
      if (tp) A.text(c, '+' + fmt(tp.income * G.state.config.income_mult * G.state.event_mult.income) + '/с', o.x, o.y + 22, 10, A.RARITY[rar].color);
    } else { A.text(c, o.id + 1, o.x, o.y - 25, 12, 'rgba(255,255,255,.8)'); }
  }
  function drawPriceTag(c, o, price) { A.drawCoin(c, o.x - 18, o.y + 22, 8); A.text(c, price, o.x + 10, o.y + 22, 12, '#ffe27a'); }
  function drawNpc(c, n) {
    A.shadow(c, n.x, n.y + 2, 28, 8, 0.3);
    const bob = Math.sin(n.walkT * 9); A.drawHero(c, 'hero', n.x, n.y - Math.abs(bob) * 3, 62, G.time, { bob, tilt: bob * 0.03 * n.face });
    A.text(c, 'Дон Сомбреро', n.x, n.y + 16, 11, '#ffe27a');
    if (n.sayT > 0) {
      const w = Math.min(230, 20 + n.say.length * 6.6), lines = wrap(c, n.say, w - 20, 12), h = lines.length * 15 + 14, y = n.y - 90 - h;
      c.fillStyle = '#fff'; c.strokeStyle = 'rgba(40,24,12,.6)'; c.lineWidth = 2.5; A.rr(c, n.x - w / 2, y, w, h, 10); c.fill(); c.stroke();
      c.beginPath(); c.moveTo(n.x - 6, y + h); c.lineTo(n.x, y + h + 9); c.lineTo(n.x + 6, y + h); c.fillStyle = '#fff'; c.fill();
      c.fillStyle = '#2a1a0e'; c.font = '700 12px "Trebuchet MS",system-ui,sans-serif'; c.textAlign = 'center'; c.textBaseline = 'middle'; lines.forEach((l, i) => c.fillText(l, n.x, y + 14 + i * 15));
    }
  }
  function wrap(c, s, w, size) {
    c.font = '700 ' + size + 'px "Trebuchet MS",system-ui,sans-serif'; const words = s.split(' '), lines = []; let cur = '';
    words.forEach(wd => { const t = cur ? cur + ' ' + wd : wd; if (c.measureText(t).width > w && cur) { lines.push(cur); cur = wd; } else cur = t; }); if (cur) lines.push(cur); return lines;
  }
  function drawPlayer(c) {
    const p = G.player, st = G.state; if (!st) return;
    const bob = Math.sin(p.walkT * 14), moving = Math.hypot(p.vx, p.vy) > 12;
    const pop = p.pop, sc = pop < 1 ? (1 + 0.25 * Math.sin(pop * Math.PI)) * pop : 1;
    A.shadow(c, p.x, p.y + 2, 30 * sc, 9 * sc, 0.32);
    c.save(); c.translate(p.x, p.y); c.scale(p.face * sc, sc); c.translate(-p.x, -p.y);
    A.drawHero(c, 'hero', p.x, p.y - (moving ? Math.abs(bob) * 5 : 0), 68, G.time, { bob: moving ? bob : undefined, tilt: p.tilt * p.face });
    c.restore();
    const gold = st.role === 'GLOBAL_ADMIN';
    A.text(c, st.username, p.x, p.y + 18, 12, gold ? '#ffd23f' : '#fff');
  }

  /* ---------- размеры и цикл ---------- */
  G.setPotatoMode = function (enabled) { G.potatoMode = !!enabled; try { localStorage.setItem('farm.potato', G.potatoMode ? '1' : '0'); } catch (e) {} };
  G.resize = function () {
    const dpr = window.devicePixelRatio || 1;
    G.dpr = dpr; G.W = Math.floor(window.innerWidth * dpr); G.H = Math.floor(window.innerHeight * dpr);
    G.canvas.width = G.W; G.canvas.height = G.H;
    const cssW = window.innerWidth, cssH = window.innerHeight;
    G.scale = dpr * clamp(Math.min(cssW / 700, cssH / 520), 0.7, 2.0);
  };
  let lastRender = 0, initialized = false;
  function frame(ts) {
    requestAnimationFrame(frame);
    if (document.hidden) { lastRender = ts; return; }
    const elapsed = ts - lastRender;
    // Ограничиваем ~60 кадрами/с, но время считаем от последнего НАРИСОВАННОГО кадра:
    // иначе на экранах 90/120 Гц ни один кадр не проходил проверку и мир не рисовался.
    if (lastRender && elapsed < 10) return;
    lastRender = ts;
    const dt = Math.min(0.05, (elapsed || 16.7) / 1000);
    update(dt); render();
  }
  G.init = function (canvas) {
    if (initialized) return; // Защита от повторного запуска RAF и повторных обработчиков.
    initialized = true;
    G.canvas = canvas; G.ctx = canvas.getContext('2d', { alpha: false });
    G.touch = !!((window.matchMedia && matchMedia('(pointer: coarse)').matches) || (navigator.maxTouchPoints > 0) || ('ontouchstart' in window));
    document.documentElement.classList.toggle('touch', G.touch);
    G.resize(); window.addEventListener('resize', G.resize);
    build();
    canvas.addEventListener('pointerdown', e => { if (e.button > 0) return; G.pointerDown(e.clientX * G.dpr, e.clientY * G.dpr); });
    requestAnimationFrame(frame);
  };
  // Серверное действие через общую очередь (порядок гарантирован); возвращает состояние или бросает ошибку.
  G.exec = function (name, args) {
    return new Promise((res, rej) => enqueue(async () => {
      try { const st = await call(name, args); if (G.pending === 1) G.applyState(st); else if (G.state) { G.state.coins = st.coins; } res(st); } catch (e) { rej(e); }
    }));
  };
  G.ZW = ZW; G.ZONE_NAMES = ZONE_NAMES; G.crop = crop;
})();
