-- Общий склад яиц: остатки едины для всех игроков.
create table if not exists public.farm_egg_stock (
  egg_id text primary key references public.farm_eggs(id) on delete cascade,
  quantity integer not null default 40 check (quantity >= 0),
  max_quantity integer not null default 40 check (max_quantity >= 1),
  updated_at timestamptz not null default now()
);
insert into public.farm_egg_stock(egg_id,quantity,max_quantity)
select id,40,40 from public.farm_eggs on conflict(egg_id) do nothing;
alter table public.farm_egg_stock enable row level security;
drop policy if exists farm_egg_stock_read on public.farm_egg_stock;
create policy farm_egg_stock_read on public.farm_egg_stock for select to authenticated using (true);
grant select on public.farm_egg_stock to authenticated;

create or replace function public.farm_global_stock() returns jsonb
language plpgsql stable security definer set search_path=public as $$
begin
 if auth.uid() is null then raise exception 'not_authenticated'; end if;
 return coalesce((select jsonb_agg(jsonb_build_object('id',e.id,'name',e.name,'price',e.price,'min_zone',e.min_zone,'quantity',s.quantity,'max_quantity',s.max_quantity,'updated_at',s.updated_at) order by e.price) from public.farm_eggs e join public.farm_egg_stock s on s.egg_id=e.id),'[]'::jsonb);
end $$;

create or replace function public.farm_admin_restock(p_egg text default null,p_amount integer default 40) returns jsonb
language plpgsql security definer set search_path=public as $$
declare uid uuid:=public._farm_need('global'); n integer;
begin
 if p_amount is null or p_amount<1 or p_amount>10000 then raise exception 'bad_amount'; end if;
 if p_egg is not null and not exists(select 1 from public.farm_eggs where id=p_egg) then raise exception 'bad_egg'; end if;
 if p_egg is null then update public.farm_egg_stock set quantity=least(max_quantity,quantity+p_amount),updated_at=now();
 else update public.farm_egg_stock set quantity=least(max_quantity,quantity+p_amount),updated_at=now() where egg_id=p_egg; end if;
 get diagnostics n=row_count;
 perform public._farm_log(uid,'egg_stock_restock',jsonb_build_object('egg',p_egg,'amount',p_amount,'rows',n));
 return public.farm_global_stock();
end $$;

create or replace function public.farm_buy_egg(p_egg text) returns jsonb
language plpgsql security definer set search_path=public as $$
declare uid uuid:=auth.uid(); s public.farm_saves; e public.farm_eggs; t public.farm_pet_types; pick public.farm_pet_types; total_w numeric; roll numeric; acc numeric:=0; pid uuid; stock public.farm_egg_stock;
begin
 if uid is null then raise exception 'not_authenticated'; end if;
 select * into s from public.farm_saves where user_id=uid for update; if not found then raise exception 'no_save'; end if;
 select * into e from public.farm_eggs where id=p_egg; if not found then raise exception 'bad_egg'; end if;
 if s.zones<e.min_zone then raise exception 'zone_locked'; end if;
 if s.coins<e.price then raise exception 'not_enough_coins'; end if;
 if (select count(*) from public.farm_pets where user_id=uid)>=60 then raise exception 'inventory_full'; end if;
 select * into stock from public.farm_egg_stock where egg_id=p_egg for update;
 if not found or stock.quantity<=0 then raise exception 'egg_out_of_stock'; end if;
 select sum(weight) into total_w from public.farm_pet_types where egg_id=e.id and weight>0; if total_w is null then raise exception 'bad_egg'; end if;
 roll:=random()*total_w;
 for t in select * from public.farm_pet_types where egg_id=e.id and weight>0 order by weight desc,id loop acc:=acc+t.weight;pick:=t;exit when roll<acc;end loop;
 insert into public.farm_pets(user_id,pet_type) values(uid,pick.id) returning id into pid;
 update public.farm_egg_stock set quantity=quantity-1,updated_at=now() where egg_id=p_egg;
 update public.farm_saves set coins=coins-e.price,eggs_opened=eggs_opened+1,updated_at=now() where user_id=uid;
 perform public._farm_log(uid,'buy_egg',jsonb_build_object('egg',e.id,'price',e.price,'pet',pick.id,'rarity',pick.rarity));
 return public._farm_state(uid)||jsonb_build_object('hatched',jsonb_build_object('id',pid,'type',pick.id,'rarity',pick.rarity));
end $$;
grant execute on function public.farm_global_stock(),public.farm_admin_restock(text,integer),public.farm_buy_egg(text) to authenticated;
