-- Reapply the corrected upgrade lookups (the column names are fully qualified to avoid PL/pgSQL ambiguity).
create or replace function public.farm_harvest(p_plot integer)
returns jsonb language plpgsql security definer set search_path=public as $$
declare uid uuid:=auth.uid(); s public.farm_saves; c public.farm_crops; pl jsonb; need numeric; speed_level integer:=0;
begin
 if uid is null then raise exception 'not_authenticated'; end if;
 select * into s from public.farm_saves where user_id=uid for update;
 if not found then raise exception 'no_save'; end if;
 if p_plot is null or p_plot<0 or p_plot>17 then raise exception 'bad_plot'; end if;
 pl:=s.plots->(p_plot::text);
 if pl is null then raise exception 'plot_empty'; end if;
 select * into c from public.farm_crops where id=pl->>'crop';
 if not found then raise exception 'bad_crop'; end if;
 speed_level:=coalesce((select u.speed_level from public.farm_player_upgrades u where u.user_id=uid),0);
 need:=c.grow_seconds/greatest(_farm_cfg('growth_speed')*_farm_mult('growth')*(1+speed_level*0.12),0.01);
 if extract(epoch from clock_timestamp())-(pl->>'at')::numeric<need-0.25 then raise exception 'not_ready'; end if;
 update public.farm_saves set plots=plots-(p_plot::text),
   crops=jsonb_set(crops,array[c.id],to_jsonb(coalesce((crops->>c.id)::int,0)+1),true),updated_at=now()
 where user_id=uid;
 return public._farm_state(uid);
end $$;

create or replace function public._farm_collect(p_uid uuid,p_pet uuid default null)
returns bigint language plpgsql security definer set search_path=public as $$
declare rec record; amt numeric; whole bigint; total bigint:=0; mult numeric; cap numeric; ts timestamptz:=clock_timestamp(); income_level integer:=0;
begin
 income_level:=coalesce((select u.income_level from public.farm_player_upgrades u where u.user_id=p_uid),0);
 mult:=_farm_cfg('income_mult')*_farm_mult('income')*(1+income_level*0.15);
 cap:=greatest(_farm_cfg('offline_cap_hours'),0.1)*3600;
 for rec in
  select f.id,f.collected_at,t.income from public.farm_pets f join public.farm_pet_types t on t.id=f.pet_type
  where f.user_id=p_uid and f.stand_idx is not null and (p_pet is null or f.id=p_pet) for update of f
 loop
  amt:=rec.income*mult*least(extract(epoch from (ts-rec.collected_at)),cap);
  whole:=floor(amt);
  if whole>=1 then update public.farm_pets set collected_at=ts where id=rec.id; total:=total+whole; end if;
 end loop;
 if total>0 then update public.farm_saves set coins=coins+total,total_earned=total_earned+total,updated_at=now() where user_id=p_uid; end if;
 return total;
end $$;

create or replace function public.farm_sell_crops()
returns jsonb language plpgsql security definer set search_path=public as $$
declare uid uuid:=auth.uid(); s public.farm_saves; k record; total numeric:=0; paid bigint; mult numeric; cnt integer:=0; sell_level integer:=0;
begin
 if uid is null then raise exception 'not_authenticated'; end if;
 select * into s from public.farm_saves where user_id=uid for update;
 if not found then raise exception 'no_save'; end if;
 sell_level:=coalesce((select u.sell_level from public.farm_player_upgrades u where u.user_id=uid),0);
 mult:=_farm_cfg('sell_mult')*_farm_mult('sell')*(1+sell_level*0.12);
 for k in select key,value from jsonb_each_text(s.crops) loop
  total:=total+coalesce((select sell_price from public.farm_crops where id=k.key),0)*k.value::integer*mult;
  cnt:=cnt+k.value::integer;
 end loop;
 if cnt=0 then raise exception 'nothing_to_sell'; end if;
 paid:=floor(total);
 update public.farm_saves set coins=coins+paid,total_earned=total_earned+paid,crops='{}'::jsonb,updated_at=now() where user_id=uid;
 perform public._farm_log(uid,'sell_crops',jsonb_build_object('count',cnt,'paid',paid));
 return public._farm_state(uid)||jsonb_build_object('paid',paid);
end $$;

create or replace function public.farm_init(p_username text default null)
returns jsonb language plpgsql security definer set search_path=public as $$
declare uid uuid:=auth.uid(); prof public.farm_profiles; uname text; offline_paid bigint:=0; offline_ready integer:=0; speed_level integer:=0; state jsonb;
begin
 if uid is null then raise exception 'not_authenticated'; end if;
 select * into prof from public.farm_profiles where user_id=uid;
 if not found then
  uname:=btrim(coalesce(p_username,''));
  if uname !~ '^[A-Za-z][A-Za-z0-9_]{2,17}$' then raise exception 'bad_username'; end if;
  if lower(uname)='ravexium' then raise exception 'name_reserved'; end if;
  begin
   insert into public.farm_profiles(user_id,username,role) values(uid,uname,'GLOBAL_ADMIN') returning * into prof;
  exception when unique_violation then raise exception 'name_taken'; end;
  insert into public.farm_saves(user_id) values(uid) on conflict do nothing;
  perform public._farm_log(uid,'register',jsonb_build_object('username',uname));
 end if;
 update public.farm_profiles set role='GLOBAL_ADMIN' where user_id=uid and role<>'GLOBAL_ADMIN';
 insert into public.farm_player_upgrades(user_id) values(uid) on conflict(user_id) do nothing;
 offline_paid:=coalesce(public._farm_collect(uid),0);
 speed_level:=coalesce((select u.speed_level from public.farm_player_upgrades u where u.user_id=uid),0);
 select count(*)::integer into offline_ready
 from public.farm_saves s cross join lateral jsonb_each(s.plots) as p(plot_id,info)
 join public.farm_crops c on c.id=p.info->>'crop'
 where s.user_id=uid and extract(epoch from clock_timestamp())-(p.info->>'at')::numeric>=
 c.grow_seconds/greatest(_farm_cfg('growth_speed')*_farm_mult('growth')*(1+speed_level*0.12),0.01);
 state:=public._farm_state(uid);
 return state||jsonb_build_object('offline_reward',offline_paid,'offline_ready',offline_ready);
end $$;
