-- Increase shared planting-egg stock capacity to 160 per egg.
alter table public.farm_crop_stock drop constraint if exists farm_crop_stock_quantity_check;
alter table public.farm_crop_stock add constraint farm_crop_stock_quantity_check
  check (quantity between 0 and 160);
-- Raise current stocks so the planting market does not feel empty.
update public.farm_crop_stock set quantity=greatest(quantity,40), updated_at=now();
create or replace function public.farm_admin_set_crop_stock(p_crop text,p_quantity integer)
returns jsonb language plpgsql security definer set search_path=public as $$
begin
 if not exists(select 1 from public.farm_profiles where user_id=auth.uid() and role in ('admin','owner')) then raise exception 'not_admin'; end if;
 if p_quantity<4 or p_quantity>160 then raise exception 'bad_quantity'; end if;
 update public.farm_crop_stock set quantity=p_quantity,updated_at=now() where crop_id=p_crop;
 if not found then raise exception 'bad_crop'; end if;
 return public.farm_crop_stock();
end $$;
grant execute on function public.farm_admin_set_crop_stock(text,integer) to authenticated;
