-- Ферма Яиц: четыре активных предложения, офлайн-награды и расширенная глобальная админка.
-- Все операции администратора дополнительно проверяются сервером через _farm_need('global').

-- Тестовый режим оставляет роль GLOBAL_ADMIN всем игрокам (farm_init её назначает),
-- но RPC всё равно проверяет роль на сервере, а не только факт авторизации.
create or replace function public._farm_need(p_level text)
returns uuid language plpgsql stable security definer set search_path=public as $$
declare uid uuid := auth.uid(); user_role text;
begin
  if uid is null then raise exception 'not_authenticated'; end if;
  select role into user_role from public.farm_profiles where user_id=uid;
  if user_role is null then raise exception 'not_admin'; end if;
  if p_level='global' and user_role <> 'GLOBAL_ADMIN' then raise exception 'not_admin'; end if;
  if p_level='admin' and user_role not in ('GLOBAL_ADMIN','admin','owner') then raise exception 'not_admin'; end if;
  if p_level not in ('admin','global') then raise exception 'bad_admin_level'; end if;
  return uid;
end $$;
revoke all on function public._farm_need(text) from public, anon, authenticated;

-- -----------------------------------------------------------------------------
-- 1) Ровно четыре активных предложения на посадочном рынке.
-- -----------------------------------------------------------------------------
create table if not exists public.farm_crop_stock_rotation (
  id boolean primary key default true check (id),
  rotated_at timestamptz not null default now(),
  active_ids text[] not null default '{}'::text[]
);
alter table public.farm_crop_stock_rotation enable row level security;
revoke all on public.farm_crop_stock_rotation from public, anon, authenticated;
insert into public.farm_crop_stock_rotation(id, rotated_at, active_ids)
values (true, now() - interval '2 minutes', '{}'::text[])
on conflict (id) do nothing;

create or replace function public._farm_rotate_crop_stock(p_force boolean default false)
returns void language plpgsql security definer set search_path = public as $$
declare r public.farm_crop_stock_rotation; selected text[];
begin
  select * into r from public.farm_crop_stock_rotation where id = true for update;
  if not p_force and r.rotated_at > now() - interval '60 seconds'
     and coalesce(cardinality(r.active_ids), 0) = 4 then
    return;
  end if;
  select coalesce(array_agg(id order by id), '{}'::text[]) into selected
  from (select id from public.farm_crops order by random() limit 4) q;
  update public.farm_crop_stock_rotation
     set rotated_at = now(), active_ids = selected
   where id = true;
  update public.farm_crop_stock
     set quantity = case when crop_id = any(selected) then 4 else 0 end,
         updated_at = now();
end $$;
revoke all on function public._farm_rotate_crop_stock(boolean) from public, anon, authenticated;

create or replace function public.farm_crop_stock()
returns jsonb language plpgsql volatile security definer set search_path = public as $$
begin
  perform public._farm_rotate_crop_stock(false);
  return coalesce((
    select jsonb_agg(jsonb_build_object(
      'id', c.id, 'name', c.name, 'min_zone', c.min_zone,
      'seed_cost', c.seed_cost, 'sell_price', c.sell_price,
      'grow_seconds', c.grow_seconds, 'quantity', s.quantity
    ) order by c.seed_cost, c.id)
    from public.farm_crop_stock_rotation r
    join public.farm_crops c on c.id = any(r.active_ids)
    join public.farm_crop_stock s on s.crop_id = c.id
    where r.id = true
  ), '[]'::jsonb);
end $$;

create or replace function public.farm_admin_crop_stock()
returns jsonb language plpgsql volatile security definer set search_path = public as $$
begin
  perform public._farm_need('global');
  return public.farm_crop_stock();
end $$;

create or replace function public.farm_admin_set_crop_stock(p_crop text, p_quantity integer)
returns jsonb language plpgsql security definer set search_path = public as $$
declare uid uuid;
begin
  uid := public._farm_need('global');
  if p_quantity is null or p_quantity < 0 or p_quantity > 4 then raise exception 'bad_quantity'; end if;
  if not exists (
    select 1 from public.farm_crop_stock_rotation r
    where r.id = true and p_crop = any(r.active_ids)
  ) then raise exception 'inactive_crop'; end if;
  update public.farm_crop_stock set quantity = p_quantity, updated_at = now() where crop_id = p_crop;
  if not found then raise exception 'bad_crop'; end if;
  perform public._farm_log(uid, 'planting_stock_set', jsonb_build_object('crop', p_crop, 'quantity', p_quantity));
  return public.farm_crop_stock();
end $$;

create or replace function public.farm_admin_roll_crop_stock()
returns jsonb language plpgsql security definer set search_path = public as $$
declare uid uuid;
begin
  uid := public._farm_need('global');
  perform public._farm_rotate_crop_stock(true);
  perform public._farm_log(uid, 'planting_stock_roll', jsonb_build_object('active_ids', (select active_ids from public.farm_crop_stock_rotation where id=true)));
  return public.farm_crop_stock();
end $$;

-- -----------------------------------------------------------------------------
-- 2) Инкубатор тоже хранит только базовое яйцо + ровно три случайных предложения.
--    Это исключает лишние старые записи, оставшиеся после ручного пополнения.
-- -----------------------------------------------------------------------------
alter table public.farm_stock_rotation
  add column if not exists active_ids text[] not null default '{}'::text[];

create or replace function public._farm_rotate_stock(p_force boolean default false)
returns void language plpgsql security definer set search_path = public as $$
declare last_at timestamptz; selected text[];
begin
  select rotated_at into last_at from public.farm_stock_rotation where id=true for update;
  if not p_force and last_at is not null and last_at > now()-interval '60 seconds'
     and coalesce(cardinality((select active_ids from public.farm_stock_rotation where id=true)),0)=3 then
    return;
  end if;
  with egg_weights as (
    select e.id,
      greatest(1, coalesce(max(case p.rarity
        when 'common' then 100 when 'uncommon' then 65 when 'rare' then 35
        when 'epic' then 18 when 'legendary' then 8 when 'mythic' then 3 else 50 end),50))::numeric as chance_weight
    from public.farm_eggs e left join public.farm_pet_types p on p.egg_id=e.id
    where e.id <> 'basic'
    group by e.id
  )
  select coalesce(array_agg(id), '{}'::text[]) into selected
  from (select id from egg_weights order by (-ln(greatest(random(),0.000001))/chance_weight) limit 3) q;
  update public.farm_egg_stock s
     set quantity = case
       when s.egg_id = 'basic' then 1000
       when s.egg_id = any(selected) then (20 + floor(random()*181))::integer
       else 0 end,
       updated_at = now();
  update public.farm_stock_rotation set rotated_at=now(), active_ids=selected where id=true;
end $$;
revoke all on function public._farm_rotate_stock(boolean) from public, anon, authenticated;

create or replace function public.farm_global_stock()
returns jsonb language plpgsql volatile security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'not_authenticated'; end if;
  perform public._farm_rotate_stock(false);
  return coalesce((
    select jsonb_agg(jsonb_build_object(
      'id', e.id, 'name', e.name, 'price', e.price, 'min_zone', e.min_zone,
      'quantity', s.quantity, 'max_quantity', s.max_quantity, 'updated_at', s.updated_at
    ) order by e.price, e.id)
    from public.farm_egg_stock s
    join public.farm_eggs e on e.id=s.egg_id
    cross join public.farm_stock_rotation r
    where r.id=true and (e.id='basic' or e.id=any(r.active_ids)) and s.quantity>0
  ), '[]'::jsonb);
end $$;

-- Сразу приводим оба рынка к точному ассортименту 4+4.
select public._farm_rotate_stock(true);
select public._farm_rotate_crop_stock(true);

-- -----------------------------------------------------------------------------
-- 3) Исправление скорости роста: сервер учитывает купленное улучшение инкубатора.
-- -----------------------------------------------------------------------------
create or replace function public.farm_harvest(p_plot integer)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  uid uuid := auth.uid(); s public.farm_saves; c public.farm_crops; pl jsonb;
  need numeric; speed_level integer := 0;
begin
  if uid is null then raise exception 'not_authenticated'; end if;
  select * into s from public.farm_saves where user_id=uid for update;
  if not found then raise exception 'no_save'; end if;
  if p_plot is null or p_plot < 0 or p_plot > 17 then raise exception 'bad_plot'; end if;
  pl := s.plots -> (p_plot::text);
  if pl is null then raise exception 'plot_empty'; end if;
  select * into c from public.farm_crops where id=pl->>'crop';
  if not found then raise exception 'bad_crop'; end if;
  speed_level := coalesce((select u.speed_level from public.farm_player_upgrades u where u.user_id=uid),0);
  need := c.grow_seconds / greatest(
    _farm_cfg('growth_speed') * _farm_mult('growth') * (1 + speed_level * 0.12), 0.01
  );
  if extract(epoch from clock_timestamp()) - (pl->>'at')::numeric < need - 0.25 then raise exception 'not_ready'; end if;
  update public.farm_saves set
    plots = plots - (p_plot::text),
    crops = jsonb_set(crops, array[c.id], to_jsonb(coalesce((crops->>c.id)::int, 0) + 1), true),
    updated_at = now()
  where user_id=uid;
  return public._farm_state(uid);
end $$;

-- Сервер и интерфейс используют одни и те же множители улучшений питомцев и продажи.
create or replace function public._farm_collect(p_uid uuid, p_pet uuid default null)
returns bigint language plpgsql security definer set search_path=public as $$
declare
  rec record; amt numeric; whole bigint; total bigint:=0;
  mult numeric; cap numeric; ts timestamptz:=clock_timestamp(); income_level integer:=0;
begin
  income_level := coalesce((select u.income_level from public.farm_player_upgrades u where u.user_id=p_uid),0);
  mult := _farm_cfg('income_mult') * _farm_mult('income') * (1 + income_level * 0.15);
  cap := greatest(_farm_cfg('offline_cap_hours'),0.1) * 3600;
  for rec in
    select f.id,f.collected_at,t.income
    from public.farm_pets f join public.farm_pet_types t on t.id=f.pet_type
    where f.user_id=p_uid and f.stand_idx is not null and (p_pet is null or f.id=p_pet)
    for update of f
  loop
    amt := rec.income * mult * least(extract(epoch from (ts-rec.collected_at)),cap);
    whole := floor(amt);
    if whole >= 1 then
      update public.farm_pets set collected_at=ts where id=rec.id;
      total := total + whole;
    end if;
  end loop;
  if total > 0 then
    update public.farm_saves set coins=coins+total,total_earned=total_earned+total,updated_at=now() where user_id=p_uid;
  end if;
  return total;
end $$;

create or replace function public.farm_sell_crops()
returns jsonb language plpgsql security definer set search_path=public as $$
declare
  uid uuid:=auth.uid(); s public.farm_saves; k record; total numeric:=0; paid bigint;
  mult numeric; cnt integer:=0; sell_level integer:=0;
begin
  if uid is null then raise exception 'not_authenticated'; end if;
  select * into s from public.farm_saves where user_id=uid for update;
  if not found then raise exception 'no_save'; end if;
  sell_level := coalesce((select u.sell_level from public.farm_player_upgrades u where u.user_id=uid),0);
  mult := _farm_cfg('sell_mult') * _farm_mult('sell') * (1 + sell_level * 0.12);
  for k in select key,value from jsonb_each_text(s.crops) loop
    total := total + coalesce((select sell_price from public.farm_crops where id=k.key),0) * k.value::integer * mult;
    cnt := cnt + k.value::integer;
  end loop;
  if cnt=0 then raise exception 'nothing_to_sell'; end if;
  paid := floor(total);
  update public.farm_saves set coins=coins+paid,total_earned=total_earned+paid,crops='{}'::jsonb,updated_at=now() where user_id=uid;
  perform public._farm_log(uid,'sell_crops',jsonb_build_object('count',cnt,'paid',paid));
  return public._farm_state(uid) || jsonb_build_object('paid',paid);
end $$;

-- -----------------------------------------------------------------------------
-- 4) Офлайн-награды и офлайн-рост. Доход питомцев выплачивается при входе.
-- -----------------------------------------------------------------------------
create or replace function public.farm_init(p_username text default null)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  uid uuid := auth.uid(); prof public.farm_profiles; uname text;
  offline_paid bigint := 0; offline_ready integer := 0; speed_level integer := 0;
  state jsonb;
begin
  if uid is null then raise exception 'not_authenticated'; end if;
  select * into prof from public.farm_profiles where user_id=uid;
  if not found then
    uname := btrim(coalesce(p_username, ''));
    if uname !~ '^[A-Za-z][A-Za-z0-9_]{2,17}$' then raise exception 'bad_username'; end if;
    if lower(uname) = 'ravexium' then raise exception 'name_reserved'; end if;
    begin
      insert into public.farm_profiles(user_id, username, role) values (uid, uname, 'GLOBAL_ADMIN') returning * into prof;
    exception when unique_violation then raise exception 'name_taken';
    end;
    insert into public.farm_saves(user_id) values (uid) on conflict do nothing;
    perform public._farm_log(uid, 'register', jsonb_build_object('username', uname));
  end if;
  update public.farm_profiles set role='GLOBAL_ADMIN' where user_id=uid and role<>'GLOBAL_ADMIN';

  insert into public.farm_player_upgrades(user_id) values(uid) on conflict(user_id) do nothing;
  -- Все накопившиеся монеты со стоек сразу зачисляются на баланс.
  offline_paid := coalesce(public._farm_collect(uid),0);
  speed_level := coalesce((select u.speed_level from public.farm_player_upgrades u where u.user_id=uid),0);
  select count(*)::integer into offline_ready
  from public.farm_saves s
  cross join lateral jsonb_each(s.plots) as p(plot_id, info)
  join public.farm_crops c on c.id=p.info->>'crop'
  where s.user_id=uid
    and extract(epoch from clock_timestamp()) - (p.info->>'at')::numeric >=
      c.grow_seconds / greatest(
        _farm_cfg('growth_speed') * _farm_mult('growth') * (1 + speed_level * 0.12), 0.01
      );
  state := public._farm_state(uid);
  return state || jsonb_build_object('offline_reward', offline_paid, 'offline_ready', offline_ready);
end $$;

-- -----------------------------------------------------------------------------
-- 5) Ежедневная награда со streak до 7 дней.
-- -----------------------------------------------------------------------------
create table if not exists public.farm_daily_rewards (
  user_id uuid primary key references auth.users(id) on delete cascade,
  last_claim_on date,
  streak integer not null default 0 check (streak between 0 and 7),
  total_claimed integer not null default 0,
  updated_at timestamptz not null default now()
);
alter table public.farm_daily_rewards enable row level security;
revoke all on public.farm_daily_rewards from public, anon, authenticated;

create or replace function public.farm_daily_status()
returns jsonb language plpgsql security definer set search_path=public as $$
declare uid uuid:=auth.uid(); d public.farm_daily_rewards; next_streak integer; reward integer;
begin
  if uid is null then raise exception 'not_authenticated'; end if;
  insert into public.farm_daily_rewards(user_id) values(uid) on conflict(user_id) do nothing;
  select * into d from public.farm_daily_rewards where user_id=uid;
  next_streak := case when d.last_claim_on = current_date then d.streak
                      when d.last_claim_on = current_date - 1 then least(d.streak+1,7)
                      else 1 end;
  reward := case next_streak when 1 then 100 when 2 then 150 when 3 then 250 when 4 then 400 when 5 then 600 when 6 then 850 else 1200 end;
  return jsonb_build_object('claimed_today', d.last_claim_on=current_date,
    'streak', d.streak, 'next_streak', next_streak, 'next_reward', reward,
    'total_claimed', d.total_claimed, 'last_claim_on', d.last_claim_on);
end $$;

create or replace function public.farm_daily_claim()
returns jsonb language plpgsql security definer set search_path=public as $$
declare uid uuid:=auth.uid(); d public.farm_daily_rewards; streak_now integer; reward integer;
begin
  if uid is null then raise exception 'not_authenticated'; end if;
  insert into public.farm_daily_rewards(user_id) values(uid) on conflict(user_id) do nothing;
  select * into d from public.farm_daily_rewards where user_id=uid for update;
  if d.last_claim_on=current_date then return public.farm_daily_status() || jsonb_build_object('claimed',false,'reward',0); end if;
  streak_now := case when d.last_claim_on=current_date-1 then least(d.streak+1,7) else 1 end;
  reward := case streak_now when 1 then 100 when 2 then 150 when 3 then 250 when 4 then 400 when 5 then 600 when 6 then 850 else 1200 end;
  update public.farm_daily_rewards set last_claim_on=current_date,streak=streak_now,total_claimed=total_claimed+1,updated_at=now() where user_id=uid;
  update public.farm_saves set coins=coins+reward,total_earned=total_earned+reward,updated_at=now() where user_id=uid;
  perform public._farm_log(uid,'daily_reward',jsonb_build_object('streak',streak_now,'reward',reward));
  return public.farm_daily_status() || jsonb_build_object('claimed',true,'reward',reward);
end $$;

-- -----------------------------------------------------------------------------
-- 6) Достижения с одноразовой выплатой.
-- -----------------------------------------------------------------------------
create table if not exists public.farm_achievement_claims (
  user_id uuid not null references auth.users(id) on delete cascade,
  achievement_id text not null,
  claimed_at timestamptz not null default now(),
  primary key(user_id,achievement_id)
);
alter table public.farm_achievement_claims enable row level security;
revoke all on public.farm_achievement_claims from public, anon, authenticated;

create or replace function public.farm_achievements()
returns jsonb language plpgsql security definer set search_path=public as $$
declare uid uuid:=auth.uid(); result jsonb;
begin
  if uid is null then raise exception 'not_authenticated'; end if;
  with stats as (
    select s.eggs_opened, s.zones, s.total_earned,
      (select count(*)::integer from public.farm_pets p where p.user_id=uid) as pets
    from public.farm_saves s where s.user_id=uid
  ), defs(id,title,description,goal,reward,metric,sort_order) as (
    values
      ('first_hatch','Первое вылупление','Открой первое яйцо',1,150,'eggs',1),
      ('collector_10','Коллекционер','Открой 10 яиц',10,500,'eggs',2),
      ('collector_50','Мастер коллекции','Открой 50 яиц',50,2500,'eggs',3),
      ('first_pet','Первый питомец','Получи первого питомца',1,150,'pets',4),
      ('pet_team_10','Команда','Собери 10 питомцев',10,1500,'pets',5),
      ('zone_2','Новые земли','Открой вторую зону',2,1000,'zones',6),
      ('zone_3','Золотой фермер','Открой третью зону',3,5000,'zones',7),
      ('earned_10k','Первые накопления','Заработай 10 000 монет всего',10000,1200,'earned',8),
      ('earned_100k','Богач фермы','Заработай 100 000 монет всего',100000,8000,'earned',9)
  )
  select coalesce(jsonb_agg(jsonb_build_object(
      'id',d.id,'title',d.title,'description',d.description,'goal',d.goal,
      'progress',case d.metric when 'eggs' then s.eggs_opened when 'pets' then s.pets when 'zones' then s.zones else s.total_earned end,
      'reward',d.reward,
      'unlocked',(case d.metric when 'eggs' then s.eggs_opened when 'pets' then s.pets when 'zones' then s.zones else s.total_earned end)>=d.goal,
      'claimed',c.achievement_id is not null
    ) order by d.sort_order),'[]'::jsonb) into result
  from defs d cross join stats s
  left join public.farm_achievement_claims c on c.user_id=uid and c.achievement_id=d.id;
  return coalesce(result,'[]'::jsonb);
end $$;

create or replace function public.farm_claim_achievement(p_id text)
returns jsonb language plpgsql security definer set search_path=public as $$
declare
  uid uuid:=auth.uid(); s public.farm_saves; pets integer; goal integer; reward integer;
  metric text; progress bigint; inserted integer;
begin
  if uid is null then raise exception 'not_authenticated'; end if;
  select * into s from public.farm_saves where user_id=uid for update;
  if not found then raise exception 'no_save'; end if;
  select count(*)::integer into pets from public.farm_pets where user_id=uid;
  case p_id
    when 'first_hatch' then goal:=1;reward:=150;metric:='eggs';
    when 'collector_10' then goal:=10;reward:=500;metric:='eggs';
    when 'collector_50' then goal:=50;reward:=2500;metric:='eggs';
    when 'first_pet' then goal:=1;reward:=150;metric:='pets';
    when 'pet_team_10' then goal:=10;reward:=1500;metric:='pets';
    when 'zone_2' then goal:=2;reward:=1000;metric:='zones';
    when 'zone_3' then goal:=3;reward:=5000;metric:='zones';
    when 'earned_10k' then goal:=10000;reward:=1200;metric:='earned';
    when 'earned_100k' then goal:=100000;reward:=8000;metric:='earned';
    else raise exception 'bad_achievement';
  end case;
  progress := case metric when 'eggs' then s.eggs_opened when 'pets' then pets when 'zones' then s.zones else s.total_earned end;
  if progress < goal then raise exception 'achievement_locked'; end if;
  insert into public.farm_achievement_claims(user_id,achievement_id) values(uid,p_id) on conflict do nothing;
  get diagnostics inserted = row_count;
  if inserted=0 then raise exception 'achievement_claimed'; end if;
  update public.farm_saves set coins=coins+reward,total_earned=total_earned+reward,updated_at=now() where user_id=uid;
  perform public._farm_log(uid,'achievement_reward',jsonb_build_object('id',p_id,'reward',reward));
  return jsonb_build_object('reward',reward,'achievements',public.farm_achievements());
end $$;

-- -----------------------------------------------------------------------------
-- 7) Дополнительные глобальные инструменты администратора.
-- -----------------------------------------------------------------------------
create or replace function public.farm_admin_grant_all_coins(p_amount bigint)
returns bigint language plpgsql security definer set search_path=public as $$
declare uid uuid:=public._farm_need('global'); n bigint;
begin
  if p_amount is null or p_amount<1 or p_amount>1000000000 then raise exception 'bad_amount'; end if;
  update public.farm_saves set coins=coins+p_amount,total_earned=total_earned+p_amount,updated_at=now();
  get diagnostics n=row_count;
  perform public._farm_log(uid,'global_coin_gift',jsonb_build_object('amount_each',p_amount,'players',n));
  return n;
end $$;

create or replace function public.farm_admin_give_pet_all(p_pet_type text)
returns integer language plpgsql security definer set search_path=public as $$
declare uid uuid:=public._farm_need('global'); n integer;
begin
  if not exists(select 1 from public.farm_pet_types where id=p_pet_type) then raise exception 'bad_pet_type'; end if;
  insert into public.farm_pets(user_id,pet_type)
  select p.user_id,p_pet_type from public.farm_profiles p
  where (select count(*) from public.farm_pets x where x.user_id=p.user_id)<60
    and not exists(select 1 from public.farm_pets x where x.user_id=p.user_id and x.pet_type=p_pet_type);
  get diagnostics n=row_count;
  perform public._farm_log(uid,'global_pet_gift',jsonb_build_object('pet_type',p_pet_type,'players',n));
  return n;
end $$;

create or replace function public.farm_admin_set_player_coins(p_user uuid,p_coins bigint)
returns void language plpgsql security definer set search_path=public as $$
declare uid uuid:=public._farm_need('global');
begin
  if p_coins is null or p_coins<0 or p_coins>1000000000000 then raise exception 'bad_amount'; end if;
  update public.farm_saves set coins=p_coins,updated_at=now() where user_id=p_user;
  if not found then raise exception 'no_player'; end if;
  perform public._farm_log(uid,'set_player_coins',jsonb_build_object('target',p_user,'coins',p_coins));
end $$;

create or replace function public.farm_admin_clear_events()
returns integer language plpgsql security definer set search_path=public as $$
declare uid uuid:=public._farm_need('global'); n integer;
begin
  update public.farm_events set expires_at=now() where expires_at>now();
  get diagnostics n=row_count;
  perform public._farm_log(uid,'clear_all_events',jsonb_build_object('ended',n));
  return n;
end $$;

create or replace function public.farm_admin_clear_announcements()
returns integer language plpgsql security definer set search_path=public as $$
declare uid uuid:=public._farm_need('global'); n integer;
begin
  delete from public.farm_announcements;
  get diagnostics n=row_count;
  perform public._farm_log(uid,'clear_all_announcements',jsonb_build_object('deleted',n));
  return n;
end $$;

-- -----------------------------------------------------------------------------
-- 8) Grants / revokes. Клиент вызывает только проверяемые RPC.
-- -----------------------------------------------------------------------------
revoke all on function public.farm_crop_stock() from public, anon;
revoke all on function public.farm_admin_crop_stock() from public, anon;
revoke all on function public.farm_admin_set_crop_stock(text,integer) from public, anon;
revoke all on function public.farm_admin_roll_crop_stock() from public, anon;
revoke all on function public.farm_global_stock() from public, anon;
revoke all on function public.farm_daily_status() from public, anon;
revoke all on function public.farm_daily_claim() from public, anon;
revoke all on function public.farm_achievements() from public, anon;
revoke all on function public.farm_claim_achievement(text) from public, anon;
revoke all on function public.farm_admin_grant_all_coins(bigint) from public, anon;
revoke all on function public.farm_admin_give_pet_all(text) from public, anon;
revoke all on function public.farm_admin_set_player_coins(uuid,bigint) from public, anon;
revoke all on function public.farm_admin_clear_events() from public, anon;
revoke all on function public.farm_admin_clear_announcements() from public, anon;
grant execute on function public.farm_crop_stock(), public.farm_admin_crop_stock(),
  public.farm_admin_set_crop_stock(text,integer), public.farm_admin_roll_crop_stock(),
  public.farm_global_stock(), public.farm_daily_status(), public.farm_daily_claim(),
  public.farm_achievements(), public.farm_claim_achievement(text),
  public.farm_admin_grant_all_coins(bigint), public.farm_admin_give_pet_all(text),
  public.farm_admin_set_player_coins(uuid,bigint), public.farm_admin_clear_events(),
  public.farm_admin_clear_announcements() to authenticated;
