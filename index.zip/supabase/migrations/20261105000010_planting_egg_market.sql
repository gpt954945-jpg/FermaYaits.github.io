begin;
-- All farmable items are eggs; no wheat/vegetable products remain.
update public.farm_crops set name = case id
  when 'wheat' then 'Обычное яйцо' when 'carrot' then 'Крапчатое яйцо'
  when 'corn' then 'Солнечное яйцо' when 'pumpkin' then 'Тыквенное яйцо'
  when 'berry' then 'Ягодное яйцо' when 'blue_egg' then 'Голубое яйцо'
  when 'speckled_egg' then 'Пятнистое яйцо' when 'golden_egg' then 'Золотое яйцо'
  when 'rainbow_egg' then 'Радужное яйцо' when 'crystal_egg' then 'Кристальное яйцо'
  when 'moon_egg' then 'Лунное яйцо' when 'fire_egg' then 'Огненное яйцо'
  when 'ocean_egg' then 'Океанское яйцо' when 'forest_egg' then 'Лесное яйцо'
  when 'candy_egg' then 'Конфетное яйцо' when 'star_egg' then 'Звёздное яйцо'
  when 'shadow_egg' then 'Теневое яйцо' when 'galaxy_egg' then 'Галактическое яйцо'
  when 'royal_egg' then 'Королевское яйцо' when 'dragon_egg' then 'Драконье яйцо' else name end,
  min_zone=1,
  seed_cost=case id when 'wheat' then 20 when 'blue_egg' then 35 when 'carrot' then 55 when 'speckled_egg' then 80 when 'corn' then 120 when 'golden_egg' then 180 when 'pumpkin' then 260 when 'rainbow_egg' then 400 when 'crystal_egg' then 650 when 'berry' then 900 when 'moon_egg' then 1400 when 'fire_egg' then 2200 when 'ocean_egg' then 3500 when 'forest_egg' then 5500 when 'candy_egg' then 8500 when 'star_egg' then 13000 when 'shadow_egg' then 20000 when 'galaxy_egg' then 32000 when 'royal_egg' then 50000 when 'dragon_egg' then 80000 else seed_cost end,
  sell_price=case id when 'wheat' then 32 when 'blue_egg' then 58 when 'carrot' then 90 when 'speckled_egg' then 135 when 'corn' then 200 when 'golden_egg' then 300 when 'pumpkin' then 430 when 'rainbow_egg' then 660 when 'crystal_egg' then 1050 when 'berry' then 1450 when 'moon_egg' then 2250 when 'fire_egg' then 3500 when 'ocean_egg' then 5600 when 'forest_egg' then 8800 when 'candy_egg' then 13500 when 'star_egg' then 21000 when 'shadow_egg' then 32000 when 'galaxy_egg' then 51000 when 'royal_egg' then 80000 when 'dragon_egg' then 128000 else sell_price end;

create table if not exists public.farm_crop_stock(
 crop_id text primary key references public.farm_crops(id) on delete cascade,
 quantity integer not null default 4 check(quantity between 0 and 16),
 updated_at timestamptz not null default now()
);
insert into public.farm_crop_stock(crop_id,quantity)
select id,4+floor(random()*13)::int from public.farm_crops
on conflict(crop_id) do nothing;
alter table public.farm_crop_stock enable row level security;
drop policy if exists farm_crop_stock_read on public.farm_crop_stock;
create policy farm_crop_stock_read on public.farm_crop_stock for select to authenticated using(true);
grant select on public.farm_crop_stock to authenticated;

create or replace function public.farm_crop_stock() returns jsonb language sql stable security definer set search_path=public as $$
 select coalesce(jsonb_agg(jsonb_build_object('id',c.id,'name',c.name,'min_zone',c.min_zone,'seed_cost',c.seed_cost,'sell_price',c.sell_price,'grow_seconds',c.grow_seconds,'quantity',s.quantity) order by c.seed_cost),'[]'::jsonb)
 from public.farm_crops c join public.farm_crop_stock s on s.crop_id=c.id;
$$;

create or replace function public.farm_plant(p_plot integer,p_crop text) returns jsonb
language plpgsql security definer set search_path=public as $$
declare uid uuid:=auth.uid(); s public.farm_saves; c public.farm_crops; q integer;
begin
 if uid is null then raise exception 'not_authenticated'; end if;
 select * into s from public.farm_saves where user_id=uid for update;
 if not found then raise exception 'no_save'; end if;
 if p_plot is null or p_plot<0 or p_plot>17 then raise exception 'bad_plot'; end if;
 if (p_plot/6)+1>s.zones then raise exception 'zone_locked'; end if;
 if s.plots ? (p_plot::text) then raise exception 'plot_busy'; end if;
 select * into c from public.farm_crops where id=p_crop;
 if not found then raise exception 'bad_crop'; end if;
 if c.min_zone>s.zones then raise exception 'zone_locked'; end if;
 select quantity into q from public.farm_crop_stock where crop_id=p_crop for update;
 if coalesce(q,0)<=0 then raise exception 'crop_out_of_stock'; end if;
 if s.coins<c.seed_cost then raise exception 'not_enough_coins'; end if;
 update public.farm_crop_stock set quantity=quantity-1,updated_at=now() where crop_id=p_crop;
 update public.farm_saves set coins=coins-c.seed_cost,plots=plots||jsonb_build_object(p_plot::text,jsonb_build_object('crop',c.id,'at',extract(epoch from clock_timestamp()))),updated_at=now() where user_id=uid;
 return public._farm_state(uid);
end $$;

create or replace function public.farm_admin_crop_stock() returns jsonb language plpgsql stable security definer set search_path=public as $$
begin
 if not exists(select 1 from public.farm_profiles where user_id=auth.uid() and role in ('admin','owner')) then raise exception 'not_admin'; end if;
 return public.farm_crop_stock();
end $$;
create or replace function public.farm_admin_set_crop_stock(p_crop text,p_quantity integer) returns jsonb language plpgsql security definer set search_path=public as $$
begin
 if not exists(select 1 from public.farm_profiles where user_id=auth.uid() and role in ('admin','owner')) then raise exception 'not_admin'; end if;
 if p_quantity<0 or p_quantity>16 then raise exception 'bad_quantity'; end if;
 update public.farm_crop_stock set quantity=p_quantity,updated_at=now() where crop_id=p_crop;
 if not found then raise exception 'bad_crop'; end if;
 return public.farm_crop_stock();
end $$;
revoke all on function public.farm_crop_stock() from public,anon;
grant execute on function public.farm_crop_stock() to authenticated;
grant execute on function public.farm_admin_crop_stock() to authenticated;
grant execute on function public.farm_admin_set_crop_stock(text,integer) to authenticated;
commit;
