-- 15 новых посадочных яиц + 6 инкубационных яиц и 30 питомцев.
-- Безопасно повторно запускать: все вставки используют ON CONFLICT.
begin;

insert into public.farm_crops (id,name,min_zone,seed_cost,sell_price,grow_seconds) values
('blue_egg','Голубое',1,8,20,35),
('speckled_egg','Крапчатое',1,18,50,65),
('golden_egg','Золотое',1,50,140,90),
('rainbow_egg','Радужное',1,100,300,130),
('crystal_egg','Кристальное',2,220,700,180),
('moon_egg','Лунное',2,400,1300,220),
('fire_egg','Огненное',2,700,2200,260),
('ocean_egg','Океанское',2,1200,4000,300),
('forest_egg','Лесное',2,2500,8500,360),
('candy_egg','Конфетное',2,5000,17000,420),
('star_egg','Звёздное',3,12000,42000,480),
('shadow_egg','Теневое',3,25000,90000,540),
('galaxy_egg','Галактическое',3,50000,180000,600),
('royal_egg','Королевское',3,100000,380000,720),
('dragon_egg','Драконье',3,250000,1000000,900)
on conflict (id) do nothing;

insert into public.farm_eggs (id,name,price,min_zone) values
('sky','Небесное яйцо',2000,1),
('ocean','Океанское яйцо',6000,1),
('lava','Лавовое яйцо',50000,2),
('crystal','Кристальное яйцо',100000,2),
('shadow','Теневое яйцо',500000,3),
('cosmic','Космическое яйцо',1500000,3)
on conflict (id) do nothing;

insert into public.farm_pet_types (id,name,rarity,income,weight,egg_id) values
('sparrow','Воробей','common',3,55,'sky'),
('owl','Совёнок','uncommon',8,25,'sky'),
('pegasus','Пегас','rare',22,14,'sky'),
('griffin','Грифон','epic',60,5,'sky'),
('starbird','Звёздная птица','legendary',180,1,'sky'),
('turtle','Черепашка','common',6,55,'ocean'),
('seal','Тюлень','uncommon',16,25,'ocean'),
('dolphin','Дельфин','rare',45,14,'ocean'),
('shark','Акула','epic',120,5,'ocean'),
('kraken','Кракен','legendary',360,1,'ocean'),
('salamander','Саламандра','common',30,55,'lava'),
('firecat','Огненный кот','uncommon',80,25,'lava'),
('magma_golem','Магмовый голем','rare',220,14,'lava'),
('wyvern','Виверна','epic',600,5,'lava'),
('inferno_dragon','Инферно-дракон','legendary',1800,1,'lava'),
('crystal_moth','Кристальная моль','common',55,55,'crystal'),
('gem_beetle','Самоцветный жук','uncommon',140,25,'crystal'),
('crystal_fox','Кристальная лиса','rare',400,14,'crystal'),
('crystal_golem','Кристальный голем','epic',1100,5,'crystal'),
('diamond_dragon','Алмазный дракон','legendary',3300,1,'crystal'),
('bat','Летучая мышь','common',250,55,'shadow'),
('black_cat','Чёрный кот','uncommon',650,25,'shadow'),
('phantom','Фантом','rare',1800,14,'shadow'),
('shadow_wolf','Теневой волк','epic',5000,5,'shadow'),
('reaper','Жнец','legendary',15000,1,'shadow'),
('alien','Пришелец','common',700,55,'cosmic'),
('moon_rabbit','Лунный кролик','uncommon',1800,25,'cosmic'),
('comet_fox','Кометная лиса','rare',5000,14,'cosmic'),
('nebula_dragon','Туманность-дракон','epic',14000,5,'cosmic'),
('galaxy_guardian','Страж галактики','legendary',42000,1,'cosmic')
on conflict (id) do nothing;

insert into public.farm_egg_stock (egg_id,quantity,max_quantity)
select id,1000,10000 from public.farm_eggs
on conflict (egg_id) do update set
  quantity=greatest(public.farm_egg_stock.quantity,1000),
  max_quantity=greatest(public.farm_egg_stock.max_quantity,10000),
  updated_at=now();

update public.farm_egg_stock
set quantity=greatest(quantity,1000),max_quantity=greatest(max_quantity,10000),updated_at=now()
where true;

commit;
