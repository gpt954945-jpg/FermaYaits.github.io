revoke all on function public._farm_need(text) from public, anon, authenticated;
revoke all on function public.farm_admin_restock(text,integer) from public, anon;
revoke all on function public.farm_create_poll(text,jsonb,integer) from public, anon;
revoke all on function public.farm_poll_vote(bigint,integer) from public, anon;
grant execute on function public.farm_admin_restock(text,integer),
  public.farm_create_poll(text,jsonb,integer),
  public.farm_poll_vote(bigint,integer) to authenticated;
