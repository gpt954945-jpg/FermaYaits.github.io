-- Ферма «Дон Сомбреро»: схема, RLS, каталог.
-- Только ДОБАВЛЯЕТ объекты с префиксом farm_. Таблицы Soul Clicker не затрагиваются.

create table if not exists public.farm_config (
  key text primary key,
  value numeric not null
);

-- Приватные настройки (e-mail глобального админа). Без политик и без грантов: клиент не видит.
create table if not exists public.farm_private (
  key text primary key,
  value text not null
);

create table if not exists public.farm_profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  username text not null check (username ~ '^[A-Za-z][A-Za-z0-9_]{2,17}$'),
  role text not null default 'player' check (role in ('player','admin','GLOBAL_ADMIN')),
  created_at timestamptz not null default now()
);
create unique index if not exists farm_profiles_username_ci on public.farm_profiles (lower(username));

create table if not exists public.farm_saves (
  user_id uuid primary key references auth.users(id) on delete cascade,
  coins bigint not null default 60 check (coins >= 0),
  total_earned bigint not null default 0 check (total_earned >= 0),
  zones int not null default 1 check (zones between 1 and 3),
  plots jsonb not null default '{}'::jsonb,
  crops jsonb not null default '{}'::jsonb,
  eggs_opened int not null default 0,
  updated_at timestamptz not null default now()
);

create table if not exists public.farm_crops (
  id text primary key,
  name text not null,
  grow_seconds int not null check (grow_seconds > 0),
  seed_cost int not null check (seed_cost >= 0),
  sell_price int not null check (sell_price >= 0),
  min_zone int not null default 1
);

create table if not exists public.farm_zones (
  zone int primary key,
  name text not null,
  price bigint not null
);

create table if not exists public.farm_eggs (
  id text primary key,
  name text not null,
  price bigint not null check (price >= 0),
  min_zone int not null default 1
);

create table if not exists public.farm_pet_types (
  id text primary key,
  name text not null,
  rarity text not null check (rarity in ('common','uncommon','rare','epic','legendary','mythic')),
  income numeric not null check (income > 0),
  weight numeric not null check (weight >= 0),
  egg_id text not null references public.farm_eggs(id)
);

create table if not exists public.farm_pets (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  pet_type text not null references public.farm_pet_types(id),
  stand_idx int check (stand_idx between 0 and 11),
  collected_at timestamptz not null default now(),
  created_at timestamptz not null default now()
);
create unique index if not exists farm_pets_stand_uq on public.farm_pets (user_id, stand_idx) where stand_idx is not null;
create index if not exists farm_pets_user_idx on public.farm_pets (user_id);

create table if not exists public.farm_announcements (
  id bigint generated always as identity primary key,
  message text not null check (char_length(message) between 1 and 240),
  created_by uuid references auth.users(id) on delete set null,
  created_by_name text not null default 'Администрация',
  created_at timestamptz not null default now(),
  expires_at timestamptz not null
);
create index if not exists farm_announcements_exp on public.farm_announcements (expires_at);

create table if not exists public.farm_events (
  id bigint generated always as identity primary key,
  kind text not null check (kind in ('income','growth','sell')),
  title text not null check (char_length(title) between 1 and 80),
  mult numeric not null check (mult >= 1 and mult <= 100),
  starts_at timestamptz not null default now(),
  expires_at timestamptz not null,
  created_by uuid references auth.users(id) on delete set null
);

create table if not exists public.farm_log (
  id bigint generated always as identity primary key,
  user_id uuid references auth.users(id) on delete set null,
  action text not null,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index if not exists farm_log_user_idx on public.farm_log (user_id, created_at desc);

-- ---------- RLS ----------
alter table public.farm_config enable row level security;
alter table public.farm_private enable row level security;
alter table public.farm_profiles enable row level security;
alter table public.farm_saves enable row level security;
alter table public.farm_crops enable row level security;
alter table public.farm_zones enable row level security;
alter table public.farm_eggs enable row level security;
alter table public.farm_pet_types enable row level security;
alter table public.farm_pets enable row level security;
alter table public.farm_announcements enable row level security;
alter table public.farm_events enable row level security;
alter table public.farm_log enable row level security;

-- Клиент только читает. Любые изменения идут через серверные функции (security definer).
revoke all on public.farm_config, public.farm_private, public.farm_profiles, public.farm_saves,
  public.farm_crops, public.farm_zones, public.farm_eggs, public.farm_pet_types, public.farm_pets,
  public.farm_announcements, public.farm_events, public.farm_log from public, anon, authenticated;

grant select on public.farm_config, public.farm_crops, public.farm_zones, public.farm_eggs,
  public.farm_pet_types, public.farm_announcements, public.farm_events to anon, authenticated;
grant select on public.farm_profiles, public.farm_saves, public.farm_pets, public.farm_log to authenticated;

create policy farm_config_read on public.farm_config for select to anon, authenticated using (true);
create policy farm_crops_read on public.farm_crops for select to anon, authenticated using (true);
create policy farm_zones_read on public.farm_zones for select to anon, authenticated using (true);
create policy farm_eggs_read on public.farm_eggs for select to anon, authenticated using (true);
create policy farm_pet_types_read on public.farm_pet_types for select to anon, authenticated using (true);
create policy farm_announcements_read on public.farm_announcements for select to anon, authenticated using (true);
create policy farm_events_read on public.farm_events for select to anon, authenticated using (true);
create policy farm_profiles_own on public.farm_profiles for select to authenticated using (user_id = (select auth.uid()));
create policy farm_saves_own on public.farm_saves for select to authenticated using (user_id = (select auth.uid()));
create policy farm_pets_own on public.farm_pets for select to authenticated using (user_id = (select auth.uid()));
create policy farm_log_own on public.farm_log for select to authenticated using (user_id = (select auth.uid()));

-- ---------- Каталог ----------
insert into public.farm_config(key, value) values
  ('income_mult',1),('sell_mult',1),('growth_speed',1),('offline_cap_hours',4)
on conflict (key) do nothing;

insert into public.farm_crops(id,name,grow_seconds,seed_cost,sell_price,min_zone) values
  ('wheat','Пшеница',20,5,12,1),
  ('carrot','Морковь',45,15,40,1),
  ('corn','Кукуруза',90,40,120,1),
  ('pumpkin','Тыква',180,100,340,2),
  ('berry','Клубника',300,250,900,3)
on conflict (id) do nothing;

insert into public.farm_zones(zone,name,price) values
  (1,'Луг',0),(2,'Дубовая роща',4000),(3,'Золотые холмы',60000)
on conflict (zone) do nothing;

insert into public.farm_eggs(id,name,price,min_zone) values
  ('meadow','Луговое яйцо',400,1),
  ('grove','Яйцо рощи',15000,2),
  ('peak','Яйцо холмов',150000,3)
on conflict (id) do nothing;

insert into public.farm_pet_types(id,name,rarity,income,weight,egg_id) values
  ('chick','Цыплёнок','common',0.5,55,'meadow'),
  ('duck','Утёнок','common',0.8,25,'meadow'),
  ('goat','Козлик','uncommon',2.5,12,'meadow'),
  ('piglet','Поросёнок','rare',8,7,'meadow'),
  ('hero','Дон Сомбреро','legendary',60,1,'meadow'),
  ('bunny','Кролик','uncommon',6,45,'grove'),
  ('fox','Лиса','rare',20,32,'grove'),
  ('wolf','Волк','epic',70,17,'grove'),
  ('unicorn','Единорог','legendary',260,5.5,'grove'),
  ('hero_neo','Сомбреро Нео','mythic',900,0.5,'grove'),
  ('cat','Кот','rare',45,40,'peak'),
  ('dragon','Дракончик','epic',180,35,'peak'),
  ('phoenix','Феникс','legendary',700,21,'peak'),
  ('hero_gold','Эль Дорадо','mythic',2500,4,'peak')
on conflict (id) do nothing;

-- ---------- Realtime ----------
do $$
begin
  if exists (select 1 from pg_publication where pubname = 'supabase_realtime') then
    begin alter publication supabase_realtime add table public.farm_announcements; exception when duplicate_object then null; end;
    begin alter publication supabase_realtime add table public.farm_events; exception when duplicate_object then null; end;
  end if;
end $$;
