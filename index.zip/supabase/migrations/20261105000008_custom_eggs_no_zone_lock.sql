-- Custom eggs are available in every zone and receive a starter pet automatically.
create or replace function public.farm_admin_save_egg(
 p_id text,p_name text,p_price bigint,p_min_zone integer,
 p_quantity integer default 0,p_max_quantity integer default 1000
) returns jsonb language plpgsql security definer set search_path=public as $$
declare v_id text:=lower(trim(coalesce(p_id,''))); v_pet text;
begin
 if auth.uid() is null then raise exception 'not_authenticated'; end if;
 if v_id !~ '^[a-z0-9_]{2,32}$' then raise exception 'bad_egg_id'; end if;
 if length(trim(coalesce(p_name,''))) not between 2 and 40 then raise exception 'bad_egg_name'; end if;
 if p_price is null or p_price<0 or p_price>1000000000 then raise exception 'bad_egg_price'; end if;
 if p_quantity is null or p_quantity<0 or p_quantity>1000000 then raise exception 'bad_egg_quantity'; end if;
 if p_max_quantity is null or p_max_quantity<1 or p_max_quantity>1000000 or p_quantity>p_max_quantity then raise exception 'bad_egg_quantity'; end if;
 insert into public.farm_eggs(id,name,price,min_zone) values(v_id,trim(p_name),p_price,0)
 on conflict(id) do update set name=excluded.name,price=excluded.price,min_zone=0;
 insert into public.farm_egg_stock(egg_id,quantity,max_quantity,updated_at) values(v_id,p_quantity,p_max_quantity,now())
 on conflict(egg_id) do update set quantity=excluded.quantity,max_quantity=excluded.max_quantity,updated_at=now();
 if not exists(select 1 from public.farm_pet_types where egg_id=v_id) then
   v_pet:=left(v_id,22)||'_custom_pet';
   insert into public.farm_pet_types(id,name,rarity,income,weight,egg_id)
   values(v_pet,left(trim(p_name)||' питомец',60),'common',1,100,v_id) on conflict(id) do nothing;
 end if;
 return jsonb_build_object('id',v_id,'name',trim(p_name),'price',p_price,'min_zone',0,'quantity',p_quantity,'max_quantity',p_max_quantity);
end $$;
update public.farm_eggs set min_zone=0 where min_zone<>0;

create or replace function public.farm_buy_egg(p_egg text)
returns jsonb language plpgsql security definer set search_path=public as $$
declare uid uuid:=auth.uid(); s public.farm_saves; e public.farm_eggs; t public.farm_pet_types; pick public.farm_pet_types; total_w numeric; roll numeric; acc numeric:=0; pid uuid; stock public.farm_egg_stock;
begin
 if uid is null then raise exception 'not_authenticated'; end if;
 perform public.farm_global_stock();
 select * into s from public.farm_saves where user_id=uid for update; if not found then raise exception 'no_save'; end if;
 select * into e from public.farm_eggs where id=p_egg; if not found then raise exception 'bad_egg'; end if;
 if s.coins<e.price then raise exception 'not_enough_coins'; end if;
 if (select count(*) from public.farm_pets where user_id=uid)>=60 then raise exception 'inventory_full'; end if;
 select * into stock from public.farm_egg_stock where egg_id=p_egg for update;
 if not found or stock.quantity<=0 then raise exception 'egg_out_of_stock'; end if;
 select sum(weight) into total_w from public.farm_pet_types where egg_id=e.id and weight>0;
 if total_w is null then raise exception 'bad_egg'; end if;
 roll:=random()*total_w;
 for t in select * from public.farm_pet_types where egg_id=e.id and weight>0 order by weight desc,id loop acc:=acc+t.weight;pick:=t;exit when roll<acc;end loop;
 insert into public.farm_pets(user_id,pet_type) values(uid,pick.id) returning id into pid;
 update public.farm_egg_stock set quantity=quantity-1,updated_at=now() where egg_id=p_egg;
 update public.farm_saves set coins=coins-e.price,eggs_opened=eggs_opened+1,updated_at=now() where user_id=uid;
 perform public._farm_log(uid,'buy_egg',jsonb_build_object('egg',e.id,'price',e.price,'pet',pick.id,'rarity',pick.rarity));
 return public._farm_state(uid)||jsonb_build_object('hatched',jsonb_build_object('id',pid,'type',pick.id,'rarity',pick.rarity));
end $$;
grant execute on function public.farm_admin_save_egg(text,text,bigint,integer,integer,integer),public.farm_buy_egg(text) to authenticated;
revoke all on function public.farm_admin_save_egg(text,text,bigint,integer,integer,integer),public.farm_buy_egg(text) from public,anon;
