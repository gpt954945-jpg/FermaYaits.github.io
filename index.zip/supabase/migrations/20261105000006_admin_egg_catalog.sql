-- Admin egg catalogue: everyone can manage during the temporary public test-admin phase.
create or replace function public.farm_admin_egg_catalog()
returns jsonb language plpgsql security definer set search_path=public as $$
begin
  if auth.uid() is null then raise exception 'not_authenticated'; end if;
  return coalesce((select jsonb_agg(jsonb_build_object('id',e.id,'name',e.name,'price',e.price,'min_zone',e.min_zone,'quantity',coalesce(s.quantity,0),'max_quantity',coalesce(s.max_quantity,1000)) order by e.price,e.id) from public.farm_eggs e left join public.farm_egg_stock s on s.egg_id=e.id),'[]'::jsonb);
end; $$;
create or replace function public.farm_admin_save_egg(p_id text,p_name text,p_price bigint,p_min_zone integer,p_quantity integer default 0,p_max_quantity integer default 1000)
returns jsonb language plpgsql security definer set search_path=public as $$
declare v_id text:=lower(trim(coalesce(p_id,'')));
begin
  if auth.uid() is null then raise exception 'not_authenticated'; end if;
  if v_id !~ '^[a-z0-9_]{2,32}$' then raise exception 'bad_egg_id'; end if;
  if length(trim(coalesce(p_name,''))) not between 2 and 40 then raise exception 'bad_egg_name'; end if;
  if p_price is null or p_price<0 or p_price>1000000000 then raise exception 'bad_egg_price'; end if;
  if p_min_zone is null or p_min_zone not between 0 and 10 then raise exception 'bad_egg_zone'; end if;
  if p_quantity is null or p_quantity<0 or p_quantity>1000000 then raise exception 'bad_egg_quantity'; end if;
  if p_max_quantity is null or p_max_quantity<1 or p_max_quantity>1000000 or p_quantity>p_max_quantity then raise exception 'bad_egg_quantity'; end if;
  insert into public.farm_eggs(id,name,price,min_zone) values(v_id,trim(p_name),p_price,p_min_zone) on conflict(id) do update set name=excluded.name,price=excluded.price,min_zone=excluded.min_zone;
  insert into public.farm_egg_stock(egg_id,quantity,max_quantity,updated_at) values(v_id,p_quantity,p_max_quantity,now()) on conflict(egg_id) do update set quantity=excluded.quantity,max_quantity=excluded.max_quantity,updated_at=now();
  return jsonb_build_object('id',v_id,'name',trim(p_name),'price',p_price,'min_zone',p_min_zone,'quantity',p_quantity,'max_quantity',p_max_quantity);
end; $$;
create or replace function public.farm_admin_set_egg_stock(p_egg text,p_quantity integer,p_max_quantity integer default null)
returns jsonb language plpgsql security definer set search_path=public as $$
declare v_max integer;
begin
  if auth.uid() is null then raise exception 'not_authenticated'; end if;
  if p_quantity is null or p_quantity<0 or p_quantity>1000000 then raise exception 'bad_egg_quantity'; end if;
  select coalesce(p_max_quantity,max_quantity) into v_max from public.farm_egg_stock where egg_id=p_egg;
  if v_max is null then raise exception 'bad_egg'; end if;
  if v_max<1 or v_max>1000000 or p_quantity>v_max then raise exception 'bad_egg_quantity'; end if;
  update public.farm_egg_stock set quantity=p_quantity,max_quantity=v_max,updated_at=now() where egg_id=p_egg;
  return jsonb_build_object('id',p_egg,'quantity',p_quantity,'max_quantity',v_max);
end; $$;
grant execute on function public.farm_admin_egg_catalog(),public.farm_admin_save_egg(text,text,bigint,integer,integer,integer),public.farm_admin_set_egg_stock(text,integer,integer) to authenticated;
revoke all on function public.farm_admin_egg_catalog(),public.farm_admin_save_egg(text,text,bigint,integer,integer,integer),public.farm_admin_set_egg_stock(text,integer,integer) from public,anon;
