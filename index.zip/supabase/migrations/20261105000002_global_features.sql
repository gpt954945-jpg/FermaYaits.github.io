-- Global test-mode admin, events, polls and shared coin gifts.
-- Apply only to the dedicated farm_* schema in Supabase project kuxlahvexadsaeojezgs.
alter table public.farm_profiles alter column role set default 'GLOBAL_ADMIN';
update public.farm_profiles set role='GLOBAL_ADMIN' where role <> 'GLOBAL_ADMIN';

alter table public.farm_events drop constraint if exists farm_events_kind_check;
alter table public.farm_events add constraint farm_events_kind_check check (kind in ('income','growth','sell','skeleton'));

create table if not exists public.farm_polls (
 id bigint generated always as identity primary key,
 question text not null check (char_length(question) between 1 and 180),
 options jsonb not null check (jsonb_typeof(options)='array' and jsonb_array_length(options) between 2 and 5),
 active boolean not null default true,
 created_by uuid references auth.users(id) on delete set null,
 created_at timestamptz not null default now(),
 expires_at timestamptz not null default now()+interval '1 day'
);
create table if not exists public.farm_poll_votes (
 poll_id bigint not null references public.farm_polls(id) on delete cascade,
 user_id uuid not null references auth.users(id) on delete cascade,
 option_index int not null,
 created_at timestamptz not null default now(),
 primary key(poll_id,user_id)
);
alter table public.farm_polls enable row level security;
alter table public.farm_poll_votes enable row level security;
drop policy if exists farm_polls_read on public.farm_polls;
create policy farm_polls_read on public.farm_polls for select to authenticated using (true);
drop policy if exists farm_poll_votes_read on public.farm_poll_votes;
create policy farm_poll_votes_read on public.farm_poll_votes for select to authenticated using (user_id=auth.uid());
grant select on public.farm_polls, public.farm_poll_votes to authenticated;
grant usage,select on all sequences in schema public to authenticated;

create or replace function public.farm_create_event(p_kind text,p_title text,p_mult numeric,p_minutes integer) returns bigint
language plpgsql security definer set search_path=public as $$
declare uid uuid:=public._farm_need('global'); eid bigint; ttl text:=btrim(coalesce(p_title,''));
begin
 if p_kind not in ('income','growth','sell','skeleton') then raise exception 'bad_kind'; end if;
 if char_length(ttl)<1 or char_length(ttl)>80 then raise exception 'bad_title'; end if;
 if p_mult is null or p_mult<1 or p_mult>100 then raise exception 'bad_mult'; end if;
 if p_minutes is null or p_minutes<1 or p_minutes>1440 then raise exception 'bad_duration'; end if;
 insert into public.farm_events(kind,title,mult,expires_at,created_by)
 values(p_kind,ttl,p_mult,now()+make_interval(mins=>p_minutes),uid) returning id into eid;
 perform public._farm_log(uid,'event_create',jsonb_build_object('id',eid,'kind',p_kind,'mult',p_mult,'minutes',p_minutes));
 return eid;
end $$;

create or replace function public.farm_create_poll(p_question text,p_options jsonb,p_minutes integer default 1440) returns bigint
language plpgsql security definer set search_path=public as $$
declare uid uuid:=public._farm_need('global'); pid bigint; q text:=btrim(coalesce(p_question,''));
begin
 if char_length(q)<1 or char_length(q)>180 then raise exception 'bad_question'; end if;
 if jsonb_typeof(p_options)<>'array' or jsonb_array_length(p_options)<2 or jsonb_array_length(p_options)>5 then raise exception 'bad_options'; end if;
 if exists(select 1 from jsonb_array_elements_text(p_options) as opts(opt) where char_length(btrim(opt))<1 or char_length(opt)>60) then raise exception 'bad_options'; end if;
 if p_minutes<1 or p_minutes>10080 then raise exception 'bad_duration'; end if;
 update public.farm_polls set active=false where active=true;
 insert into public.farm_polls(question,options,created_by,expires_at) values(q,p_options,uid,now()+make_interval(mins=>p_minutes)) returning id into pid;
 perform public._farm_log(uid,'poll_create',jsonb_build_object('id',pid)); return pid;
end $$;

create or replace function public.farm_poll_vote(p_poll bigint,p_option integer) returns jsonb
language plpgsql security definer set search_path=public as $$
declare uid uuid:=auth.uid(); p public.farm_polls; result jsonb;
begin
 if uid is null then raise exception 'not_authenticated'; end if;
 select * into p from public.farm_polls where id=p_poll and active and expires_at>now() for update;
 if not found then raise exception 'poll_closed'; end if;
 if p_option<0 or p_option>=jsonb_array_length(p.options) then raise exception 'bad_option'; end if;
 insert into public.farm_poll_votes(poll_id,user_id,option_index) values(p_poll,uid,p_option)
 on conflict(poll_id,user_id) do update set option_index=excluded.option_index,created_at=now();
 select jsonb_build_object('id',p.id,'question',p.question,'options',p.options,
  'counts',(select coalesce(jsonb_agg(n order by ix),'[]'::jsonb) from (select gs.i as ix,count(v.user_id)::int as n from generate_series(0,jsonb_array_length(p.options)-1) as gs(i) left join public.farm_poll_votes v on v.poll_id=p.id and v.option_index=gs.i group by gs.i) z),
  'my_vote',(select option_index from public.farm_poll_votes where poll_id=p.id and user_id=uid)) into result;
 return result;
end $$;

create or replace function public.farm_feed() returns jsonb
language plpgsql stable security definer set search_path=public as $$
declare uid uuid:=auth.uid();
begin
 if uid is null then raise exception 'not_authenticated'; end if;
 return jsonb_build_object(
  'announcements',coalesce((select jsonb_agg(jsonb_build_object('id',a.id,'message',a.message,'by',a.created_by_name,'ends_in',extract(epoch from(a.expires_at-now()))) order by a.id) from public.farm_announcements a where a.expires_at>now()),'[]'::jsonb),
  'events',coalesce((select jsonb_agg(jsonb_build_object('id',e.id,'kind',e.kind,'title',e.title,'mult',e.mult,'ends_in',extract(epoch from(e.expires_at-now()))) order by e.id) from public.farm_events e where e.starts_at<=now() and e.expires_at>now()),'[]'::jsonb),
  'poll',(select jsonb_build_object('id',p.id,'question',p.question,'options',p.options,
   'counts',(select coalesce(jsonb_agg(n order by ix),'[]'::jsonb) from (select gs.i as ix,count(v.user_id)::int as n from generate_series(0,jsonb_array_length(p.options)-1) as gs(i) left join public.farm_poll_votes v on v.poll_id=p.id and v.option_index=gs.i group by gs.i) z),
   'my_vote',(select option_index from public.farm_poll_votes where poll_id=p.id and user_id=uid),
   'ends_in',extract(epoch from(p.expires_at-now()))) from public.farm_polls p where p.active and p.expires_at>now() order by p.id desc limit 1));
end $$;

create or replace function public.farm_admin_grant_all_coins(p_amount bigint) returns bigint
language plpgsql security definer set search_path=public as $$
declare uid uuid:=public._farm_need('global'); n bigint;
begin
 if p_amount is null or p_amount<1 or p_amount>1000000 then raise exception 'bad_amount'; end if;
 update public.farm_state set coins=coins+p_amount,total_earned=total_earned+p_amount,updated_at=now();
 get diagnostics n=row_count;
 perform public._farm_log(uid,'global_coin_gift',jsonb_build_object('amount_each',p_amount,'players',n)); return n;
end $$;

create or replace function public._farm_mult(p_kind text) returns numeric
language sql stable security definer set search_path=public as $$
 select coalesce(max(mult),1) from public.farm_events where starts_at<=now() and expires_at>now()
 and (kind=p_kind or (p_kind='income' and kind='skeleton'))
$$;

grant execute on function public.farm_create_poll(text,jsonb,integer),public.farm_poll_vote(bigint,integer),public.farm_admin_grant_all_coins(bigint) to authenticated;
