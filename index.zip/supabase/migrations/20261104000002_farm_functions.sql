-- Серверная логика фермы. Клиент не может менять таблицы напрямую (см. 0001), только вызывать эти функции.

-- ---------- внутренние помощники (недоступны клиенту) ----------
create or replace function public._farm_cfg(k text) returns numeric
language sql stable security definer set search_path = public as $$
  select coalesce((select value from farm_config where key = k), 1)
$$;

create or replace function public._farm_mult(p_kind text) returns numeric
language sql stable security definer set search_path = public as $$
  select coalesce(max(mult), 1) from farm_events
  where kind = p_kind and starts_at <= now() and expires_at > now()
$$;

create or replace function public._farm_log(p_uid uuid, p_action text, p_details jsonb default '{}'::jsonb) returns void
language sql security definer set search_path = public as $$
  insert into farm_log(user_id, action, details) values (p_uid, p_action, coalesce(p_details, '{}'::jsonb))
$$;

create or replace function public._farm_role(p_uid uuid) returns text
language sql stable security definer set search_path = public as $$
  select role from farm_profiles where user_id = p_uid
$$;

create or replace function public._farm_state(p_uid uuid) returns jsonb
language plpgsql security definer set search_path = public as $$
declare r jsonb;
begin
  select jsonb_build_object(
    'user_id', p.user_id,
    'username', p.username,
    'role', p.role,
    'coins', s.coins,
    'total_earned', s.total_earned,
    'zones', s.zones,
    'plots', s.plots,
    'crops', s.crops,
    'eggs_opened', s.eggs_opened,
    'pets', coalesce((select jsonb_agg(jsonb_build_object(
        'id', f.id, 'type', f.pet_type, 'stand', f.stand_idx,
        'collected_at', extract(epoch from f.collected_at)) order by f.created_at)
      from farm_pets f where f.user_id = p_uid), '[]'::jsonb),
    'config', jsonb_build_object(
        'income_mult', _farm_cfg('income_mult'), 'sell_mult', _farm_cfg('sell_mult'),
        'growth_speed', _farm_cfg('growth_speed'), 'offline_cap_hours', _farm_cfg('offline_cap_hours')),
    'event_mult', jsonb_build_object(
        'income', _farm_mult('income'), 'growth', _farm_mult('growth'), 'sell', _farm_mult('sell')),
    'now', extract(epoch from clock_timestamp())
  ) into r
  from farm_profiles p join farm_saves s on s.user_id = p.user_id
  where p.user_id = p_uid;
  return r;
end $$;

-- Начисляет доход со стоек (всех или одного питомца). Возвращает выплаченную сумму.
create or replace function public._farm_collect(p_uid uuid, p_pet uuid default null) returns bigint
language plpgsql security definer set search_path = public as $$
declare
  rec record; amt numeric; whole bigint; total bigint := 0;
  mult numeric; cap numeric; ts timestamptz := clock_timestamp();
begin
  mult := _farm_cfg('income_mult') * _farm_mult('income');
  cap := greatest(_farm_cfg('offline_cap_hours'), 0.1) * 3600;
  for rec in
    select f.id, f.collected_at, t.income
    from farm_pets f join farm_pet_types t on t.id = f.pet_type
    where f.user_id = p_uid and f.stand_idx is not null and (p_pet is null or f.id = p_pet)
    for update of f
  loop
    amt := rec.income * mult * least(extract(epoch from (ts - rec.collected_at)), cap);
    whole := floor(amt);
    if whole >= 1 then
      update farm_pets set collected_at = ts where id = rec.id;
      total := total + whole;
    end if;
  end loop;
  if total > 0 then
    update farm_saves set coins = coins + total, total_earned = total_earned + total, updated_at = now()
    where user_id = p_uid;
  end if;
  return total;
end $$;

-- ---------- вход / регистрация профиля ----------
create or replace function public.farm_init(p_username text default null) returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  uid uuid := auth.uid();
  em text; confirmed timestamptz; admin_email text;
  prof farm_profiles; uname text; is_admin_identity boolean;
begin
  if uid is null then raise exception 'not_authenticated'; end if;

  select email, email_confirmed_at into em, confirmed from auth.users where id = uid;
  select value into admin_email from farm_private where key = 'global_admin_email';
  -- Личность подтверждена только если e-mail аккаунта подтверждён и совпадает с записанным на сервере.
  is_admin_identity := admin_email is not null and em is not null and confirmed is not null
                       and lower(em) = lower(admin_email);

  select * into prof from farm_profiles where user_id = uid;
  if not found then
    uname := btrim(coalesce(p_username, ''));
    if uname !~ '^[A-Za-z][A-Za-z0-9_]{2,17}$' then raise exception 'bad_username'; end if;
    if lower(uname) = 'ravexium' and not (is_admin_identity and uname = 'Ravexium') then
      raise exception 'name_reserved';
    end if;
    begin
      insert into farm_profiles(user_id, username) values (uid, uname) returning * into prof;
    exception when unique_violation then
      raise exception 'name_taken';
    end;
    insert into farm_saves(user_id) values (uid) on conflict do nothing;
    perform _farm_log(uid, 'register', jsonb_build_object('username', uname));
  end if;

  if prof.username = 'Ravexium' and is_admin_identity then
    if prof.role <> 'GLOBAL_ADMIN' then
      update farm_profiles set role = 'GLOBAL_ADMIN' where user_id = uid;
      perform _farm_log(uid, 'global_admin_granted', '{}'::jsonb);
    end if;
  elsif prof.role = 'GLOBAL_ADMIN' then
    update farm_profiles set role = 'player' where user_id = uid;
    perform _farm_log(uid, 'global_admin_revoked', '{}'::jsonb);
  end if;

  return _farm_state(uid);
end $$;

create or replace function public.farm_state() returns jsonb
language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'not_authenticated'; end if;
  if not exists (select 1 from farm_profiles where user_id = auth.uid()) then raise exception 'no_profile'; end if;
  return _farm_state(auth.uid());
end $$;

-- ---------- грядки ----------
create or replace function public.farm_plant(p_plot int, p_crop text) returns jsonb
language plpgsql security definer set search_path = public as $$
declare uid uuid := auth.uid(); s farm_saves; c farm_crops;
begin
  if uid is null then raise exception 'not_authenticated'; end if;
  select * into s from farm_saves where user_id = uid for update;
  if not found then raise exception 'no_save'; end if;
  if p_plot is null or p_plot < 0 or p_plot > 17 then raise exception 'bad_plot'; end if;
  if (p_plot / 6) + 1 > s.zones then raise exception 'zone_locked'; end if;
  if s.plots ? (p_plot::text) then raise exception 'plot_busy'; end if;
  select * into c from farm_crops where id = p_crop;
  if not found then raise exception 'bad_crop'; end if;
  if c.min_zone > s.zones then raise exception 'zone_locked'; end if;
  if s.coins < c.seed_cost then raise exception 'not_enough_coins'; end if;
  update farm_saves set
    coins = coins - c.seed_cost,
    plots = plots || jsonb_build_object(p_plot::text, jsonb_build_object('crop', c.id, 'at', extract(epoch from clock_timestamp()))),
    updated_at = now()
  where user_id = uid;
  return _farm_state(uid);
end $$;

create or replace function public.farm_harvest(p_plot int) returns jsonb
language plpgsql security definer set search_path = public as $$
declare uid uuid := auth.uid(); s farm_saves; c farm_crops; pl jsonb; need numeric;
begin
  if uid is null then raise exception 'not_authenticated'; end if;
  select * into s from farm_saves where user_id = uid for update;
  if not found then raise exception 'no_save'; end if;
  if p_plot is null or p_plot < 0 or p_plot > 17 then raise exception 'bad_plot'; end if;
  pl := s.plots -> (p_plot::text);
  if pl is null then raise exception 'plot_empty'; end if;
  select * into c from farm_crops where id = pl->>'crop';
  need := c.grow_seconds / greatest(_farm_cfg('growth_speed') * _farm_mult('growth'), 0.01);
  if extract(epoch from clock_timestamp()) - (pl->>'at')::numeric < need - 0.25 then
    raise exception 'not_ready';
  end if;
  update farm_saves set
    plots = plots - (p_plot::text),
    crops = jsonb_set(crops, array[c.id], to_jsonb(coalesce((crops->>c.id)::int, 0) + 1), true),
    updated_at = now()
  where user_id = uid;
  return _farm_state(uid);
end $$;

create or replace function public.farm_sell_crops() returns jsonb
language plpgsql security definer set search_path = public as $$
declare uid uuid := auth.uid(); s farm_saves; k record; total numeric := 0; paid bigint; mult numeric; cnt int := 0;
begin
  if uid is null then raise exception 'not_authenticated'; end if;
  select * into s from farm_saves where user_id = uid for update;
  if not found then raise exception 'no_save'; end if;
  mult := _farm_cfg('sell_mult') * _farm_mult('sell');
  for k in select key, value from jsonb_each_text(s.crops) loop
    total := total + coalesce((select sell_price from farm_crops where id = k.key), 0) * k.value::int * mult;
    cnt := cnt + k.value::int;
  end loop;
  if cnt = 0 then raise exception 'nothing_to_sell'; end if;
  paid := floor(total);
  update farm_saves set coins = coins + paid, total_earned = total_earned + paid, crops = '{}'::jsonb, updated_at = now()
  where user_id = uid;
  perform _farm_log(uid, 'sell_crops', jsonb_build_object('count', cnt, 'paid', paid));
  return _farm_state(uid) || jsonb_build_object('paid', paid);
end $$;

-- ---------- яйца и питомцы ----------
create or replace function public.farm_buy_egg(p_egg text) returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  uid uuid := auth.uid(); s farm_saves; e farm_eggs; t farm_pet_types; pick farm_pet_types;
  total_w numeric; roll numeric; acc numeric := 0; pid uuid;
begin
  if uid is null then raise exception 'not_authenticated'; end if;
  select * into s from farm_saves where user_id = uid for update;
  if not found then raise exception 'no_save'; end if;
  select * into e from farm_eggs where id = p_egg;
  if not found then raise exception 'bad_egg'; end if;
  if s.zones < e.min_zone then raise exception 'zone_locked'; end if;
  if s.coins < e.price then raise exception 'not_enough_coins'; end if;
  if (select count(*) from farm_pets where user_id = uid) >= 60 then raise exception 'inventory_full'; end if;

  select sum(weight) into total_w from farm_pet_types where egg_id = e.id and weight > 0;
  if total_w is null then raise exception 'bad_egg'; end if;
  roll := random() * total_w;
  for t in select * from farm_pet_types where egg_id = e.id and weight > 0 order by weight desc, id loop
    acc := acc + t.weight;
    pick := t;
    exit when roll < acc;
  end loop;

  insert into farm_pets(user_id, pet_type) values (uid, pick.id) returning id into pid;
  update farm_saves set coins = coins - e.price, eggs_opened = eggs_opened + 1, updated_at = now() where user_id = uid;
  perform _farm_log(uid, 'buy_egg', jsonb_build_object('egg', e.id, 'price', e.price, 'pet', pick.id, 'rarity', pick.rarity));
  return _farm_state(uid) || jsonb_build_object('hatched', jsonb_build_object('id', pid, 'type', pick.id, 'rarity', pick.rarity));
end $$;

create or replace function public.farm_place_pet(p_pet uuid, p_stand int) returns jsonb
language plpgsql security definer set search_path = public as $$
declare uid uuid := auth.uid(); s farm_saves; pet farm_pets; need_zone int;
begin
  if uid is null then raise exception 'not_authenticated'; end if;
  select * into s from farm_saves where user_id = uid for update;
  if not found then raise exception 'no_save'; end if;
  if p_stand is null or p_stand < 0 or p_stand > 11 then raise exception 'bad_stand'; end if;
  need_zone := case when p_stand < 3 then 1 when p_stand < 7 then 2 else 3 end;
  if need_zone > s.zones then raise exception 'zone_locked'; end if;
  select * into pet from farm_pets where id = p_pet and user_id = uid for update;
  if not found then raise exception 'bad_pet'; end if;
  if pet.stand_idx is not null then raise exception 'already_placed'; end if;
  if exists (select 1 from farm_pets where user_id = uid and stand_idx = p_stand) then raise exception 'stand_busy'; end if;
  update farm_pets set stand_idx = p_stand, collected_at = now() where id = pet.id;
  return _farm_state(uid);
end $$;

create or replace function public.farm_unplace_pet(p_pet uuid) returns jsonb
language plpgsql security definer set search_path = public as $$
declare uid uuid := auth.uid(); pet farm_pets; paid bigint;
begin
  if uid is null then raise exception 'not_authenticated'; end if;
  perform 1 from farm_saves where user_id = uid for update;
  select * into pet from farm_pets where id = p_pet and user_id = uid for update;
  if not found then raise exception 'bad_pet'; end if;
  if pet.stand_idx is null then raise exception 'not_placed'; end if;
  paid := _farm_collect(uid, pet.id);
  update farm_pets set stand_idx = null where id = pet.id;
  return _farm_state(uid) || jsonb_build_object('paid', paid);
end $$;

create or replace function public.farm_collect(p_stand int default null) returns jsonb
language plpgsql security definer set search_path = public as $$
declare uid uuid := auth.uid(); paid bigint; pid uuid;
begin
  if uid is null then raise exception 'not_authenticated'; end if;
  perform 1 from farm_saves where user_id = uid for update;
  if p_stand is not null then
    select id into pid from farm_pets where user_id = uid and stand_idx = p_stand;
    if pid is null then raise exception 'stand_empty'; end if;
    paid := _farm_collect(uid, pid);
  else
    paid := _farm_collect(uid, null);
  end if;
  return _farm_state(uid) || jsonb_build_object('paid', paid);
end $$;

create or replace function public.farm_sell_pet(p_pet uuid) returns jsonb
language plpgsql security definer set search_path = public as $$
declare uid uuid := auth.uid(); pet farm_pets; t farm_pet_types; price bigint; paid bigint := 0;
begin
  if uid is null then raise exception 'not_authenticated'; end if;
  perform 1 from farm_saves where user_id = uid for update;
  select * into pet from farm_pets where id = p_pet and user_id = uid for update;
  if not found then raise exception 'bad_pet'; end if;
  if pet.stand_idx is not null then paid := _farm_collect(uid, pet.id); end if;
  select * into t from farm_pet_types where id = pet.pet_type;
  price := ceil(t.income * 60);
  delete from farm_pets where id = pet.id;
  update farm_saves set coins = coins + price, total_earned = total_earned + price, updated_at = now() where user_id = uid;
  perform _farm_log(uid, 'sell_pet', jsonb_build_object('pet', t.id, 'price', price));
  return _farm_state(uid) || jsonb_build_object('paid', paid + price);
end $$;

create or replace function public.farm_unlock_zone() returns jsonb
language plpgsql security definer set search_path = public as $$
declare uid uuid := auth.uid(); s farm_saves; z farm_zones;
begin
  if uid is null then raise exception 'not_authenticated'; end if;
  select * into s from farm_saves where user_id = uid for update;
  if not found then raise exception 'no_save'; end if;
  select * into z from farm_zones where zone = s.zones + 1;
  if not found then raise exception 'all_unlocked'; end if;
  if s.coins < z.price then raise exception 'not_enough_coins'; end if;
  update farm_saves set coins = coins - z.price, zones = z.zone, updated_at = now() where user_id = uid;
  perform _farm_log(uid, 'unlock_zone', jsonb_build_object('zone', z.zone, 'price', z.price));
  return _farm_state(uid);
end $$;

create or replace function public.farm_leaderboard() returns jsonb
language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'not_authenticated'; end if;
  return coalesce((
    select jsonb_agg(x) from (
      select p.username, s.total_earned,
             (select count(*) from farm_pets f where f.user_id = s.user_id) as pets
      from farm_saves s join farm_profiles p on p.user_id = s.user_id
      order by s.total_earned desc, p.username limit 15
    ) x), '[]'::jsonb);
end $$;

-- ---------- администрирование ----------
create or replace function public._farm_need(p_level text) returns uuid
language plpgsql stable security definer set search_path = public as $$
declare uid uuid := auth.uid(); r text;
begin
  if uid is null then raise exception 'not_authenticated'; end if;
  r := _farm_role(uid);
  if p_level = 'global' and r is distinct from 'GLOBAL_ADMIN' then raise exception 'forbidden'; end if;
  if p_level = 'admin' and r not in ('admin','GLOBAL_ADMIN') then raise exception 'forbidden'; end if;
  return uid;
end $$;

create or replace function public.farm_announce(p_message text, p_seconds int default 20) returns bigint
language plpgsql security definer set search_path = public as $$
declare uid uuid; nm text; nid bigint; msg text := btrim(coalesce(p_message, ''));
begin
  uid := _farm_need('admin');
  if char_length(msg) < 1 or char_length(msg) > 240 then raise exception 'bad_message'; end if;
  if p_seconds is null or p_seconds < 5 or p_seconds > 3600 then raise exception 'bad_duration'; end if;
  select username into nm from farm_profiles where user_id = uid;
  insert into farm_announcements(message, created_by, created_by_name, expires_at)
  values (msg, uid, nm, now() + make_interval(secs => p_seconds)) returning id into nid;
  perform _farm_log(uid, 'announce', jsonb_build_object('id', nid, 'message', msg));
  return nid;
end $$;

create or replace function public.farm_delete_announcement(p_id bigint) returns void
language plpgsql security definer set search_path = public as $$
declare uid uuid;
begin
  uid := _farm_need('admin');
  delete from farm_announcements where id = p_id;
  perform _farm_log(uid, 'announce_delete', jsonb_build_object('id', p_id));
end $$;

create or replace function public.farm_create_event(p_kind text, p_title text, p_mult numeric, p_minutes int) returns bigint
language plpgsql security definer set search_path = public as $$
declare uid uuid; eid bigint; ttl text := btrim(coalesce(p_title, ''));
begin
  uid := _farm_need('global');
  if p_kind not in ('income','growth','sell') then raise exception 'bad_kind'; end if;
  if char_length(ttl) < 1 or char_length(ttl) > 80 then raise exception 'bad_title'; end if;
  if p_mult is null or p_mult < 1 or p_mult > 100 then raise exception 'bad_mult'; end if;
  if p_minutes is null or p_minutes < 1 or p_minutes > 1440 then raise exception 'bad_duration'; end if;
  insert into farm_events(kind, title, mult, expires_at, created_by)
  values (p_kind, ttl, p_mult, now() + make_interval(mins => p_minutes), uid) returning id into eid;
  perform _farm_log(uid, 'event_create', jsonb_build_object('id', eid, 'kind', p_kind, 'mult', p_mult, 'minutes', p_minutes));
  return eid;
end $$;

create or replace function public.farm_end_event(p_id bigint) returns void
language plpgsql security definer set search_path = public as $$
declare uid uuid;
begin
  uid := _farm_need('global');
  update farm_events set expires_at = now() where id = p_id and expires_at > now();
  perform _farm_log(uid, 'event_end', jsonb_build_object('id', p_id));
end $$;

create or replace function public.farm_set_config(p_key text, p_value numeric) returns void
language plpgsql security definer set search_path = public as $$
declare uid uuid; lo numeric; hi numeric;
begin
  uid := _farm_need('global');
  if p_key = 'income_mult' or p_key = 'sell_mult' then lo := 0.1; hi := 100;
  elsif p_key = 'growth_speed' then lo := 0.1; hi := 50;
  elsif p_key = 'offline_cap_hours' then lo := 0.5; hi := 24;
  else raise exception 'bad_key'; end if;
  if p_value is null or p_value < lo or p_value > hi then raise exception 'bad_value'; end if;
  update farm_config set value = p_value where key = p_key;
  perform _farm_log(uid, 'config', jsonb_build_object('key', p_key, 'value', p_value));
end $$;

create or replace function public.farm_admin_pet_type(p_id text, p_income numeric, p_weight numeric) returns void
language plpgsql security definer set search_path = public as $$
declare uid uuid;
begin
  uid := _farm_need('global');
  if p_income is null or p_income <= 0 or p_income > 100000 then raise exception 'bad_value'; end if;
  if p_weight is null or p_weight < 0 or p_weight > 1000 then raise exception 'bad_value'; end if;
  update farm_pet_types set income = p_income, weight = p_weight where id = p_id;
  if not found then raise exception 'bad_pet_type'; end if;
  -- в яйце должен остаться хотя бы один питомец с шансом
  if exists (select 1 from farm_eggs e where not exists
      (select 1 from farm_pet_types t where t.egg_id = e.id and t.weight > 0)) then
    raise exception 'egg_would_be_empty';
  end if;
  perform _farm_log(uid, 'pet_type', jsonb_build_object('id', p_id, 'income', p_income, 'weight', p_weight));
end $$;

create or replace function public.farm_admin_players(p_query text default '') returns jsonb
language plpgsql security definer set search_path = public as $$
declare q text := btrim(coalesce(p_query, ''));
begin
  perform _farm_need('global');
  return coalesce((select jsonb_agg(x) from (
    select p.user_id, p.username, p.role, s.coins, s.total_earned, s.zones,
           (select count(*) from farm_pets f where f.user_id = p.user_id) as pets,
           s.updated_at
    from farm_profiles p join farm_saves s on s.user_id = p.user_id
    where q = '' or p.username ilike '%' || replace(replace(q, '%', ''), '_', '\_') || '%'
    order by s.updated_at desc limit 50) x), '[]'::jsonb);
end $$;

create or replace function public.farm_admin_player(p_user uuid) returns jsonb
language plpgsql security definer set search_path = public as $$
begin
  perform _farm_need('global');
  if not exists (select 1 from farm_profiles where user_id = p_user) then raise exception 'no_player'; end if;
  return _farm_state(p_user);
end $$;

create or replace function public.farm_admin_set_role(p_user uuid, p_role text) returns void
language plpgsql security definer set search_path = public as $$
declare uid uuid; cur text;
begin
  uid := _farm_need('global');
  if p_role not in ('player','admin') then raise exception 'bad_role'; end if;
  if p_user = uid then raise exception 'forbidden'; end if;
  select role into cur from farm_profiles where user_id = p_user;
  if cur is null then raise exception 'no_player'; end if;
  if cur = 'GLOBAL_ADMIN' then raise exception 'forbidden'; end if;
  update farm_profiles set role = p_role where user_id = p_user;
  perform _farm_log(uid, 'set_role', jsonb_build_object('target', p_user, 'role', p_role));
end $$;

create or replace function public.farm_admin_grant_coins(p_user uuid, p_amount bigint) returns void
language plpgsql security definer set search_path = public as $$
declare uid uuid;
begin
  uid := _farm_need('global');
  if p_amount is null or p_amount < 1 or p_amount > 1000000000 then raise exception 'bad_value'; end if;
  update farm_saves set coins = coins + p_amount, updated_at = now() where user_id = p_user;
  if not found then raise exception 'no_player'; end if;
  perform _farm_log(uid, 'grant_coins', jsonb_build_object('target', p_user, 'amount', p_amount));
end $$;

create or replace function public.farm_admin_log(p_limit int default 50) returns jsonb
language plpgsql security definer set search_path = public as $$
begin
  perform _farm_need('global');
  return coalesce((select jsonb_agg(x) from (
    select l.id, l.action, l.details, l.created_at, p.username
    from farm_log l left join farm_profiles p on p.user_id = l.user_id
    order by l.id desc limit least(greatest(coalesce(p_limit, 50), 1), 200)) x), '[]'::jsonb);
end $$;

-- ---------- каталог и лента для клиента ----------
create or replace function public.farm_catalog() returns jsonb
language plpgsql stable security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'not_authenticated'; end if;
  return jsonb_build_object(
    'crops', (select coalesce(jsonb_agg(to_jsonb(c) order by c.min_zone, c.grow_seconds), '[]'::jsonb) from farm_crops c),
    'zones', (select coalesce(jsonb_agg(to_jsonb(z) order by z.zone), '[]'::jsonb) from farm_zones z),
    'eggs',  (select coalesce(jsonb_agg(to_jsonb(e) order by e.price), '[]'::jsonb) from farm_eggs e),
    'pets',  (select coalesce(jsonb_agg(to_jsonb(t) order by t.income), '[]'::jsonb) from farm_pet_types t));
end $$;

-- Активные объявления и события; время жизни в секундах от «сейчас» (без зависимости от часов клиента).
create or replace function public.farm_feed() returns jsonb
language plpgsql stable security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'not_authenticated'; end if;
  return jsonb_build_object(
    'announcements', coalesce((select jsonb_agg(jsonb_build_object(
        'id', a.id, 'message', a.message, 'by', a.created_by_name,
        'ends_in', extract(epoch from (a.expires_at - now()))) order by a.id)
      from farm_announcements a where a.expires_at > now()), '[]'::jsonb),
    'events', coalesce((select jsonb_agg(jsonb_build_object(
        'id', e.id, 'kind', e.kind, 'title', e.title, 'mult', e.mult,
        'ends_in', extract(epoch from (e.expires_at - now()))) order by e.id)
      from farm_events e where e.starts_at <= now() and e.expires_at > now()), '[]'::jsonb));
end $$;

-- ---------- права на вызов ----------
do $$
declare f record;
begin
  for f in select p.oid::regprocedure as sig, p.proname
           from pg_proc p join pg_namespace n on n.oid = p.pronamespace
           where n.nspname = 'public' and (p.proname like 'farm\_%' or p.proname like '\_farm\_%')
  loop
    execute format('revoke all on function %s from public, anon, authenticated', f.sig);
    if f.proname like 'farm\_%' then
      execute format('grant execute on function %s to authenticated', f.sig);
    end if;
  end loop;
end $$;
