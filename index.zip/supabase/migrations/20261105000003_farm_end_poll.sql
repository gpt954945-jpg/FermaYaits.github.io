-- Allow global test admins to stop the currently active poll for every player.
create or replace function public.farm_end_poll(p_poll bigint default null)
returns integer
language plpgsql
security definer
set search_path = public
as $$
declare
  uid uuid := public._farm_need('global');
  changed integer;
begin
  if p_poll is null then
    update public.farm_polls set active = false where active = true;
  else
    update public.farm_polls set active = false where id = p_poll and active = true;
  end if;
  get diagnostics changed = row_count;
  perform public._farm_log(uid, 'poll_end', jsonb_build_object('poll_id', p_poll, 'count', changed));
  return changed;
end;
$$;
revoke all on function public.farm_end_poll(bigint) from public, anon;
grant execute on function public.farm_end_poll(bigint) to authenticated;
