-- 4 яйца в общем стоке: самое дешёвое всегда есть, остальные 3 выбираются по шансам.
-- Редкие яйца имеют низкий шанс и маленький запас. Обновление ограничено явным WHERE true.
create or replace function public._farm_rotate_stock(p_force boolean default false)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  last_at timestamptz;
begin
  select rotated_at into last_at
  from public.farm_stock_rotation
  where id = true
  for update;

  if not p_force and last_at is not null and last_at > now() - interval '60 seconds' then
    return;
  end if;

  with cheapest as (
    select id from public.farm_eggs order by price asc, id asc limit 1
  ), weighted as (
    select e.id,
      case e.id
        when 'sky' then 100::numeric
        when 'ocean' then 75::numeric
        when 'grove' then 42::numeric
        when 'peak' then 24::numeric
        when 'lava' then 14::numeric
        when 'crystal' then 4::numeric
        when 'shadow' then 0.35::numeric
        when 'cosmic' then 0.05::numeric
        else 35::numeric
      end as chance_weight
    from public.farm_eggs e
    where not exists (select 1 from cheapest c where c.id = e.id)
  ), chosen AS (
    select id from weighted
    order by -ln(greatest(random(), 0.000001)) / chance_weight
    limit 3
  ), selected AS (
    select id from cheapest
    union all
    select id from chosen
  )
  update public.farm_egg_stock s
  set quantity = case
      when s.egg_id not in (select id from selected) then 0
      when s.egg_id = (select id from cheapest) then 120 + floor(random() * 121)::integer
      when s.egg_id = 'sky' then 65 + floor(random() * 76)::integer
      when s.egg_id = 'ocean' then 45 + floor(random() * 56)::integer
      when s.egg_id = 'grove' then 25 + floor(random() * 36)::integer
      when s.egg_id = 'peak' then 12 + floor(random() * 19)::integer
      when s.egg_id = 'lava' then 6 + floor(random() * 11)::integer
      when s.egg_id = 'crystal' then 2 + floor(random() * 4)::integer
      when s.egg_id = 'shadow' then 1 + floor(random() * 2)::integer
      when s.egg_id = 'cosmic' then 1
      else 10 + floor(random() * 21)::integer
    end,
    updated_at = now()
  where true;

  update public.farm_stock_rotation
  set rotated_at = now()
  where id = true;
end;
$$;

revoke all on function public._farm_rotate_stock(boolean) from public, anon, authenticated;
