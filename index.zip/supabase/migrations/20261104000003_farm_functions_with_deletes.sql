-- Две функции с оператором delete. Supabase требует подтверждения для таких запросов, поэтому они применяются отдельно.
-- Выполни в SQL Editor (Supabase → SQL Editor → Run).

create or replace function public.farm_sell_pet(p_pet uuid) returns jsonb
language plpgsql security definer set search_path = public as $$
declare uid uuid := auth.uid(); pet farm_pets; t farm_pet_types; price bigint; paid bigint := 0;
begin
  if uid is null then raise exception 'not_authenticated'; end if;
  perform 1 from farm_saves where user_id = uid for update;
  select * into pet from farm_pets where id = p_pet and user_id = uid for update;
  if not found then raise exception 'bad_pet'; end if;
  if pet.stand_idx is not null then paid := _farm_collect(uid, pet.id); end if;
  select * into t from farm_pet_types where id = pet.pet_type;
  price := ceil(t.income * 60);
  delete from farm_pets where id = pet.id;
  update farm_saves set coins = coins + price, total_earned = total_earned + price, updated_at = now() where user_id = uid;
  perform _farm_log(uid, 'sell_pet', jsonb_build_object('pet', t.id, 'price', price));
  return _farm_state(uid) || jsonb_build_object('paid', paid + price);
end $$;

create or replace function public.farm_delete_announcement(p_id bigint) returns void
language plpgsql security definer set search_path = public as $$
declare uid uuid;
begin
  uid := _farm_need('admin');
  delete from farm_announcements where id = p_id;
  perform _farm_log(uid, 'announce_delete', jsonb_build_object('id', p_id));
end $$;

revoke all on function public.farm_sell_pet(uuid) from public, anon, authenticated;
revoke all on function public.farm_delete_announcement(bigint) from public, anon, authenticated;
grant execute on function public.farm_sell_pet(uuid) to authenticated;
grant execute on function public.farm_delete_announcement(bigint) to authenticated;
