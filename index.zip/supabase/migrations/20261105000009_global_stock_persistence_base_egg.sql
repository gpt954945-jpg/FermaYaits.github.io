-- Stable global stock: automatic player reads no longer rotate/reset stock.
create or replace function public.farm_global_stock() returns jsonb
language plpgsql volatile security definer set search_path=public as $$
begin
  if auth.uid() is null then raise exception 'not_authenticated'; end if;
  return coalesce((select jsonb_agg(jsonb_build_object('id',e.id,'name',e.name,'price',e.price,'min_zone',e.min_zone,'quantity',s.quantity,'max_quantity',s.max_quantity,'updated_at',s.updated_at) order by e.price,e.id)
    from public.farm_eggs e join public.farm_egg_stock s on s.egg_id=e.id),'[]'::jsonb);
end $$;

-- Basic egg for 20 coins, always available in the shared stock.
insert into public.farm_eggs(id,name,price,min_zone)
values('basic','Базовое яйцо',20,0)
on conflict(id) do update set name=excluded.name,price=20,min_zone=0;
insert into public.farm_pet_types(id,name,rarity,income,weight,egg_id)
values('basic_chick','Цыплёнок','common',1,100,'basic')
on conflict(id) do update set name=excluded.name,rarity='common',income=1,weight=100,egg_id='basic';
insert into public.farm_egg_stock(egg_id,quantity,max_quantity,updated_at)
values('basic',1000,10000,now())
on conflict(egg_id) do update set quantity=greatest(public.farm_egg_stock.quantity,1000),max_quantity=10000,updated_at=now();

-- The basic egg is a permanent offer; only three other eggs rotate on manual restock.
create or replace function public._farm_rotate_stock(p_force boolean default false)
returns void language plpgsql security definer set search_path=public as $$
declare last_at timestamptz;
begin
  select rotated_at into last_at from public.farm_stock_rotation where id=true for update;
  if not p_force and last_at is not null and last_at > now()-interval '60 seconds' then return; end if;
  with egg_weights as (
    select e.id,
      greatest(1, coalesce(max(case p.rarity
        when 'common' then 100 when 'uncommon' then 65 when 'rare' then 35
        when 'epic' then 18 when 'legendary' then 8 when 'mythic' then 3 else 50 end),50))::numeric as chance_weight
    from public.farm_eggs e left join public.farm_pet_types p on p.egg_id=e.id
    where e.id <> 'basic'
    group by e.id
  ), chosen as (
    select id from egg_weights order by (-ln(greatest(random(),0.000001))/chance_weight) limit 3
  )
  update public.farm_egg_stock s
    set quantity=case when s.egg_id='basic' then 1000
      when s.egg_id in (select id from chosen) then (20+floor(random()*181))::integer else 0 end,
      updated_at=now()
  where true;
  update public.farm_stock_rotation set rotated_at=now() where id=true;
end $$;
revoke all on function public._farm_rotate_stock(boolean) from public,anon,authenticated;

-- Rotation only happens when an administrator explicitly presses the restock button.
-- farm_global_stock and farm_buy_egg no longer invoke _farm_rotate_stock automatically.
revoke all on function public.farm_global_stock() from public,anon;
grant execute on function public.farm_global_stock() to authenticated;
