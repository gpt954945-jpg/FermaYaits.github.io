-- ФЕРМА СОМБРЕРО: схема, RLS, серверная логика.
-- Только добавляет таблицы farm_* и функции. Старые таблицы (soul_clicker_*, bk_* и т.д.) не затрагиваются.

-- ============ СЕКРЕТНАЯ КОНФИГУРАЦИЯ (клиент доступа не имеет) ============
create table if not exists public.farm_secure_config (
  key text primary key,
  value text not null
);
alter table public.farm_secure_config enable row level security;
revoke all on public.farm_secure_config from anon, authenticated;

-- ============ КАТАЛОГИ ============
create table if not exists public.farm_zones (
  id int primary key,
  name text not null,
  price bigint not null check (price >= 0)
);
create table if not exists public.farm_crops (
  id text primary key,
  name text not null,
  seed_cost int not null check (seed_cost >= 0),
  grow_seconds int not null check (grow_seconds > 0),
  sell_price int not null check (sell_price >= 0),
  zone_req int not null default 1
);
create table if not exists public.farm_egg_types (
  id text primary key,
  name text not null,
  price bigint not null check (price >= 0),
  hatch_seconds int not null check (hatch_seconds >= 0),
  zone_req int not null default 1,
  weights jsonb not null
);
create table if not exists public.farm_chars (
  id text primary key check (id ~ '^[a-z0-9_]{2,24}$'),
  name text not null check (char_length(name) between 1 and 30),
  rarity text not null check (rarity in ('common','rare','epic','legendary','mythic')),
  income_per_min int not null check (income_per_min between 0 and 1000000),
  hue int not null default 0 check (hue between 0 and 360),
  active boolean not null default true
);
create table if not exists public.farm_config (
  key text primary key,
  value numeric not null
);

-- ============ ДАННЫЕ ИГРОКОВ ============
create table if not exists public.farm_profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  username text not null check (username ~ '^[A-Za-z][A-Za-z0-9_]{2,17}$'),
  role text not null default 'player' check (role in ('player','admin','GLOBAL_ADMIN')),
  created_at timestamptz not null default now()
);
create unique index if not exists farm_profiles_username_lower on public.farm_profiles (lower(username));

create table if not exists public.farm_state (
  user_id uuid primary key references auth.users(id) on delete cascade,
  coins bigint not null default 30 check (coins >= 0),
  total_earned bigint not null default 0,
  zones int not null default 1 check (zones between 1 and 3),
  last_collect timestamptz not null default now(),
  last_daily timestamptz,
  updated_at timestamptz not null default now()
);
create table if not exists public.farm_plots (
  user_id uuid not null references auth.users(id) on delete cascade,
  idx int not null check (idx between 0 and 17),
  crop text not null references public.farm_crops(id),
  ready_at timestamptz not null,
  primary key (user_id, idx)
);
create table if not exists public.farm_inventory (
  user_id uuid not null references auth.users(id) on delete cascade,
  item text not null references public.farm_crops(id),
  qty int not null default 0 check (qty >= 0),
  primary key (user_id, item)
);
create table if not exists public.farm_eggs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  egg_type text not null references public.farm_egg_types(id),
  ready_at timestamptz not null,
  created_at timestamptz not null default now()
);
create index if not exists farm_eggs_user on public.farm_eggs(user_id);
create table if not exists public.farm_characters (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  char_id text not null references public.farm_chars(id),
  stand int check (stand between 0 and 7),
  created_at timestamptz not null default now()
);
create index if not exists farm_characters_user on public.farm_characters(user_id);
create unique index if not exists farm_characters_stand_unique on public.farm_characters(user_id, stand) where stand is not null;
create table if not exists public.farm_log (
  id bigint generated always as identity primary key,
  user_id uuid references auth.users(id) on delete set null,
  action text not null,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index if not exists farm_log_user on public.farm_log(user_id, created_at desc);

create table if not exists public.farm_announcements (
  id bigint generated always as identity primary key,
  message text not null check (char_length(message) between 1 and 180),
  created_by uuid references auth.users(id) on delete set null,
  created_by_name text not null default 'Администрация',
  created_at timestamptz not null default now(),
  expires_at timestamptz not null default (now() + interval '15 seconds')
);
create index if not exists farm_announcements_by on public.farm_announcements(created_by);
create table if not exists public.farm_events (
  id bigint generated always as identity primary key,
  kind text not null check (kind in ('coin_boost','growth_boost','income_boost')),
  title text not null check (char_length(title) between 1 and 80),
  mult numeric not null check (mult >= 1 and mult <= 10),
  created_by uuid references auth.users(id) on delete set null,
  created_by_name text not null default 'Администрация',
  starts_at timestamptz not null default now(),
  expires_at timestamptz not null
);
create index if not exists farm_events_by on public.farm_events(created_by);

-- ============ RLS ============
alter table public.farm_zones enable row level security;
alter table public.farm_crops enable row level security;
alter table public.farm_egg_types enable row level security;
alter table public.farm_chars enable row level security;
alter table public.farm_config enable row level security;
alter table public.farm_profiles enable row level security;
alter table public.farm_state enable row level security;
alter table public.farm_plots enable row level security;
alter table public.farm_inventory enable row level security;
alter table public.farm_eggs enable row level security;
alter table public.farm_characters enable row level security;
alter table public.farm_log enable row level security;
alter table public.farm_announcements enable row level security;
alter table public.farm_events enable row level security;

-- каталоги, настройки, объявления, события: читать могут вошедшие игроки, писать — только серверные функции
create policy farm_zones_read on public.farm_zones for select to authenticated using (true);
create policy farm_crops_read on public.farm_crops for select to authenticated using (true);
create policy farm_egg_types_read on public.farm_egg_types for select to authenticated using (true);
create policy farm_chars_read on public.farm_chars for select to authenticated using (true);
create policy farm_config_read on public.farm_config for select to authenticated using (true);
create policy farm_announcements_read on public.farm_announcements for select to authenticated using (true);
create policy farm_events_read on public.farm_events for select to authenticated using (true);
-- личные данные: только свои, только чтение (запись исключительно через RPC)
create policy farm_profiles_own on public.farm_profiles for select to authenticated using (user_id = (select auth.uid()));
create policy farm_state_own on public.farm_state for select to authenticated using (user_id = (select auth.uid()));
create policy farm_plots_own on public.farm_plots for select to authenticated using (user_id = (select auth.uid()));
create policy farm_inventory_own on public.farm_inventory for select to authenticated using (user_id = (select auth.uid()));
create policy farm_eggs_own on public.farm_eggs for select to authenticated using (user_id = (select auth.uid()));
create policy farm_characters_own on public.farm_characters for select to authenticated using (user_id = (select auth.uid()));
create policy farm_log_own on public.farm_log for select to authenticated using (user_id = (select auth.uid()));

-- клиент не имеет прав на запись ни в одну таблицу
revoke insert, update, delete, truncate on
  public.farm_zones, public.farm_crops, public.farm_egg_types, public.farm_chars, public.farm_config,
  public.farm_profiles, public.farm_state, public.farm_plots, public.farm_inventory, public.farm_eggs,
  public.farm_characters, public.farm_log, public.farm_announcements, public.farm_events
  from anon, authenticated;
revoke all on
  public.farm_zones, public.farm_crops, public.farm_egg_types, public.farm_chars, public.farm_config,
  public.farm_profiles, public.farm_state, public.farm_plots, public.farm_inventory, public.farm_eggs,
  public.farm_characters, public.farm_log, public.farm_announcements, public.farm_events
  from anon;

-- ============ НАЧАЛЬНЫЕ ДАННЫЕ ============
insert into public.farm_zones values (1,'Ферма',0),(2,'Сад',400),(3,'Золотой пруд',3000)
  on conflict (id) do nothing;
insert into public.farm_crops values
  ('wheat','Пшеница',5,20,9,1),
  ('carrot','Морковь',12,45,24,1),
  ('corn','Кукуруза',30,90,70,2),
  ('pumpkin','Тыква',80,180,210,2),
  ('melon','Золотая дыня',250,360,700,3)
  on conflict (id) do nothing;
insert into public.farm_egg_types values
  ('basic','Яйцо фермера',150,20,1,'{"common":70,"rare":22,"epic":6,"legendary":1.8,"mythic":0.2}'),
  ('golden','Золотое яйцо',1200,60,2,'{"common":40,"rare":35,"epic":18,"legendary":6,"mythic":1}'),
  ('fiesta','Яйцо фиесты',9000,120,3,'{"common":10,"rare":30,"epic":35,"legendary":20,"mythic":5}')
  on conflict (id) do nothing;
insert into public.farm_chars values
  ('poncho','Пончо','common',6,40,true),
  ('nacho','Начо','common',8,100,true),
  ('chili','Чили','rare',22,170,true),
  ('tequila','Текила','rare',26,210,true),
  ('macho','Мачо','epic',75,270,true),
  ('fiesta','Фиеста','epic',90,320,true),
  ('elgrande','Эль Гранде','legendary',280,350,true),
  ('sombrero','Сомбреро Оригинал','mythic',950,0,true)
  on conflict (id) do nothing;
insert into public.farm_config values ('coin_mult',1),('growth_mult',1),('income_mult',1),('daily_reward',100)
  on conflict (key) do nothing;

-- ============ ВНУТРЕННИЕ ФУНКЦИИ ============
create or replace function public._farm_role() returns text
language sql stable security definer set search_path = public as $$
  select role from public.farm_profiles where user_id = auth.uid()
$$;

create or replace function public._farm_require(p_roles text[]) returns void
language plpgsql stable security definer set search_path = public as $$
begin
  if not coalesce(public._farm_role() = any(p_roles), false) then
    raise exception 'forbidden';
  end if;
end$$;

create or replace function public._farm_mult(p_kind text) returns numeric
language sql stable security definer set search_path = public as $$
  select coalesce((select value from public.farm_config
                    where key = case p_kind when 'coin_boost' then 'coin_mult'
                                            when 'growth_boost' then 'growth_mult'
                                            else 'income_mult' end), 1)
       * coalesce((select exp(sum(ln(mult))) from public.farm_events
                    where kind = p_kind and starts_at <= now() and expires_at > now()), 1)
$$;

create or replace function public._farm_log(p_uid uuid, p_action text, p_details jsonb)
returns void language sql security definer set search_path = public as $$
  insert into public.farm_log(user_id, action, details) values (p_uid, p_action, coalesce(p_details,'{}'::jsonb))
$$;

-- начисление пассивного дохода со стоек (не более 2 часов за раз)
create or replace function public._farm_collect(p_uid uuid) returns bigint
language plpgsql security definer set search_path = public as $$
declare v_secs numeric; v_income numeric; v_gain bigint;
begin
  select least(extract(epoch from now() - last_collect), 7200) into v_secs
    from public.farm_state where user_id = p_uid for update;
  if v_secs is null then return 0; end if;
  select coalesce(sum(c.income_per_min), 0) into v_income
    from public.farm_characters fc join public.farm_chars c on c.id = fc.char_id
   where fc.user_id = p_uid and fc.stand is not null;
  v_gain := floor(v_income / 60.0 * v_secs * public._farm_mult('income_boost'));
  update public.farm_state
     set coins = coins + v_gain, total_earned = total_earned + v_gain,
         last_collect = now(), updated_at = now()
   where user_id = p_uid;
  return v_gain;
end$$;

-- ============ ЗАГРУЗКА СОСТОЯНИЯ ============
create or replace function public.farm_load() returns jsonb
language plpgsql security definer set search_path = public as $$
declare v_uid uuid := auth.uid(); r jsonb;
begin
  if v_uid is null then raise exception 'not_authenticated'; end if;
  if not exists (select 1 from public.farm_profiles where user_id = v_uid) then raise exception 'no_profile'; end if;
  perform public._farm_collect(v_uid);
  select jsonb_build_object(
    'now', now(),
    'profile', (select jsonb_build_object('username', username, 'role', role) from public.farm_profiles where user_id = v_uid),
    'state', (select jsonb_build_object('coins', coins, 'total_earned', total_earned, 'zones', zones, 'last_daily', last_daily) from public.farm_state where user_id = v_uid),
    'plots', coalesce((select jsonb_agg(jsonb_build_object('idx', idx, 'crop', crop, 'ready_at', ready_at)) from public.farm_plots where user_id = v_uid), '[]'::jsonb),
    'inventory', coalesce((select jsonb_object_agg(item, qty) from public.farm_inventory where user_id = v_uid and qty > 0), '{}'::jsonb),
    'eggs', coalesce((select jsonb_agg(jsonb_build_object('id', id, 'egg_type', egg_type, 'ready_at', ready_at) order by created_at) from public.farm_eggs where user_id = v_uid), '[]'::jsonb),
    'chars', coalesce((select jsonb_agg(jsonb_build_object('id', id, 'char_id', char_id, 'stand', stand) order by created_at) from public.farm_characters where user_id = v_uid), '[]'::jsonb),
    'catalog', jsonb_build_object(
      'crops', (select jsonb_agg(to_jsonb(c) order by seed_cost) from public.farm_crops c),
      'eggs', (select jsonb_agg(to_jsonb(e) order by price) from public.farm_egg_types e),
      'zones', (select jsonb_agg(to_jsonb(z) order by id) from public.farm_zones z),
      'chars', (select jsonb_agg(to_jsonb(c) order by income_per_min) from public.farm_chars c)),
    'mult', jsonb_build_object('coin', public._farm_mult('coin_boost'), 'growth', public._farm_mult('growth_boost'), 'income', public._farm_mult('income_boost')),
    'daily_reward', (select value from public.farm_config where key = 'daily_reward'),
    'events', coalesce((select jsonb_agg(jsonb_build_object('id', id, 'kind', kind, 'title', title, 'mult', mult, 'expires_at', expires_at)) from public.farm_events where expires_at > now() and starts_at <= now()), '[]'::jsonb),
    'announcements', coalesce((select jsonb_agg(jsonb_build_object('id', id, 'message', message, 'expires_at', expires_at) order by id) from public.farm_announcements where expires_at > now()), '[]'::jsonb)
  ) into r;
  return r;
end$$;

-- ============ РЕГИСТРАЦИЯ ПРОФИЛЯ + ПРАВИЛО RAVEXIUM ============
-- Роль GLOBAL_ADMIN выдаётся ТОЛЬКО если: имя Ravexium И email подтверждён Supabase Auth
-- И email совпадает со значением global_admin_email в farm_secure_config (клиенту недоступно).
create or replace function public.farm_bootstrap(p_username text) returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid(); v_email text; v_conf boolean; v_admin_email text;
  v_role text := 'player'; v_prof public.farm_profiles%rowtype; v_ok boolean;
begin
  if v_uid is null then raise exception 'not_authenticated'; end if;
  select email, email_confirmed_at is not null into v_email, v_conf from auth.users where id = v_uid;
  select value into v_admin_email from public.farm_secure_config where key = 'global_admin_email';
  v_ok := coalesce(v_conf, false) and v_admin_email is not null and v_email is not null
          and lower(v_email) = lower(v_admin_email);
  select * into v_prof from public.farm_profiles where user_id = v_uid;
  if not found then
    if p_username is null or p_username !~ '^[A-Za-z][A-Za-z0-9_]{2,17}$' then raise exception 'bad_username'; end if;
    if lower(p_username) = 'ravexium' then
      if not v_ok then raise exception 'reserved_name'; end if;
      v_role := 'GLOBAL_ADMIN';
    end if;
    begin
      insert into public.farm_profiles(user_id, username, role) values (v_uid, p_username, v_role);
    exception when unique_violation then
      raise exception 'username_taken';
    end;
    insert into public.farm_state(user_id) values (v_uid) on conflict do nothing;
    perform public._farm_log(v_uid, 'register', jsonb_build_object('role', v_role));
  elsif lower(v_prof.username) = 'ravexium' and v_prof.role <> 'GLOBAL_ADMIN' and v_ok then
    update public.farm_profiles set role = 'GLOBAL_ADMIN' where user_id = v_uid;
    perform public._farm_log(v_uid, 'global_admin_assigned', '{}'::jsonb);
  end if;
  return public.farm_load();
end$$;

-- ============ ИГРОВЫЕ ДЕЙСТВИЯ ============
create or replace function public.farm_plant(p_idx int, p_crop text) returns jsonb
language plpgsql security definer set search_path = public as $$
declare v_uid uuid := auth.uid(); v_state public.farm_state%rowtype; v_crop public.farm_crops%rowtype;
begin
  if v_uid is null then raise exception 'not_authenticated'; end if;
  if p_idx is null or p_idx < 0 or p_idx > 17 then raise exception 'bad_plot'; end if;
  select * into v_state from public.farm_state where user_id = v_uid for update;
  if not found then raise exception 'no_profile'; end if;
  if (p_idx / 6) + 1 > v_state.zones then raise exception 'zone_locked'; end if;
  select * into v_crop from public.farm_crops where id = p_crop;
  if not found then raise exception 'bad_crop'; end if;
  if v_crop.zone_req > v_state.zones then raise exception 'crop_locked'; end if;
  if exists (select 1 from public.farm_plots where user_id = v_uid and idx = p_idx) then raise exception 'plot_busy'; end if;
  if v_state.coins < v_crop.seed_cost then raise exception 'not_enough_coins'; end if;
  update public.farm_state set coins = coins - v_crop.seed_cost, updated_at = now() where user_id = v_uid;
  insert into public.farm_plots(user_id, idx, crop, ready_at)
    values (v_uid, p_idx, p_crop, now() + ((v_crop.grow_seconds / public._farm_mult('growth_boost'))::double precision * interval '1 second'));
  return public.farm_load();
end$$;

create or replace function public.farm_harvest(p_idx int) returns jsonb
language plpgsql security definer set search_path = public as $$
declare v_uid uuid := auth.uid(); v_plot public.farm_plots%rowtype;
begin
  if v_uid is null then raise exception 'not_authenticated'; end if;
  select * into v_plot from public.farm_plots where user_id = v_uid and idx = p_idx for update;
  if not found then raise exception 'nothing_planted'; end if;
  if v_plot.ready_at > now() then raise exception 'not_ready'; end if;
  delete from public.farm_plots where user_id = v_uid and idx = p_idx;
  insert into public.farm_inventory(user_id, item, qty) values (v_uid, v_plot.crop, 1)
    on conflict (user_id, item) do update set qty = public.farm_inventory.qty + 1;
  return public.farm_load();
end$$;

create or replace function public.farm_sell(p_item text, p_qty int default null) returns jsonb
language plpgsql security definer set search_path = public as $$
declare v_uid uuid := auth.uid(); v_have int; v_qty int; v_price int; v_gain bigint;
begin
  if v_uid is null then raise exception 'not_authenticated'; end if;
  select qty into v_have from public.farm_inventory where user_id = v_uid and item = p_item for update;
  if coalesce(v_have, 0) <= 0 then raise exception 'nothing_to_sell'; end if;
  v_qty := coalesce(p_qty, v_have);
  if v_qty <= 0 or v_qty > v_have then raise exception 'bad_quantity'; end if;
  select sell_price into v_price from public.farm_crops where id = p_item;
  v_gain := floor(v_price * v_qty * public._farm_mult('coin_boost'));
  update public.farm_inventory set qty = qty - v_qty where user_id = v_uid and item = p_item;
  update public.farm_state set coins = coins + v_gain, total_earned = total_earned + v_gain, updated_at = now() where user_id = v_uid;
  perform public._farm_log(v_uid, 'sell', jsonb_build_object('item', p_item, 'qty', v_qty, 'gain', v_gain));
  return public.farm_load();
end$$;

create or replace function public.farm_buy_egg(p_type text) returns jsonb
language plpgsql security definer set search_path = public as $$
declare v_uid uuid := auth.uid(); v_state public.farm_state%rowtype; v_egg public.farm_egg_types%rowtype;
begin
  if v_uid is null then raise exception 'not_authenticated'; end if;
  select * into v_state from public.farm_state where user_id = v_uid for update;
  if not found then raise exception 'no_profile'; end if;
  select * into v_egg from public.farm_egg_types where id = p_type;
  if not found then raise exception 'bad_egg'; end if;
  if v_egg.zone_req > v_state.zones then raise exception 'zone_locked'; end if;
  if (select count(*) from public.farm_eggs where user_id = v_uid) >= 6 then raise exception 'too_many_eggs'; end if;
  if v_state.coins < v_egg.price then raise exception 'not_enough_coins'; end if;
  update public.farm_state set coins = coins - v_egg.price, updated_at = now() where user_id = v_uid;
  insert into public.farm_eggs(user_id, egg_type, ready_at) values (v_uid, p_type, now() + v_egg.hatch_seconds * interval '1 second');
  perform public._farm_log(v_uid, 'buy_egg', jsonb_build_object('egg', p_type, 'price', v_egg.price));
  return public.farm_load();
end$$;

create or replace function public.farm_hatch(p_egg uuid) returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid(); v_egg public.farm_eggs%rowtype; v_w jsonb; v_total numeric := 0;
  v_roll numeric; v_rarity text := 'common'; v_r text; v_char text;
begin
  if v_uid is null then raise exception 'not_authenticated'; end if;
  select * into v_egg from public.farm_eggs where id = p_egg and user_id = v_uid for update;
  if not found then raise exception 'no_egg'; end if;
  if v_egg.ready_at > now() then raise exception 'not_ready'; end if;
  select weights into v_w from public.farm_egg_types where id = v_egg.egg_type;
  foreach v_r in array array['common','rare','epic','legendary','mythic'] loop
    v_total := v_total + coalesce((v_w ->> v_r)::numeric, 0);
  end loop;
  v_roll := random() * v_total;
  foreach v_r in array array['common','rare','epic','legendary','mythic'] loop
    v_roll := v_roll - coalesce((v_w ->> v_r)::numeric, 0);
    if v_roll < 0 then v_rarity := v_r; exit; end if;
  end loop;
  select id into v_char from public.farm_chars where rarity = v_rarity and active order by random() limit 1;
  if v_char is null then select id into v_char from public.farm_chars where active order by random() limit 1; end if;
  if v_char is null then raise exception 'no_characters'; end if;
  delete from public.farm_eggs where id = p_egg;
  insert into public.farm_characters(user_id, char_id) values (v_uid, v_char);
  perform public._farm_log(v_uid, 'hatch', jsonb_build_object('char', v_char, 'rarity', v_rarity));
  return public.farm_load() || jsonb_build_object('hatched', v_char);
end$$;

create or replace function public.farm_place(p_char uuid, p_stand int) returns jsonb
language plpgsql security definer set search_path = public as $$
declare v_uid uuid := auth.uid(); v_zones int;
begin
  if v_uid is null then raise exception 'not_authenticated'; end if;
  if p_stand is null or p_stand < 0 or p_stand > 7 then raise exception 'bad_stand'; end if;
  perform public._farm_collect(v_uid);
  select zones into v_zones from public.farm_state where user_id = v_uid;
  if (case when p_stand < 3 then 1 when p_stand < 6 then 2 else 3 end) > v_zones then raise exception 'zone_locked'; end if;
  if not exists (select 1 from public.farm_characters where id = p_char and user_id = v_uid) then raise exception 'no_character'; end if;
  if exists (select 1 from public.farm_characters where user_id = v_uid and stand = p_stand and id <> p_char) then raise exception 'stand_busy'; end if;
  update public.farm_characters set stand = p_stand where id = p_char and user_id = v_uid;
  return public.farm_load();
end$$;

create or replace function public.farm_unplace(p_char uuid) returns jsonb
language plpgsql security definer set search_path = public as $$
declare v_uid uuid := auth.uid();
begin
  if v_uid is null then raise exception 'not_authenticated'; end if;
  perform public._farm_collect(v_uid);
  update public.farm_characters set stand = null where id = p_char and user_id = v_uid;
  return public.farm_load();
end$$;

create or replace function public.farm_sell_char(p_char uuid) returns jsonb
language plpgsql security definer set search_path = public as $$
declare v_uid uuid := auth.uid(); v_char public.farm_characters%rowtype; v_inc int; v_gain bigint;
begin
  if v_uid is null then raise exception 'not_authenticated'; end if;
  select * into v_char from public.farm_characters where id = p_char and user_id = v_uid for update;
  if not found then raise exception 'no_character'; end if;
  if v_char.stand is not null then raise exception 'unplace_first'; end if;
  select income_per_min into v_inc from public.farm_chars where id = v_char.char_id;
  v_gain := v_inc * 15;
  delete from public.farm_characters where id = p_char;
  update public.farm_state set coins = coins + v_gain, total_earned = total_earned + v_gain, updated_at = now() where user_id = v_uid;
  perform public._farm_log(v_uid, 'sell_char', jsonb_build_object('char', v_char.char_id, 'gain', v_gain));
  return public.farm_load();
end$$;

create or replace function public.farm_unlock_zone(p_zone int) returns jsonb
language plpgsql security definer set search_path = public as $$
declare v_uid uuid := auth.uid(); v_state public.farm_state%rowtype; v_price bigint;
begin
  if v_uid is null then raise exception 'not_authenticated'; end if;
  select * into v_state from public.farm_state where user_id = v_uid for update;
  if not found then raise exception 'no_profile'; end if;
  if p_zone <> v_state.zones + 1 then raise exception 'bad_zone'; end if;
  select price into v_price from public.farm_zones where id = p_zone;
  if v_price is null then raise exception 'bad_zone'; end if;
  if v_state.coins < v_price then raise exception 'not_enough_coins'; end if;
  update public.farm_state set coins = coins - v_price, zones = p_zone, updated_at = now() where user_id = v_uid;
  perform public._farm_log(v_uid, 'unlock_zone', jsonb_build_object('zone', p_zone, 'price', v_price));
  return public.farm_load();
end$$;

create or replace function public.farm_daily() returns jsonb
language plpgsql security definer set search_path = public as $$
declare v_uid uuid := auth.uid(); v_last timestamptz; v_reward bigint;
begin
  if v_uid is null then raise exception 'not_authenticated'; end if;
  select last_daily into v_last from public.farm_state where user_id = v_uid for update;
  if v_last is not null and now() - v_last < interval '20 hours' then raise exception 'daily_not_ready'; end if;
  select floor(value) into v_reward from public.farm_config where key = 'daily_reward';
  update public.farm_state set coins = coins + coalesce(v_reward,0), total_earned = total_earned + coalesce(v_reward,0),
         last_daily = now(), updated_at = now() where user_id = v_uid;
  perform public._farm_log(v_uid, 'daily', jsonb_build_object('reward', v_reward));
  return public.farm_load();
end$$;

-- ============ АДМИНИСТРИРОВАНИЕ ============
create or replace function public.admin_announce(p_message text, p_seconds int default 15) returns bigint
language plpgsql security definer set search_path = public as $$
declare v_id bigint; v_name text; v_msg text := btrim(coalesce(p_message,''));
begin
  perform public._farm_require(array['admin','GLOBAL_ADMIN']);
  if char_length(v_msg) < 1 or char_length(v_msg) > 180 then raise exception 'bad_message'; end if;
  select username into v_name from public.farm_profiles where user_id = auth.uid();
  insert into public.farm_announcements(message, created_by, created_by_name, expires_at)
    values (v_msg, auth.uid(), v_name, now() + greatest(5, least(coalesce(p_seconds,15), 300)) * interval '1 second')
    returning id into v_id;
  perform public._farm_log(auth.uid(), 'admin_announce', jsonb_build_object('id', v_id));
  return v_id;
end$$;

create or replace function public.admin_delete_announcement(p_id bigint) returns void
language plpgsql security definer set search_path = public as $$
begin
  perform public._farm_require(array['admin','GLOBAL_ADMIN']);
  delete from public.farm_announcements where id = p_id;
  perform public._farm_log(auth.uid(), 'admin_delete_announcement', jsonb_build_object('id', p_id));
end$$;

create or replace function public.admin_create_event(p_kind text, p_title text, p_mult numeric, p_minutes int) returns bigint
language plpgsql security definer set search_path = public as $$
declare v_id bigint; v_name text;
begin
  perform public._farm_require(array['GLOBAL_ADMIN']);
  if p_kind not in ('coin_boost','growth_boost','income_boost') then raise exception 'bad_kind'; end if;
  if p_mult is null or p_mult < 1 or p_mult > 10 then raise exception 'bad_mult'; end if;
  if p_title is null or char_length(btrim(p_title)) not between 1 and 80 then raise exception 'bad_title'; end if;
  select username into v_name from public.farm_profiles where user_id = auth.uid();
  insert into public.farm_events(kind, title, mult, created_by, created_by_name, expires_at)
    values (p_kind, btrim(p_title), p_mult, auth.uid(), v_name, now() + greatest(1, least(coalesce(p_minutes,10), 1440)) * interval '1 minute')
    returning id into v_id;
  perform public._farm_log(auth.uid(), 'admin_event', jsonb_build_object('id', v_id, 'kind', p_kind, 'mult', p_mult));
  return v_id;
end$$;

create or replace function public.admin_delete_event(p_id bigint) returns void
language plpgsql security definer set search_path = public as $$
begin
  perform public._farm_require(array['GLOBAL_ADMIN']);
  delete from public.farm_events where id = p_id;
  perform public._farm_log(auth.uid(), 'admin_delete_event', jsonb_build_object('id', p_id));
end$$;

create or replace function public.admin_set_config(p_key text, p_value numeric) returns void
language plpgsql security definer set search_path = public as $$
begin
  perform public._farm_require(array['GLOBAL_ADMIN']);
  if p_key in ('coin_mult','growth_mult','income_mult') then
    if p_value is null or p_value < 0.1 or p_value > 10 then raise exception 'bad_value'; end if;
  elsif p_key = 'daily_reward' then
    if p_value is null or p_value < 0 or p_value > 1000000 then raise exception 'bad_value'; end if;
  else
    raise exception 'bad_key';
  end if;
  insert into public.farm_config(key, value) values (p_key, p_value)
    on conflict (key) do update set value = excluded.value;
  perform public._farm_log(auth.uid(), 'admin_config', jsonb_build_object('key', p_key, 'value', p_value));
end$$;

create or replace function public.admin_players() returns jsonb
language plpgsql security definer set search_path = public as $$
begin
  perform public._farm_require(array['GLOBAL_ADMIN']);
  return coalesce((
    select jsonb_agg(jsonb_build_object(
      'username', p.username, 'role', p.role, 'created_at', p.created_at,
      'coins', s.coins, 'total_earned', s.total_earned, 'zones', s.zones,
      'chars', (select count(*) from public.farm_characters c where c.user_id = p.user_id))
      order by s.total_earned desc)
    from public.farm_profiles p join public.farm_state s on s.user_id = p.user_id), '[]'::jsonb);
end$$;

create or replace function public.admin_set_role(p_username text, p_role text) returns void
language plpgsql security definer set search_path = public as $$
declare v_target public.farm_profiles%rowtype;
begin
  perform public._farm_require(array['GLOBAL_ADMIN']);
  if p_role not in ('admin','player') then raise exception 'bad_role'; end if;
  select * into v_target from public.farm_profiles where lower(username) = lower(p_username);
  if not found then raise exception 'no_such_player'; end if;
  if v_target.role = 'GLOBAL_ADMIN' then raise exception 'forbidden'; end if;
  update public.farm_profiles set role = p_role where user_id = v_target.user_id;
  perform public._farm_log(auth.uid(), 'admin_set_role', jsonb_build_object('target', v_target.username, 'role', p_role));
end$$;

create or replace function public.admin_upsert_char(p_id text, p_name text, p_rarity text, p_income int, p_hue int, p_active boolean) returns void
language plpgsql security definer set search_path = public as $$
begin
  perform public._farm_require(array['GLOBAL_ADMIN']);
  insert into public.farm_chars(id, name, rarity, income_per_min, hue, active)
    values (p_id, btrim(p_name), p_rarity, p_income, p_hue, coalesce(p_active, true))
    on conflict (id) do update set name = excluded.name, rarity = excluded.rarity,
      income_per_min = excluded.income_per_min, hue = excluded.hue, active = excluded.active;
  perform public._farm_log(auth.uid(), 'admin_char', jsonb_build_object('id', p_id));
end$$;

-- ============ ПРАВА НА ВЫЗОВ ============
do $$
declare f text;
begin
  for f in select p.oid::regprocedure::text from pg_proc p join pg_namespace n on n.oid = p.pronamespace
            where n.nspname = 'public' and (p.proname like 'farm\_%' or p.proname like 'admin\_%' or p.proname like '\_farm\_%')
  loop
    execute format('revoke all on function %s from public, anon, authenticated', f);
  end loop;
  for f in select p.oid::regprocedure::text from pg_proc p join pg_namespace n on n.oid = p.pronamespace
            where n.nspname = 'public' and (p.proname like 'farm\_%' or p.proname like 'admin\_%')
  loop
    execute format('grant execute on function %s to authenticated', f);
  end loop;
end$$;

-- ============ REALTIME ============
do $$
begin
  if not exists (select 1 from pg_publication_tables where pubname='supabase_realtime' and tablename='farm_announcements') then
    alter publication supabase_realtime add table public.farm_announcements;
  end if;
  if not exists (select 1 from pg_publication_tables where pubname='supabase_realtime' and tablename='farm_events') then
    alter publication supabase_realtime add table public.farm_events;
  end if;
  if not exists (select 1 from pg_publication_tables where pubname='supabase_realtime' and tablename='farm_config') then
    alter publication supabase_realtime add table public.farm_config;
  end if;
end$$;
