-- Четыре случайных яйца в общем стоке. Автоматический ротационный ресток раз в 60 секунд.
create table if not exists public.farm_stock_rotation (
  id boolean primary key default true check (id),
  rotated_at timestamptz not null default now()
);
insert into public.farm_stock_rotation(id,rotated_at) values(true,now()-interval '2 minutes') on conflict(id) do nothing;

create or replace function public._farm_rotate_stock(p_force boolean default false)
returns void language plpgsql security definer set search_path=public as $$
declare last_at timestamptz;
begin
  select rotated_at into last_at from public.farm_stock_rotation where id=true for update;
  if not p_force and last_at is not null and last_at > now()-interval '60 seconds' then return; end if;
  -- Взвешенный случайный выбор без повторов: обычные яйца чаще, редкие яйца реже.
  with egg_weights as (
    select e.id,
      greatest(1, coalesce(max(case p.rarity
        when 'common' then 100 when 'uncommon' then 65 when 'rare' then 35
        when 'epic' then 18 when 'legendary' then 8 when 'mythic' then 3 else 50 end),50))::numeric as chance_weight
    from public.farm_eggs e left join public.farm_pet_types p on p.egg_id=e.id
    group by e.id
  ), chosen as (
    select id from egg_weights order by (-ln(greatest(random(),0.000001))/chance_weight) limit 4
  )
  update public.farm_egg_stock s
    set quantity=case when s.egg_id in (select id from chosen)
      then (20+floor(random()*181))::integer else 0 end,
      updated_at=now()
  where true;
  update public.farm_stock_rotation set rotated_at=now() where id=true;
end $$;

create or replace function public.farm_global_stock() returns jsonb
language plpgsql volatile security definer set search_path=public as $$
begin
  if auth.uid() is null then raise exception 'not_authenticated'; end if;
  perform public._farm_rotate_stock(false);
  return coalesce((select jsonb_agg(jsonb_build_object('id',e.id,'name',e.name,'price',e.price,'min_zone',e.min_zone,'quantity',s.quantity,'max_quantity',s.max_quantity,'updated_at',s.updated_at) order by e.price)
    from public.farm_eggs e join public.farm_egg_stock s on s.egg_id=e.id where s.quantity>0),'[]'::jsonb);
end $$;

create or replace function public.farm_admin_roll_stock() returns jsonb
language plpgsql security definer set search_path=public as $$
declare uid uuid:=public._farm_need('global');
begin
  perform public._farm_rotate_stock(true);
  perform public._farm_log(uid,'egg_stock_random_restock',jsonb_build_object('kind','weighted_four_egg_roll'));
  return public.farm_global_stock();
end $$;

-- Покупка также проверяет минутный таймер, даже если окно стока было открыто заранее.
create or replace function public.farm_buy_egg(p_egg text) returns jsonb
language plpgsql security definer set search_path=public as $$
declare uid uuid:=auth.uid(); s public.farm_saves; e public.farm_eggs; t public.farm_pet_types; pick public.farm_pet_types; total_w numeric; roll numeric; acc numeric:=0; pid uuid; stock public.farm_egg_stock;
begin
 if uid is null then raise exception 'not_authenticated'; end if;
 perform public.farm_global_stock();
 select * into s from public.farm_saves where user_id=uid for update; if not found then raise exception 'no_save'; end if;
 select * into e from public.farm_eggs where id=p_egg; if not found then raise exception 'bad_egg'; end if;
 if s.zones<e.min_zone then raise exception 'zone_locked'; end if;
 if s.coins<e.price then raise exception 'not_enough_coins'; end if;
 if (select count(*) from public.farm_pets where user_id=uid)>=60 then raise exception 'inventory_full'; end if;
 select * into stock from public.farm_egg_stock where egg_id=p_egg for update;
 if not found or stock.quantity<=0 then raise exception 'egg_out_of_stock'; end if;
 select sum(weight) into total_w from public.farm_pet_types where egg_id=e.id and weight>0; if total_w is null then raise exception 'bad_egg'; end if;
 roll:=random()*total_w;
 for t in select * from public.farm_pet_types where egg_id=e.id and weight>0 order by weight desc,id loop acc:=acc+t.weight;pick:=t;exit when roll<acc;end loop;
 insert into public.farm_pets(user_id,pet_type) values(uid,pick.id) returning id into pid;
 update public.farm_egg_stock set quantity=quantity-1,updated_at=now() where egg_id=p_egg;
 update public.farm_saves set coins=coins-e.price,eggs_opened=eggs_opened+1,updated_at=now() where user_id=uid;
 perform public._farm_log(uid,'buy_egg',jsonb_build_object('egg',e.id,'price',e.price,'pet',pick.id,'rarity',pick.rarity));
 return public._farm_state(uid)||jsonb_build_object('hatched',jsonb_build_object('id',pid,'type',pick.id,'rarity',pick.rarity));
end $$;

grant execute on function public.farm_global_stock(),public.farm_admin_roll_stock(),public.farm_buy_egg(text) to authenticated;

-- Служебная таблица и внутренняя функция недоступны напрямую из клиентского API.
alter table public.farm_stock_rotation enable row level security;
revoke all on table public.farm_stock_rotation from public, anon, authenticated;
revoke all on function public._farm_rotate_stock(boolean) from public, anon, authenticated;
revoke all on function public.farm_global_stock() from public, anon;
revoke all on function public.farm_admin_roll_stock() from public, anon;
revoke all on function public.farm_buy_egg(text) from public, anon;
