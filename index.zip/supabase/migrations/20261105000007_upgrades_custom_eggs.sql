-- Persistent per-player upgrades and automatic pet type for custom eggs.
create table if not exists public.farm_player_upgrades(
 user_id uuid primary key references auth.users(id) on delete cascade,
 income_level integer not null default 0 check(income_level between 0 and 10),
 speed_level integer not null default 0 check(speed_level between 0 and 10),
 sell_level integer not null default 0 check(sell_level between 0 and 10),
 updated_at timestamptz not null default now()
);
alter table public.farm_player_upgrades enable row level security;
revoke all on public.farm_player_upgrades from anon,authenticated;

create or replace function public.farm_upgrades_get()
returns jsonb language plpgsql security definer set search_path=public as $$
declare uid uuid:=auth.uid(); u public.farm_player_upgrades; s public.farm_saves;
begin
 if uid is null then raise exception 'not_authenticated'; end if;
 insert into public.farm_player_upgrades(user_id) values(uid) on conflict(user_id) do nothing;
 select * into u from public.farm_player_upgrades where user_id=uid;
 select * into s from public.farm_saves where user_id=uid;
 return jsonb_build_object('income',u.income_level,'speed',u.speed_level,'sell',u.sell_level,'coins',s.coins);
end $$;

create or replace function public.farm_upgrade_buy(p_kind text)
returns jsonb language plpgsql security definer set search_path=public as $$
declare uid uuid:=auth.uid(); u public.farm_player_upgrades; s public.farm_saves; lv integer; base_cost integer; cost bigint;
begin
 if uid is null then raise exception 'not_authenticated'; end if;
 if p_kind not in ('income','speed','sell') then raise exception 'bad_upgrade'; end if;
 insert into public.farm_player_upgrades(user_id) values(uid) on conflict(user_id) do nothing;
 select * into u from public.farm_player_upgrades where user_id=uid for update;
 select * into s from public.farm_saves where user_id=uid for update;
 if p_kind='income' then lv:=u.income_level;base_cost:=500;
 elsif p_kind='speed' then lv:=u.speed_level;base_cost:=650;
 else lv:=u.sell_level;base_cost:=450; end if;
 if lv>=10 then raise exception 'upgrade_max'; end if;
 cost:=floor(base_cost*power(1.7,lv));
 if s.coins<cost then raise exception 'not_enough_coins'; end if;
 update public.farm_saves set coins=coins-cost,updated_at=now() where user_id=uid;
 if p_kind='income' then update public.farm_player_upgrades set income_level=income_level+1,updated_at=now() where user_id=uid;
 elsif p_kind='speed' then update public.farm_player_upgrades set speed_level=speed_level+1,updated_at=now() where user_id=uid;
 else update public.farm_player_upgrades set sell_level=sell_level+1,updated_at=now() where user_id=uid; end if;
 select * into u from public.farm_player_upgrades where user_id=uid;
 select * into s from public.farm_saves where user_id=uid;
 return jsonb_build_object('income',u.income_level,'speed',u.speed_level,'sell',u.sell_level,'coins',s.coins);
end $$;
grant execute on function public.farm_upgrades_get(),public.farm_upgrade_buy(text) to authenticated;
revoke all on function public.farm_upgrades_get(),public.farm_upgrade_buy(text) from public,anon;
