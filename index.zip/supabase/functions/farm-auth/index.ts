// Username + password auth bridge. Supabase Auth remains the credential store.
const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, apikey, content-type, x-client-info',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Content-Type': 'application/json',
};
const reply = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: cors });
const fail = (code: string, status = 400) => reply({ code, message: code }, status);
const env = (key: string) => Deno.env.get(key) || '';
function keyedSecret(jsonName: string, legacyName: string): string {
  const legacy = env(legacyName);
  if (legacy) return legacy;
  try { return JSON.parse(env(jsonName) || '{}').default || ''; } catch { return ''; }
}
const base = env('SUPABASE_URL').replace(/\/$/, '');
const anon = keyedSecret('SUPABASE_PUBLISHABLE_KEYS', 'SUPABASE_ANON_KEY');
const secret = keyedSecret('SUPABASE_SECRET_KEYS', 'SUPABASE_SERVICE_ROLE_KEY');
const aliasEmail = (username: string) => `${username.toLowerCase()}@login.fermayaits.com`;
async function request(path: string, key: string, init: RequestInit = {}) {
  const res = await fetch(`${base}${path}`, {
    ...init,
    headers: { apikey: key, Authorization: `Bearer ${key}`, 'Content-Type': 'application/json', ...(init.headers || {}) },
  });
  const data = await res.json().catch(() => ({}));
  return { res, data };
}
Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  if (req.method !== 'POST') return fail('method_not_allowed', 405);
  if (!base || !anon || !secret) return fail('auth_service_unavailable', 503);
  try {
    const body = await req.json();
    const action = String(body?.action || '');
    const username = String(body?.username || '').trim();
    const password = String(body?.password || '');
    if (!/^[A-Za-z][A-Za-z0-9_]{2,17}$/.test(username)) return fail('bad_username', 400);
    if (password.length < 6 || password.length > 72) return fail('weak_password', 400);
    if (!['signup', 'login'].includes(action)) return fail('bad_action', 400);

    const isOwnerName = username.toLowerCase() === 'ravexiumxxxd';
    if (action === 'signup') {
      if (isOwnerName) {
        const claim = String(body?.owner_key || '');
        if (!claim) return fail('owner_key_required', 403);
        const keyRow = await request('/rest/v1/farm_private?select=value&key=eq.owner_claim_key&limit=1', secret);
        const stored = Array.isArray(keyRow.data) ? String(keyRow.data[0]?.value || '') : '';
        if (!keyRow.res.ok || !stored || stored === 'used' || stored !== claim) return fail('owner_key_invalid', 403);
      }
      const exists = await request(`/rest/v1/farm_profiles?select=user_id&username=ilike.${encodeURIComponent(username)}&limit=1`, secret);
      if (!exists.res.ok) return fail('auth_service_unavailable', 503);
      if (Array.isArray(exists.data) && exists.data.length) return fail('name_taken', 409);
      const email = aliasEmail(username);
      const created = await request('/auth/v1/admin/users', secret, {
        method: 'POST',
        body: JSON.stringify({ email, password, email_confirm: true, user_metadata: { username } }),
      });
      if (!created.res.ok) {
        const raw = String(created.data?.msg || created.data?.message || created.data?.code || '');
        if (/already|registered|exists|duplicate/i.test(raw)) return fail('name_taken', 409);
        return fail('auth_service_unavailable', 503);
      }
      // The one-time key is consumed transactionally by farm_claim_owner after sign-in.
      const signed = await request('/auth/v1/token?grant_type=password', anon, {
        method: 'POST', body: JSON.stringify({ email, password }),
      });
      if (!signed.res.ok || !signed.data?.access_token) return fail('invalid_credentials', 401);
      return reply({ ...signed.data, user: signed.data.user ? { id: signed.data.user.id } : undefined });
    }

    let email = aliasEmail(username);
    const profile = await request(`/rest/v1/farm_profiles?select=user_id&username=ilike.${encodeURIComponent(username)}&limit=1`, secret);
    let userId = Array.isArray(profile.data) && profile.data[0]?.user_id;
    if (!userId) {
      const users = await request('/auth/v1/admin/users?page=1&per_page=1000', secret);
      if (users.res.ok && Array.isArray(users.data?.users)) {
        const match = users.data.users.find((u: any) => String(u.user_metadata?.username || '').toLowerCase() === username.toLowerCase());
        if (match) { userId = match.id; email = match.email || email; }
      }
    }
    if (userId) {
      const found = await request(`/auth/v1/admin/users/${encodeURIComponent(userId)}`, secret);
      if (!found.res.ok || !found.data?.user?.email) return fail('invalid_credentials', 401);
      email = found.data.user.email;
    }
    const signed = await request('/auth/v1/token?grant_type=password', anon, {
      method: 'POST', body: JSON.stringify({ email, password }),
    });
    if (!signed.res.ok || !signed.data?.access_token) return fail('invalid_credentials', 401);
    const safe = { ...signed.data, user: signed.data.user ? { id: signed.data.user.id } : undefined };
    return reply(safe);
  } catch (_error) {
    return fail('auth_service_unavailable', 503);
  }
});
